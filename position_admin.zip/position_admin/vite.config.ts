import { ConfigEnv, defineConfig, loadEnv, UserConfigExport } from 'vite'
import vue from '@vitejs/plugin-vue'
import VueJsx from '@vitejs/plugin-vue-jsx'
import VueSetupExtend from 'vite-plugin-vue-setup-extend'
import { createSvgIconsPlugin } from 'vite-plugin-svg-icons'
import { resolve } from 'path'
import eslintPlugin from 'vite-plugin-eslint'
import viteCompression from 'vite-plugin-compression'
const CWD = process.cwd()
// https://vitejs.dev/config/
export default ({ mode }: ConfigEnv): UserConfigExport => {
    const { VITE_BASE_URL, VITE_SITE_FAVICON } = loadEnv(mode, CWD)
    return defineConfig({
        root: resolve(__dirname, ''),
        publicDir: resolve(__dirname, './public'),
        base: `${VITE_BASE_URL}`,
        plugins: [
            vue(),
            VueJsx(),
            PluginTagsTransform(mode, VITE_BASE_URL, VITE_SITE_FAVICON),
            VueSetupExtend(),
            createSvgIconsPlugin({
                // 指定需要缓存的图标文件夹
                iconDirs: [resolve(process.cwd(), 'src/assets/svg')],
                symbolId: 'icon-[dir]-[name]',
            }),
            // 配置vite在运行的时候自动检测eslint规范
            eslintPlugin({
                include: [
                    'src/**/*.ts',
                    'src/**/*.js',
                    'src/**/*.vue',
                    'src/*.ts',
                    'src/*.js',
                    'src/*.vue',
                ],
                emitWarning: false,
            }),
            viteCompression(),
        ],
        build: {
            outDir: resolve(__dirname, 'dist'),
            // 指定静态资源存放目录
            assetsDir: resolve(__dirname, 'src/assets'),
            rollupOptions: {
                input: {
                    root: resolve(__dirname, 'index.html'),
                },
                output: {
                    entryFileNames: 'assets/js/[name]-[hash].js',
                    chunkFileNames: 'assets/js/[name]-[hash].js',
                    assetFileNames: 'assets/[ext]/[name]-[hash].[ext]',
                },
            },
        },
        resolve: {
            alias: {
                '@': resolve(__dirname, './src'),
            },
        },
        css: {
            preprocessorOptions: {
                less: {
                    javascriptEnabled: true,
                },
            },
        },
        server: {
            port: 8100,
            host: '0.0.0.0',
            open: false,
        },
        preview: {
            port: 8088,
            strictPort: true,
            open: true,
            cors: true,
        },
    })
}

// 插件，提供 在 html -> head -> 插入 script
const PluginTagsTransform = function (mode, vite_base_url, vite_site_favicon) {
    console.log(mode)
    // if (mode !== 'production') {
    //     return null
    // }
    return {
        name: 'body-prepend-transform',
        transformIndexHtml() {
            return [
                {
                    tag: 'link',
                    attrs: {
                        type: 'text/css',
                        charset: 'utf-8',
                        rel: 'stylesheet',
                        href: vite_base_url + '/static/css/loading.css',
                    },
                },
                {
                    tag: 'link',
                    attrs: {
                        type: 'image/svg+xml',
                        rel: 'icon',
                        href: vite_base_url + vite_site_favicon,
                    },
                },
            ]
        },
    }
}
