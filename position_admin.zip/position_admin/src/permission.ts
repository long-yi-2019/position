import { close, start } from '@/utils/Nprogress'
import { latelyRouter } from '@/api/system/sysUser'
import { getPermissionStore, getUserStore } from '@/store'
import router from '@/router'
// import { message } from 'ant-design-vue'
import { RouteRecordName } from 'vue-router'

const permissionStore = getPermissionStore()
const userStore = getUserStore()
const loginPage = import.meta.env?.VITE_PAGE_LOGIN
const whiteListRouters = ['/login', '/welcome', '/logout']

router.beforeEach((to, from, next) => {
    start()
    const { token } = userStore
    if (to.meta.title) {
        document.title = to.meta.title + '-' + import.meta.env.VITE_SITE_NAME
    }
    if (token) {
        if (to.path === '/login') {
            userStore.logout().then()
            permissionStore.restore()
            next()
            return
        }
        // 判断路由是否已初始化
        const { onLoaded } = permissionStore
        if (onLoaded) {
            /*判断如果路由不存在，则跳转登录页*/
            const has = router.hasRoute(to.name as RouteRecordName)
            if (has) {
                const menus = permissionStore.menuRoutersOneStages.filter((m) => m.path === to.path)
                if (menus.length > 0) {
                    permissionStore.aliveTabs(menus[0])
                    const routeUrl = router.resolve({
                        path: to.path,
                        query: to.query,
                    })
                    latelyRouter({
                        title: to.meta.title,
                        icon: to.meta.icon,
                        path:
                            document.location.protocol +
                            '//' +
                            document.location.host +
                            routeUrl.href,
                    }).then(() => {})
                }
                next()
            } else {
                next(`/`)
            }
        } else {
            //解析用户信息
            userStore
                .getUserInfo()
                .then(() => {
                    return permissionStore.initRoutes()
                })
                .then(() => {
                    // 请求带有 redirect 重定向时，登录自动重定向到该地址
                    const redirect = decodeURIComponent(<string>from.query?.redirect || to.path)
                    if (router.getRoutes().filter((r) => r.path === redirect).length < 1) {
                        next(`/`)
                    } else {
                        if (to.path === redirect) {
                            next({ ...to, replace: true })
                        } else {
                            // 跳转到目的路由
                            next({ path: redirect })
                        }
                    }
                })
                .catch(() => {
                    // message.error(e.message || '请确认该用户拥有访问权限').then()
                    userStore.logout().then()
                    permissionStore.restore()
                    // next("/login") //next(`/login?redirect=${to.path}`)
                    window.location.href = loginPage
                    close()
                    return
                })
        }
    } else {
        /* white list router */
        if (whiteListRouters.indexOf(to.path) !== -1) {
            if (to.path === '/login') {
                userStore.logout().then()
                permissionStore.restore()
            }
            next()
        } else {
            // next("/login") //next(`/login?redirect=${to.path}`)
            window.location.href = loginPage
        }
        close()
    }
})

router.afterEach(() => {
    close()
})
