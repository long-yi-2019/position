<template>
    <div
        class="login_container"
        :style="{
            backgroundImage: 'url(' + backgroundImagePath + ')',
        }"
    >
        <div class="login_main">
            <div class="login_header flex justify-between">
                <div class="flex align-center">
                    <img class="logo" alt="" :src="logoPath" />
                </div>
                <div class="flex align-center">
                    <!--                    <a href="https://norisk.cn" target="_blank" style="color: #ffffff">官网</a>-->
                    <!--                    <ADivider type="vertical" style="background: #ffffff" />-->
                    <!--                    <div class="link" @click="showQrcode">APP下载</div>-->
                </div>
            </div>
            <!--            <div class="login_image"></div>-->
            <div class="login_body">
                <div class="login_form">
                    <div class="title">账号密码登录</div>
                    <div class="login_form_container">
                        <LoginAccount></LoginAccount>
                        <ASpace>
                            <!--                            <div class="link">扫码登录</div>-->
                            <!--                            <div class="link">手机号登录</div>-->
                            <!--                            <div class="link">注册新账号</div>-->
                        </ASpace>
                    </div>
                </div>
            </div>
            <div class="login_bottom">
                <div>格安智能物联(深圳)有限公司 提供技术支持</div>
                <!--                <div>Copyright © 2013 - 2023. All Rights Reserved. 纳格安全 版权所有</div>-->
                <!--                <a style="color: #ffffff" href="https://beian.miit.gov.cn/" target="_blank">-->
                <!--                    ICP备案/许可证号：豫ICP备2021031662号-->
                <!--                </a>-->
            </div>
        </div>
    </div>
</template>
<script lang="ts" setup name="login">
const logoPath = import.meta.env.VITE_BASE_URL + import.meta.env.VITE_SITE_LOGIN_LOGO

const backgroundImagePath =
    import.meta.env.VITE_BASE_URL + import.meta.env.VITE_SITE_LOGIN_BACKGROUND
// const title = import.meta.env.VITE_SITE_NAME

import LoginAccount from '@/views/login/components/LoginAccount.vue'
</script>

<style scoped lang="less">
.link {
    cursor: pointer;
}

.logo {
    height: 80px;
    display: block;
}

.login_container {
    position: relative;
    width: 100vw;
    height: 100vh;
    background-size: 100% 100%;

    .login_main {
        position: absolute;
        top: 0;
        left: 0;
        bottom: 0;
        right: 0;
        background: rgba(0, 0, 0, 0.65);
        color: #ffffff;

        .login_header {
            position: absolute;
            width: 100%;
            top: 20px;
            line-height: 64px;
            padding: 0 32px;
        }

        .login_body {
            display: flex;
            align-items: center;
            justify-content: center;
            width: 100%;
            height: 100%;

            .login_form {
                border: 1px solid #000;
                padding: 32px;
                background: rgba(0, 0, 0, 0.3);
                box-shadow: rgba(255, 255, 255, 0.9) 0 0 15px; //将h-shadow,v-shadow设为0px,实现四周阴影
                .title {
                    text-align: center;
                    font-size: 26px;
                    margin-bottom: 40px;
                }

                .login_form_container {
                    width: 320px;
                    margin: 0 auto;
                }
            }
        }

        .login_bottom {
            position: absolute;
            bottom: 0;
            text-align: center;
            width: 100%;
            height: 62px;
        }
    }
}
</style>
