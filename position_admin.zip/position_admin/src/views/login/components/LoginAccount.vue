<template>
    <AForm
        autocomplete="off"
        :model="formState"
        name="basic"
        :wrapper-col="{ span: 24 }"
        @finish="onFinish"
        @finishFailed="onFinishFailed"
    >
        <AAlert :message="msg" type="error" show-icon v-if="msg" style="margin-bottom: 10px" />
        <AFormItem name="accountName" :rules="[{ required: true, message: '请输入帐号!' }]">
            <input style="display: none" type="text" name="shenmeyebushi" />
            <input style="display: none" type="password" name="shenmeyebushi" />
            <AInput
                :autofocus="false"
                placeholder="请输入账号"
                v-model:value="formState.accountName"
                size="large"
            >
                <template #prefix>
                    <UserOutlined />
                </template>
            </AInput>
        </AFormItem>

        <AFormItem name="loginPass" :rules="[{ required: true, message: '请输入登录密码!' }]">
            <AInputPassword
                size="large"
                placeholder="请输入密码"
                v-model:value="formState.loginPass"
            >
                <template #prefix>
                    <LockOutlined />
                </template>
            </AInputPassword>
        </AFormItem>

        <AFormItem name="captcha" :rules="[{ required: true, message: '请向右拖动滑块验证!' }]">
            <YxCaptcha
                ref="YxCaptchaRef"
                :captchaUrl="captchaUrl"
                :validUrl="validUrl"
                @success="success"
            ></YxCaptcha>
        </AFormItem>

        <AFormItem name="remember">
            <div class="flex justify-between text-white">
                <ACheckbox style="color: #ffffff" v-model:checked="formState.remember"
                    >记住我</ACheckbox
                >
                <!--                <div class="tip">忘记帐号/密码？</div>-->
            </div>
        </AFormItem>

        <AFormItem>
            <AButton
                type="primary"
                :disabled="disabled"
                :loading="loading"
                size="large"
                html-type="submit"
                block
            >
                登录
            </AButton>
        </AFormItem>
    </AForm>
</template>

<script setup lang="ts">
import { LockOutlined, UserOutlined } from '@ant-design/icons-vue'
import { computed, reactive, ref } from 'vue'
import router from '@/router'
import { getUserStore } from '@/store'
const captchaUrl = import.meta.env.VITE_API_URL_SYSTEM + '/v1/sys/auth/captcha'
const validUrl = import.meta.env.VITE_API_URL_SYSTEM + '/v1/sys/auth/valid'

const msg = ref('')
const loading = ref(false)

const YxCaptchaRef = ref()

interface FormState {
    accountName: string
    loginPass: string
    remember: boolean
    captcha: string
}

const userState = getUserStore()

const formState = reactive<FormState>({
    accountName: '',
    loginPass: '',
    remember: true,
    captcha: '',
})

const disabled = computed(() => {
    return !(formState.accountName && formState.loginPass && formState.captcha)
})

const success = (token: string) => {
    formState.captcha = token
}

const onFinish = () => {
    loading.value = true
    userState
        .login(formState)
        .then(() => {
            console.log('登录成功。')
            // const url = decodeURIComponent(<string>route.query?.redirect || '/')
            // window.location.href = url
            // router.push(import.meta.env.BASE_URL).then(() => {
            //     loading.value = false
            // })
            router.push('/system/user/workbench').then(() => {
                loading.value = false
            })
        })
        .catch((e) => {
            msg.value = e.msg || '登录失败'
            loading.value = false
            YxCaptchaRef.value.refresh()
        })
}
const onFinishFailed = (errorInfo: any) => {
    console.log('Failed:', errorInfo)
}
</script>

<style scoped lang="less">
.tip {
    font-size: 14px;
    color: #ffffff;
    cursor: pointer;
}
</style>
