<template>
    <div class="login_out">
        <div class="top">
            <img class="logo" alt="" :src="logoPath" />
        </div>
        <div class="content">
            <img class="login_out_icon" alt="" :src="logout" />
            <span class="login_out_tip"> 退出成功! </span>
            <AButton type="primary" @click="reLogin">重新登录</AButton>
        </div>
    </div>
</template>

<script lang="ts" setup name="logout">
import logout from '@/assets/logout.png'

const logoPath = import.meta.env.VITE_BASE_URL + import.meta.env.VITE_SITE_LOGIN_LOGO

const reLogin = () => {
    window.location.href = import.meta.env.VITE_PAGE_LOGIN
}
</script>

<style scoped lang="less">
.logo {
    height: 80px;
    display: block;
}

.login_out {
    .top {
        background-color: #108b96;
        padding: 32px;
    }
    .content {
        margin-top: 80px;
        display: flex;
        flex-direction: column;
        align-items: center;
        .login_out_icon {
            width: 300px;
            display: block;
        }
        .login_out_tip {
            margin: 20px 0;
            font-size: 30px;
        }
    }
}
</style>
