<!--默认密码设置-->
<template>
    <ACard title="默认密码设置">
        <template #extra>
            <ASpace>
                <AButton type="primary" v-if="disabled" size="small" @click="disabled = false"
                    >编辑</AButton
                >

                <AButton
                    type="primary"
                    v-if="!disabled"
                    size="small"
                    :loading="submitLoading"
                    @click="submit"
                    >保存</AButton
                >
                <AButton size="small" v-if="!disabled" @click="disabled = true">取消</AButton>
            </ASpace>
        </template>
        <AForm
            class="padding"
            ref="myFormRef"
            name="myFormRef"
            :model="formRef"
            :label-col="{ span: 5 }"
            :wrapper-col="{ span: 18 }"
        >
            <AFormItem
                label="默认密码"
                name="pass"
                :rules="[{ required: true, validator: validPass, trigger: 'change' }]"
            >
                <AInputPassword
                    :disabled="disabled"
                    autocomplete="new-password"
                    v-model:value="formRef.pass"
                    placeholder=""
                />
            </AFormItem>
        </AForm>
    </ACard>
</template>
<script setup lang="ts" name="defaultPass">
import { onMounted, ref } from 'vue'
import { getByKey, edit, save } from '@/api/system/sysSetting'
import { FormInstance, message } from 'ant-design-vue'
import { leftCover } from '@/utils/ObjectUtils'
import { Rule } from 'ant-design-vue/es/form'
import { checkPass } from '@/utils/ValidateUtils'
const submitLoading = ref(false)
const disabled = ref(true)
const myFormRef = ref<FormInstance>()
const formRef = ref<any>({
    id: '',
    pass: '',
    settingKey: 'defaultPass',
    description: '默认密码配置',
})

/**
 * 校验密码
 * @param _rule
 * @param value
 */
const validPass = async (_rule: Rule, value: string) => {
    if (!checkPass(value)) {
        return Promise.reject('密码必须字母或数字且长度8-20位')
    }
    return Promise.resolve()
}

const submit = () => {
    myFormRef.value?.validate().then(() => {
        submitLoading.value = true
        let settingValue = {} as any
        settingValue[formRef.value.settingKey] = formRef.value.pass
        if (formRef.value.id) {
            const params = {
                id: formRef.value.id,
                settingValue: JSON.stringify(settingValue),
            }
            edit(params).then((res: any) => {
                if (res.code === 1) {
                    message.success('保存成功')
                }
                submitLoading.value = false
                disabled.value = true
            })
        } else {
            const params = {
                id: formRef.value.id,
                settingKey: formRef.value.settingKey,
                settingValue: JSON.stringify(settingValue),
                description: formRef.value.description,
            }
            save(params).then((res: any) => {
                if (res.code === 1) {
                    message.success('保存成功')
                }
                submitLoading.value = false
                disabled.value = true
            })
        }
    })
}
onMounted(() => {
    getByKey({ key: formRef.value.settingKey }).then((res) => {
        if (res.code === 1) {
            const data = res.data
            leftCover(formRef.value, data)
            const settingValue = JSON.parse(data.settingValue)
            formRef.value.pass = settingValue.defaultPass
        }
    })
})
</script>
<style scoped lang="less"></style>
