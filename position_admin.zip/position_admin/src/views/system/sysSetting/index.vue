<template>
    <PageWrapper title="参数设置" sub-title="">
        <ARow :gutter="5">
            <ACol :span="12">
                <DefaultPass></DefaultPass>
            </ACol>
        </ARow>
    </PageWrapper>
</template>
<!--路由地址：/system/sysSetting/index  ,组件名称：sysSettingIndex	-->
<script setup lang="ts" name="sysSettingIndex">
import { onMounted } from 'vue'
import DefaultPass from './defaultPass.vue'
// import { getList } from '@/api/common'
// const rows = ref([])
onMounted(() => {
    // getList(`${import.meta.env.VITE_API_URL_SYSTEM}/v1/sys/setting/getList`, {}).then((res) => {
    //     console.log(res)
    //     if (res.code === 1) {
    //         rows.value = res.data
    //     }
    // })
})
</script>

<style scoped lang="less"></style>
