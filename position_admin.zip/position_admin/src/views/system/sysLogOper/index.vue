<template>
    <PageWrapper title="操作日志" sub-title="">
        <MyTablePage
            ref="MyTablePageRef"
            :search-item="searchItem"
            :url="dataUrl"
            :columns="columns"
            :action="action"
            :ellipsis="1"
            show-index
            pagination
            selection="checkbox"
        >
            <template #tools>
                <AButton v-permission="'sysLogOperDelete'" type="danger" @click="deletes()">
                    <template #icon>
                        <DeleteOutlined />
                    </template>
                    批量删除
                </AButton>
                <AButton v-permission="'sysLogOperClear'" type="danger" @click="handelClear">
                    <template #icon>
                        <DeleteOutlined />
                    </template>
                    清空记录
                </AButton>
                <AButton
                    v-permission="'sysLogOperExport'"
                    type="success"
                    @click="MyTablePageRef.handleExport('系统操作日志')"
                >
                    <template #icon>
                        <DownloadOutlined />
                    </template>
                    导出
                </AButton>
            </template>
        </MyTablePage>
    </PageWrapper>
</template>
<!--路由地址：/system/sysLogOper/index ,组件名称：sysLogOperIndex	-->
<script setup lang="ts" name="sysLogOperIndex">
import { onMounted, ref } from 'vue'
import { DeleteOutlined, DownloadOutlined } from '@ant-design/icons-vue'
import { message, Modal } from 'ant-design-vue'
import { cloneDeep } from 'lodash-es'
import { del, clear } from '@/api/system/sysLogOper'

const MyTablePageRef = ref()
const dataUrl = `${import.meta.env.VITE_API_URL_SYSTEM}/v1/sys/log/oper/getList`

/*列配置 api https://itvita.gitee.io/liuyunxi-antd-extend/#/YxTable*/
const columns = ref<any[]>([
    {
        title: '操作人姓名',
        dataIndex: 'userName',
        hidden: false,
    },
    {
        title: '操作描述',
        dataIndex: 'title',
        hidden: false,
    },
    {
        title: '操作IP',
        dataIndex: 'ip',
        hidden: false,
    },
    {
        title: '操作地点',
        dataIndex: 'address',
        hidden: false,
    },
    {
        title: '操作系统',
        dataIndex: 'os',
        hidden: false,
    },
    {
        title: '操作浏览器',
        dataIndex: 'browser',
        hidden: false,
    },
    {
        title: '请求地址',
        dataIndex: 'actionUrl',
        hidden: true,
    },
    {
        title: '请求方式',
        dataIndex: 'requestMethod',
        hidden: true,
    },
    {
        title: '操作方法',
        dataIndex: 'classPath',
        hidden: true,
    },
    {
        title: '请求参数',
        dataIndex: 'params',
        hidden: true,
        width: 300,
    },
    {
        title: '响应参数',
        dataIndex: 'result',
        hidden: true,
    },
    {
        title: '操作状态',
        dataIndex: 'state',
        hidden: false,
        formatter: {
            type: 'tag',
            format: (row: any): any => {
                return {
                    value: row.state === '1' ? '成功' : '失败',
                    color: row.state === '1' ? 'success' : 'error',
                }
            },
        },
    },
    {
        title: '操作时间',
        width: 180,
        dataIndex: 'createdTime',
    },
])
/*搜索条配置 api https://itvita.gitee.io/liuyunxi-antd-extend/#/YxSearch*/
const searchItem = ref<any[]>([
    {
        type: 'text',
        key: 'userName',
        label: '操作人姓名',
        value: '',
        placeholder: '',
    },
    {
        type: 'text',
        key: 'title',
        label: '操作描述',
        value: '',
        placeholder: '',
    },
    {
        type: 'select',
        key: 'state',
        label: '操作状态',
        value: '',
        placeholder: '',
        options: [
            { label: '成功', value: '1' },
            { label: '失败', value: '0' },
        ],
    },
])
/**
 * 批量删除方法
 * @param ids id数组
 */
const deletes = (ids?: string[]) => {
    if (ids === undefined) {
        const { selectedRowKeys } = MyTablePageRef.value.getSelection()
        ids = cloneDeep(selectedRowKeys)
    }
    if (!ids || ids?.length < 1) {
        Modal.warning({
            title: '请先选择删除项',
        })
        return
    }
    Modal.confirm({
        title: '确定删除？',
        content: '删除后将无法恢复',
        okType: 'danger',
        onOk() {
            del(ids).then((res: any) => {
                if (res.code === 1) {
                    message.success('删除成功')
                    MyTablePageRef.value.search()
                }
            })
        },
    })
}
/**
 * 清空操作日志
 */
const handelClear = () => {
    Modal.confirm({
        title: '确定清空？',
        content: '清空后将无法恢复',
        okType: 'danger',
        onOk() {
            clear().then((res: any) => {
                if (res.code === 1) {
                    message.success('清空成功')
                    MyTablePageRef.value.search()
                }
            })
        },
    })
}
/*table 操作列配置*/
const action = ref({
    width: 200,
    fixed: 'right',
    buttons: [
        {
            title: '详情',
            icon: 'iconfont icon-caidan',
            event: (row: any) => {
                MyTablePageRef.value.showDetail(row)
            },
        },
        {
            title: '删除',
            color: '#f12424', // primary,success,warn,danger,info
            icon: 'iconfont icon-shanchu',
            permission: 'sysLogOperDelete',
            event: (row: any) => {
                deletes([row.id])
            },
        },
    ],
})

/**
 * 挂载，页面初始化后执行
 */
onMounted(() => {
    MyTablePageRef.value.search()
})
</script>

<style scoped lang="less"></style>
