<template>
    <YxModal
        ref="YxModalRef"
        :title="modalTitle"
        v-model:visible="visible"
        @ok="onSubmit"
        @cancel="onCancel"
        :submit-loading="submitLoading"
    >
        <AForm
            class="padding"
            ref="myFormRef"
            name="myFormRef"
            :model="formRef"
            :label-col="{ span: 4 }"
            :wrapper-col="{ span: 14 }"
        >
            <AFormItem label="部门" name="deptCode" :rules="[{ required: true }]">
                <!--tree-default-expand-all-->
                <ATreeSelect
                    v-model:value="formRef.deptCode"
                    v-model:searchValue="deptCodeSearchValue"
                    show-search
                    style="width: 100%"
                    treeNodeFilterProp="title"
                    :dropdown-style="{ maxHeight: '400px', overflow: 'auto' }"
                    placeholder=""
                    allow-clear
                    :tree-data="deptCodeOptions"
                    :fieldNames="{
                        children: 'children',
                        label: 'title',
                        key: 'id',
                        value: 'code',
                    }"
                >
                    <template #title="{ title }">
                        <template
                            v-for="(fragment, i) in (title || '')
                                .toString()
                                .split(
                                    new RegExp(
                                        `(?<=${deptCodeSearchValue})|(?=${deptCodeSearchValue})`,
                                        'i',
                                    ),
                                )"
                        >
                            <span
                                v-if="fragment.toLowerCase() === deptCodeSearchValue.toLowerCase()"
                                :key="i"
                                style="color: #08c"
                            >
                                {{ fragment }}
                            </span>
                            <template v-else>{{ fragment }}</template>
                        </template>
                    </template>
                </ATreeSelect>
            </AFormItem>

            <AFormItem
                label="帐号"
                name="accountName"
                :rules="[{ max: 20, message: '必填；最大长度20', required: true }]"
            >
                <AInput v-model:value="formRef.accountName" placeholder="请输入帐号"></AInput>
            </AFormItem>

            <AFormItem
                label="姓名"
                name="userName"
                :rules="[{ max: 20, message: '必填；最大长度20', required: true }]"
            >
                <AInput v-model:value="formRef.userName" placeholder=""></AInput>
            </AFormItem>

            <AFormItem
                label="手机号"
                name="phoneNumber"
                :rules="[
                    {
                        len: 11,
                        message: '请输入正确手机号',
                        pattern: '^1[3|4|5|6|7|8|9]\\d{9}$',
                        required: true,
                    },
                ]"
            >
                <AInput v-model:value="formRef.phoneNumber" placeholder=""></AInput>
            </AFormItem>
            <AFormItem
                label="角色"
                name="roleIds"
                :disabled="true"
                :rules="[{ message: '请选择角色', required: true }]"
            >
                <div style="color: red" v-if="rolesOptions.length < 1">请先维护角色</div>
                <ACheckboxGroup v-else v-model:value="formRef.roleIds" :options="rolesOptions" />
            </AFormItem>
            <AFormItem
                label="性别"
                name="sex"
                extra=""
                :rules="[{ message: '必填', required: true }]"
            >
                <ARadioGroup
                    v-model:value="formRef.sex"
                    :options="[
                        { label: '女', value: '0' },
                        { label: '男', value: '1' },
                    ]"
                ></ARadioGroup>
            </AFormItem>
            <AFormItem
                label="出生日期"
                name="birthday"
                extra=""
                :rules="[{ message: '必填', required: true }]"
            >
                <ADatePicker v-model:value="formRef.birthday" />
            </AFormItem>
            <AFormItem
                label="邮箱"
                name="email"
                :rules="[
                    {
                        message: '请输入正确邮箱地址',
                        pattern: '^[a-zA-Z0-9_-]+@[a-zA-Z0-9_-]+(\\.[a-zA-Z0-9_-]+)+$',
                    },
                ]"
            >
                <AInput v-model:value="formRef.email" placeholder=""></AInput>
            </AFormItem>

            <AFormItem
                label="居住地址"
                name="address"
                :rules="[
                    {
                        message: '最大长度200',
                        max: 200,
                    },
                ]"
            >
                <ATextarea v-model:value="formRef.address" placeholder="" :rows="3"></ATextarea>
            </AFormItem>

            <AFormItem
                label="状态"
                name="state"
                :rules="[{ message: '请选择状态', required: true }]"
            >
                <ARadioGroup placeholder="" v-model:value="formRef.state" :options="stateOptions" />
            </AFormItem>
        </AForm>
    </YxModal>
</template>
<!--添加路由地址：/system/sysUser/add，修改路由地址：/system/sysUser/edit，组件地址：/system/sysUser/edit-->
<script setup lang="ts">
import { FormInstance, message, Modal } from 'ant-design-vue'
import { ref } from 'vue'
import { save, edit, get } from '@/api/system/sysUser'
import { cloneDeep } from 'lodash-es'
import { leftCover } from '@/utils/ObjectUtils'

/**
 * 基础数据定义
 */
const visible = ref(false)
const submitLoading = ref(false)
const modalTitle = ref('添加学生表')

const myFormRef = ref<FormInstance>()

const defaultForm = {
    id: null, //主键ID
    deptCode: '', //部门编码
    accountName: '', //帐号
    userName: '', //姓名
    phoneNumber: '', //手机号
    email: '', //邮箱
    sex: '-1', //性别;1男，0女，-1未知
    birthday: null, //出生年月
    state: '1', //状态;1启用，0禁用
    roleIds: [], //角色
    address: '', //居住地址
    type: '2', //类型1.教师，2.学生 3.临时人员
}

const formRef = ref<any>({
    ...defaultForm,
})

/**
 * 部门编码选项
 */
import { getList } from '@/api/common'
import dayjs from 'dayjs'

const deptCodeOptions = ref([])
/**
 * 角色选项
 */
const rolesOptions = ref<any[]>([])
/**
 * 树形下拉搜索值
 */
const deptCodeSearchValue = ref('')

/**
 * 状态;1启用，0禁用选项
 */
const stateOptions = ref([
    { label: '启用', value: '1' },
    { label: '禁用', value: '0' },
])

/**
 * 显示弹窗
 */
const show = (params?: any) => {
    params = params || {}
    visible.value = true
    /**
     * 初始参数
     */
    formRef.value = Object.assign({}, { ...defaultForm })
    leftCover(formRef.value, params || {})
    if (params.id) {
        modalTitle.value = '编辑学生表'
        get({ id: params.id }).then((res: any) => {
            const data = parseParam(res.data)
            leftCover(formRef.value, data)
        })
    }

    /**查询部门编码数据*/
    getList(`${import.meta.env.VITE_API_URL_SYSTEM}/v1/sys/department/getTree?serve=college`).then(
        (res) => {
            if (res.code === 1) {
                deptCodeOptions.value = res.data
            }
        },
    )
    /**查询角色选项*/
    getList(import.meta.env.VITE_API_URL_SYSTEM + '/v1/sys/role/getList', {
        pageNumber: -1,
        pageSize: -1,
    }).then((res) => {
        if (res.code === 1) {
            const options = [] as any[]
            res.data.rows.forEach((d: any) => {
                if (d.roleCode === 'Student') {
                    options.push({
                        label: d.title,
                        value: d.id,
                        disabled: true,
                    })
                    formRef.value.roleIds.push(d.id)
                }
            })
            rolesOptions.value = options
        }
    })
}
defineExpose({ show })

/**
 * 接收方法
 */
const emits = defineEmits(['ok'])
/**
 * 提交方法
 */
const onSubmit = () => {
    myFormRef.value?.validate().then(() => {
        submitLoading.value = true
        const params = cloneDeep(formRef.value)
        if (params.id) {
            edit(buildParam(params)).then((res: any) => {
                if (res.code === 1) {
                    emits('ok')
                    message.success('提交成功')
                    onCancel()
                }
                submitLoading.value = false
            })
        } else {
            save(buildParam(params)).then((res: any) => {
                if (res.code === 1) {
                    emits('ok')
                    Modal.success({
                        title: '添加成功',
                        content: `默认密码：${res.data}，请牢记！`,
                    })
                    onCancel()
                }
                submitLoading.value = false
            })
        }
    })
}

const buildParam = (data: any) => {
    const tdata = cloneDeep(data)
    if (tdata.birthday) {
        tdata.birthday = tdata.birthday.format('YYYY-MM-DD')
    } else {
        tdata.birthday = null
    }
    tdata.postArray = JSON.stringify(tdata.postArray || [])
    return tdata
}
const parseParam = (data: any) => {
    const tdata = cloneDeep(data)
    if (tdata.birthday) {
        tdata.birthday = dayjs(tdata.birthday)
    } else {
        tdata.birthday = null
    }
    tdata.postArray = JSON.parse(tdata.postArray || '[]')
    return tdata
}

/**
 * 关闭弹窗
 */
const onCancel = () => {
    myFormRef.value?.resetFields()
    visible.value = false
}
</script>

<style scoped lang="less"></style>
