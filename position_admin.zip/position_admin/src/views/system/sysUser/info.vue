<template>
    <PageWrapper title="个人资料" sub-title="">
        <template #extra>
            <AButton type="primary" :loading="submitLoading" @click="onSubmit">保存</AButton>
        </template>
        <AForm
            ref="myFormRef"
            name="myFormRef"
            :model="formRef"
            :label-col="{ span: 4 }"
            :wrapper-col="{ span: 14 }"
        >
            <AFormItem
                label="帐号"
                name="accountName"
                :rules="[{ max: 20, message: '必填；最大长度20', required: true }]"
            >
                <AInput v-model:value="formRef.accountName" placeholder="请输入帐号"></AInput>
            </AFormItem>

            <AFormItem
                label="姓名"
                name="userName"
                :rules="[{ max: 20, message: '必填；最大长度20', required: true }]"
            >
                <AInput v-model:value="formRef.userName" placeholder=""></AInput>
            </AFormItem>

            <AFormItem
                label="手机号"
                name="phoneNumber"
                :rules="[
                    {
                        len: 11,
                        message: '请输入正确手机号',
                        pattern: '^1[3|4|5|6|7|8|9]\\d{9}$',
                        required: true,
                    },
                ]"
            >
                <AInput v-model:value="formRef.phoneNumber" placeholder=""></AInput>
            </AFormItem>

            <AFormItem
                label="身份证号"
                name="idCard"
                :rules="[
                    {
                        message: '身份证号格式有误',
                        pattern:
                            '^\\d{6}(18|19|20)?\\d{2}(0[1-9]|1[12])(0[1-9]|[12]\\d|3[01])\\d{3}(\\d|X)$',
                    },
                ]"
            >
                <AInput
                    v-model:value="formRef.idCard"
                    @change="idCardChange"
                    placeholder=""
                ></AInput>
            </AFormItem>
            <AFormItem
                label="邮箱"
                name="email"
                :rules="[
                    {
                        message: '请输入正确邮箱地址',
                        pattern: '^[a-zA-Z0-9_-]+@[a-zA-Z0-9_-]+(\\.[a-zA-Z0-9_-]+)+$',
                    },
                ]"
            >
                <AInput v-model:value="formRef.email" placeholder=""></AInput>
            </AFormItem>

            <AFormItem
                label="居住地址"
                name="address"
                :rules="[
                    {
                        message: '最大长度200',
                        max: 200,
                    },
                ]"
            >
                <ATextarea v-model:value="formRef.address" placeholder="" :rows="3"></ATextarea>
            </AFormItem>
        </AForm>
    </PageWrapper>
</template>
<!--添加路由地址：/system/sysUser/add，修改路由地址：/system/sysUser/edit，组件地址：/system/sysUser/edit-->
<script setup lang="ts">
import { FormInstance, message } from 'ant-design-vue'
import { onMounted, ref } from 'vue'
import { getUserStore } from '@/store'
const userStore = getUserStore()
import { save, edit, get } from '@/api/system/sysUser'
import { cloneDeep } from 'lodash-es'
import { leftCover } from '@/utils/ObjectUtils'
import { getBirthday, getSex } from '@/utils/common'
/**
 * 基础数据定义
 */
const submitLoading = ref(false)

const myFormRef = ref<FormInstance>()
const formRef = ref<any>({
    id: null, //主键ID
    accountName: '', //帐号
    userName: '', //姓名
    idCard: '', //身份证号
    phoneNumber: '', //手机号
    email: '', //邮箱
    sex: '', //性别;1男，0女，-1未知
    birthday: '', //出生年月
    address: '', //居住地址
})

/**
 * 身份证改变
 */
const idCardChange = () => {
    formRef.value.birthday = getBirthday(formRef.value.idCard)
    formRef.value.sex = getSex(formRef.value.idCard)
}

onMounted(() => {
    get({ id: userStore.userInfo.id }).then((res: any) => {
        console.log(res)
        const data = res.data
        formRef.value = leftCover(formRef.value, data)
    })
})

/**
 * 接收方法
 */
const emits = defineEmits(['ok'])
/**
 * 提交方法
 */
const onSubmit = () => {
    myFormRef.value?.validate().then(() => {
        submitLoading.value = true
        const params = cloneDeep(formRef.value)
        params.postArray = JSON.stringify(params.postArray)
        if (params.id) {
            edit(params).then((res: any) => {
                if (res.code === 1) {
                    emits('ok')
                    message.success('提交成功')
                }
                submitLoading.value = false
            })
        } else {
            save(params).then((res: any) => {
                if (res.code === 1) {
                    emits('ok')
                    message.success('提交成功')
                }
                submitLoading.value = false
            })
        }
    })
}
</script>

<style scoped lang="less"></style>
