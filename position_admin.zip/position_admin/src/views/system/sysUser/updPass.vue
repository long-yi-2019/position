<template>
    <PageWrapper title="修改密码" sub-title="定期修改密码会使帐号更加安全哦~">
        <template #extra>
            <AButton type="primary" :loading="submitLoading" @click="onSubmit">保存</AButton>
        </template>
        <AForm
            ref="myFormRef"
            name="myFormRef"
            :model="formRef"
            :label-col="{ span: 4 }"
            :wrapper-col="{ span: 14 }"
        >
            <AFormItem
                label="原密码"
                name="oldPass"
                :rules="[{ required: true, message: '原密码不能为空', trigger: 'change' }]"
            >
                <AInputPassword
                    autocomplete="new-password"
                    v-model:value="formRef.oldPass"
                    placeholder=""
                />
            </AFormItem>
            <AFormItem
                label="新密码"
                name="newPass"
                :rules="[{ required: true, validator: validPass, trigger: 'change' }]"
            >
                <AInputPassword
                    autocomplete="new-password"
                    v-model:value="formRef.newPass"
                    placeholder=""
                />
            </AFormItem>
            <AFormItem
                label="确认密码"
                name="newPass1"
                :rules="[{ required: true, validator: validPass1, trigger: 'change' }]"
            >
                <AInputPassword
                    autocomplete="new-password"
                    v-model:value="formRef.newPass1"
                    placeholder=""
                />
            </AFormItem>
        </AForm>
    </PageWrapper>
</template>
<!--添加路由地址：/system/sysUser/add，修改路由地址：/system/sysUser/edit，组件地址：/system/sysUser/edit-->
<script setup lang="ts">
import { FormInstance, message } from 'ant-design-vue'
import type { Rule } from 'ant-design-vue/es/form'
import { ref } from 'vue'
import { updPass } from '@/api/system/sysUser'
import { checkPass } from '@/utils/ValidateUtils'
const submitLoading = ref(false)
const myFormRef = ref<FormInstance>()
const formRef = ref<any>({
    oldPass: '',
    newPass: '',
    newPass1: '',
})

/**
 * 提交方法
 */
const onSubmit = () => {
    myFormRef.value?.validate().then(() => {
        submitLoading.value = true
        const params = {
            oldPass: formRef.value.oldPass,
            newPass: formRef.value.newPass,
        }
        updPass(params).then((res: any) => {
            if (res.code === 1) {
                message.success('修改成功')
                onCancel()
            }
            submitLoading.value = false
        })
    })
}
/**
 * 重置
 */
const onCancel = () => {
    myFormRef.value?.resetFields()
}
/**
 * 校验密码
 * @param _rule
 * @param value
 */
const validPass = async (_rule: Rule, value: string) => {
    if (!checkPass(value)) {
        return Promise.reject('密码必须字母或数字且长度8-20位')
    }
    return Promise.resolve()
}
/**
 * 校验确认密码
 * @param _rule
 * @param value
 */
const validPass1 = async (_rule: Rule, value: string) => {
    if (value !== formRef.value.newPass) {
        return Promise.reject('新密码不一致')
    }
    return Promise.resolve()
}
</script>

<style scoped lang="less"></style>
