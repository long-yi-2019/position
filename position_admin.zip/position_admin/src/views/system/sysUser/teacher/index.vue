<template>
    <PageWrapper title="教师管理" sub-title="">
        <MyTreeTablePage
            ref="MyTreeTablePageRef"
            :search-item="searchItem"
            :url="dataUrl"
            :columns="columns"
            :action="action"
            :ellipsis="1"
            pagination
            show-index
            selection="checkbox"
            :tree="treeConfig"
        >
            <template #tools>
                <AButton v-permission="'sysUserAdd'" type="primary" @click="handelAdd()">
                    <template #icon>
                        <PlusOutlined />
                    </template>
                    添加
                </AButton>
                <!--                <AButton v-permission="'sysUserAdd'" type="primary" @click="handelImport()">-->
                <!--                    <template #icon>-->
                <!--                        <PlusOutlined />-->
                <!--                    </template>-->
                <!--                    导入-->
                <!--                </AButton>-->
                <AButton v-permission="'sysUserDelete'" type="danger" @click="handelDelete()">
                    <template #icon>
                        <DeleteOutlined />
                    </template>
                    批量删除
                </AButton>
                <AButton
                    v-permission="'sysUserExport'"
                    type="success"
                    @click="MyTreeTablePageRef.handleExport('教师清单')"
                >
                    <template #icon>
                        <DownloadOutlined />
                    </template>
                    导出
                </AButton>
            </template>
        </MyTreeTablePage>
        <Edit ref="EditRef" @ok="MyTreeTablePageRef.init()"></Edit>
    </PageWrapper>
</template>
<!--路由地址：/system/sysUser/index ,组件名称：sysUserIndex	-->
<script setup lang="ts" name="sysUserIndex">
import { PlusOutlined, DeleteOutlined, DownloadOutlined } from '@ant-design/icons-vue'
import { onMounted, reactive, ref } from 'vue'
import { message, Modal } from 'ant-design-vue'
import { cloneDeep } from 'lodash-es'
import { del } from '@/api/system/sysUser'

import Edit from './edit.vue'

const EditRef = ref()

const MyTreeTablePageRef = ref()
const dataUrl = `${import.meta.env.VITE_API_URL_SYSTEM}/v1/sys/user/getList?type=1`
const selectNode = ref({
    id: '0',
    code: '1',
    name: '跟目录',
})

/*列配置 api https://itvita.gitee.io/liuyunxi-antd-extend/#/YxTable*/
const columns = ref([
    {
        title: '部门/院系',
        dataIndex: 'deptCode',
        hidden: false,
        align: 'left',
        fixed: 'none',
        width: 300,
    },
    {
        title: '帐号',
        dataIndex: 'accountName',
        hidden: false,
        sorter: true,
        align: 'left',
        fixed: 'none',
    },
    {
        title: '姓名',
        dataIndex: 'userName',
        hidden: false,
        align: 'left',
        fixed: 'none',
        sorter: true,
    },
    {
        title: '身份证号',
        dataIndex: 'idCard',
        hidden: true,
        align: 'left',
        fixed: 'none',
        sorter: true,
    },
    {
        title: '手机号',
        dataIndex: 'phoneNumber',
        hidden: false,
        sorter: true,
        align: 'left',
        fixed: 'none',
    },
    {
        title: '邮箱',
        dataIndex: 'email',
        hidden: true,
        align: 'left',
        fixed: 'none',
    },
    {
        title: '性别',
        dataIndex: 'sex',
        hidden: true,
        align: 'left',
        fixed: 'none',
        formatter: {
            type: 'text',
            format: (row: any) => {
                if (row.sex === '1') {
                    return {
                        value: '男',
                    }
                } else if (row.sex === '0') {
                    return {
                        value: '女',
                    }
                } else {
                    return {
                        value: '未知',
                    }
                }
            },
        },
    },
    {
        title: '出生年月',
        dataIndex: 'birthday',
        hidden: true,
        align: 'left',
        fixed: 'none',
    },
    {
        title: '最后登录IP',
        dataIndex: 'loginIp',
        hidden: false,
        align: 'left',
        fixed: 'none',
    },
    {
        title: '最后登录时间',
        dataIndex: 'loginTime',
        hidden: false,
        align: 'left',
        fixed: 'none',
        width: 200,
    },
    {
        title: '状态',
        dataIndex: 'state',
        hidden: false,
        align: 'left',
        fixed: 'none',
        formatter: {
            type: 'tag',
            format: (row: any) => {
                if (row.state === '1') {
                    return {
                        value: '启用',
                        color: 'success',
                    }
                } else {
                    return {
                        value: '禁用',
                        color: 'error',
                    }
                }
            },
        },
    },
])

/*搜索条配置 api https://itvita.gitee.io/liuyunxi-antd-extend/#/YxSearch*/
const searchItem = ref([
    {
        type: 'text',
        key: 'userName',
        label: '姓名',
        value: '',
        placeholder: '',
    },
    {
        type: 'text',
        key: 'phoneNumber',
        label: '手机号',
        value: '',
        placeholder: '',
    },
    {
        type: 'select',
        key: 'state',
        label: '状态',
        value: '',
        placeholder: '',
        options: [
            {
                label: '启用',
                value: '1',
            },
            {
                label: '禁用',
                value: '0',
            },
        ],
    },
])

/**
 * 添加
 */
const handelAdd = () => {
    EditRef.value.show({ deptCode: selectNode.value.code })
}

// const handelImport = () => {
//     MyTreeTablePageRef.value.handleImport({
//         uploadUrl: `${import.meta.env.VITE_API_URL_SYSTEM}/v1/sys/user/importUser?type=1`,
//         templateUrl: `${import.meta.env.VITE_API_URL_SYSTEM}/v1/sys/user/downLoadTemplate`,
//         templateName: '教师导入模板.xls',
//     })
// }

/**
 * 删除
 * @param ids id数组
 */
const handelDelete = (ids?: string[]) => {
    if (ids === undefined) {
        const { selectedRowKeys } = MyTreeTablePageRef.value.getSelection()
        ids = cloneDeep(selectedRowKeys)
    }
    if (!ids || ids?.length < 1) {
        Modal.warning({
            title: '请先选择删除项！',
        })
        return
    }
    Modal.confirm({
        title: '确定删除？',
        content: '删除后将无法恢复',
        okType: 'danger',
        onOk() {
            del(ids).then((res: any) => {
                if (res.code === 1) {
                    message.success('删除成功')
                    MyTreeTablePageRef.value.init()
                }
            })
        },
    })
}

/*操作列配置*/
const action = ref({
    width: 200,
    fixed: 'right',
    buttons: [
        {
            title: '详情',
            icon: 'iconfont icon-caidan',
            event: (row: any) => {
                MyTreeTablePageRef.value.showDetail(row)
            },
        },
        {
            title: '编辑',
            icon: 'iconfont icon-bianji',
            color: '#28A6FF',
            permission: 'sysUserEdit',
            event: (row: any) => {
                EditRef.value.show({ id: row.id })
            },
        },
        {
            title: '删除',
            color: '#f12424', // primary,success,warn,danger,info
            icon: 'iconfont icon-shanchu',
            permission: 'sysUserDelete',
            event: (row: any) => {
                handelDelete([row.id])
            },
        },
    ],
})

/*树形配置*/
const treeConfig = reactive({
    url: `${import.meta.env.VITE_API_URL_SYSTEM}/v1/sys/department/getZtree`,
    drag: false,
    add: false,
    edit: false,
    remove: false,
    handelClick: (treeNodes: any) => {
        selectNode.value = treeNodes
        MyTreeTablePageRef.value.search()
    },
})

/**
 * 挂载，页面初始化后执行
 */
onMounted(() => {
    MyTreeTablePageRef.value.init()
})
</script>

<style scoped lang="less"></style>
