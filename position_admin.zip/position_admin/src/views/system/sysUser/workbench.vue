<template>
    <div class="padding-lg layout__content">
        <ARow :gutter="16">
            <ACol :span="24">
                <ACard class="margin-bottom-xs">
                    <div class="flex justify-between align-center">
                        <div class="flex align-center">
                            <div>
                                <MyAvatar :src="myInfo.avatar"></MyAvatar>
                            </div>
                            <div class="margin-left-sm">
                                <ATypographyTitle :level="4">
                                    {{ welcome() }},
                                    {{ myInfo.userName }}
                                    <ATypographyText mark>{{
                                        myInfo.roles?.join(',')
                                    }}</ATypographyText>
                                </ATypographyTitle>

                                <ATypographyText>
                                    {{ myInfo.departmentName }}
                                </ATypographyText>
                            </div>
                        </div>
                    </div>
                </ACard>

                <ACard title="最近访问" class="margin-bottom-xs">
                    <ASelect
                        size="large"
                        v-model:value="searchValue"
                        show-search
                        placeholder="搜索菜单名称"
                        style="width: 100%"
                        :default-active-first-option="false"
                        :show-arrow="false"
                        :filter-option="false"
                        :not-found-content="null"
                        :options="searchOptions"
                        @search="handleSearch"
                        @change="handleChange"
                    ></ASelect>
                    <ASpace class="flex-wrap margin-top-md">
                        <ACard
                            class="margin-bottom-md pointer"
                            :body-style="{ padding: '8px 20px' }"
                            v-for="item in historyList"
                            :key="item.id"
                            @click="goUrl(item)"
                        >
                            <i class="iconfont" :class="item.icon"></i>
                            <span class="margin-left-xss">{{ item.title }}</span>
                        </ACard>
                    </ASpace>
                </ACard>

                <ACard v-if="false" title="我的待办"> 各种待办数据什么的</ACard>
            </ACol>
        </ARow>
    </div>
</template>
<script lang="ts" setup>
import MyAvatar from '@/components/MyAvatar.vue'
import { welcome } from '@/utils/Common'
import { getLatelyRouter } from '@/api/system/sysUser'
import { useRouter } from 'vue-router'
const router = useRouter()
import { getUserStore } from '@/store'
import { onBeforeMount, onMounted, ref } from 'vue'
import { debounce } from 'lodash-es'
import { getList } from '@/api/platform/sysHelper'
import { usePermissionStore } from '@/store'

const userStore = getUserStore()
const myInfo = ref({
    avatar: '',
    userName: '',
    roles: [],
    departmentName: '',
})
// const siteName = import.meta.env.VITE_SITE_NAME
const goUrl = (item) => {
    window.location.href = item.path
}

/**
 * 路由搜索
 */
const searchValue = ref()
const searchOptions = ref([])
const handleChange = (val: string) => {
    router.push(val).then(() => {})
}
let lastFetchId = 0
const handleSearch = debounce((value: string) => {
    if (value == '') {
        return
    }
    lastFetchId += 1
    const fetchId = lastFetchId
    searchOptions.value = []
    if (fetchId !== lastFetchId) {
        return
    }
    const data = [] as any
    router.getRoutes().forEach((r: any) => {
        try {
            if (
                r.meta?.title?.toLowerCase().indexOf(value.toLowerCase()) > -1 ||
                r.path.toLowerCase().indexOf(value.toLowerCase()) > -1
            ) {
                data.push({
                    label: `${r.meta.title}`,
                    value: `${r.path}`,
                })
            }
        } catch (e) {
            console.error(r)
        }
    })
    searchOptions.value = data
}, 300)

onBeforeMount(() => {})
/**
 * 历史访问路由
 */
const historyList = ref<any>([])
/**
 * 帮助文档列表
 */
const helperList = ref([])
onMounted(() => {
    myInfo.value = userStore.userInfo
    getLatelyRouter().then((res) => {
        if (res.code === 1) {
            filterHistory(res.data)
        }
    })
    getList({ pageSize: -1 }).then((res) => {
        if (res.code === 1) {
            helperList.value = res.data.rows
        }
    })
})

const filterHistory = (resData) => {
    const permission = usePermissionStore()
    // console.log('打印allMenu', permission.allMenu)
    // console.log('打印historyList.value', historyList.value)
    let arr = [] as any
    resData.forEach((item: any) => {
        const tmpArr = permission.allMenu.filter((ele: any) => ele.title === item.title)
        if (tmpArr && tmpArr.length > 0) {
            arr.push(item)
        }
    })
    historyList.value = []
    historyList.value.push(resData[0])
    historyList.value.push(...arr)
}
</script>
<style lang="less" scoped>
@import '@/theme/theme.less';
.layout__content {
    position: relative;
    height: calc(100vh - 95px);
    overflow: auto;
}
.icon-favorfill {
    color: @primary-7;
}
.remark {
    font-size: 12px;
    font-weight: 500;
    color: @text-color-secondary;
}
</style>
