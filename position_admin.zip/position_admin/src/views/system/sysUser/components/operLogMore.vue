<template>
    <ADrawer width="70%" v-model:visible="visible" title="操作日志" placement="right">
        <MyTablePage
            ref="MyTablePageRef"
            :search-item="searchItem"
            :url="dataUrl"
            :ellipsis="1"
            :columns="columns"
            show-index
            pagination
            :height="-200"
            :showTools="false"
        >
        </MyTablePage>
    </ADrawer>
</template>
<!--路由地址：/system/sysLogOper/index ,组件名称：sysLogOperIndex	-->
<script setup lang="ts" name="sysLogOperIndex">
import { nextTick, onMounted, ref } from 'vue'
import { getUserStore } from '@/store'
const visible = ref()
const MyTablePageRef = ref()
const userStore = getUserStore()
const dataUrl = `${import.meta.env.VITE_API_URL_SYSTEM}/v1/sys/log/oper/getList?createdBy=${
    userStore.userInfo.id
}`
const show = () => {
    visible.value = true
    nextTick(() => {
        MyTablePageRef.value.search()
    })
}
defineExpose({ show })
/*搜索条配置 api https://itvita.gitee.io/liuyunxi-antd-extend/#/YxSearch*/
const searchItem = ref<any[]>([
    {
        type: 'text',
        key: 'title',
        label: '操作描述',
        value: '',
        placeholder: '',
    },
    {
        type: 'select',
        key: 'state',
        label: '操作状态',
        value: '',
        placeholder: '',
        options: [
            { label: '成功', value: '1' },
            { label: '失败', value: '0' },
        ],
    },
])

/*列配置 api https://itvita.gitee.io/liuyunxi-antd-extend/#/YxTable*/
const columns = ref<any[]>([
    {
        title: '操作描述',
        dataIndex: 'title',
        width: 200,
        hidden: false,
    },
    {
        title: '操作IP',
        dataIndex: 'ip',
        width: 120,
        hidden: false,
    },
    {
        title: '操作地点',
        dataIndex: 'address',
        hidden: false,
    },
    {
        title: '操作系统',
        dataIndex: 'os',
        hidden: false,
    },
    {
        title: '操作浏览器',
        dataIndex: 'browser',
        hidden: false,
    },
    {
        title: '请求地址',
        dataIndex: 'actionUrl',
        hidden: true,
    },
    {
        title: '请求方式',
        dataIndex: 'requestMethod',
        hidden: true,
    },
    {
        title: '操作方法',
        dataIndex: 'classPath',
        hidden: true,
    },
    {
        title: '请求参数',
        dataIndex: 'params',
        hidden: true,
    },
    {
        title: '响应参数',
        dataIndex: 'result',
        hidden: true,
    },
    {
        title: '操作状态',
        dataIndex: 'state',
        hidden: false,
        width: 70,
        formatter: {
            type: 'tag',
            format: (row: any): any => {
                return {
                    value: row.state === '1' ? '成功' : '失败',
                    color: row.state === '1' ? 'success' : 'error',
                }
            },
        },
    },
    {
        title: '操作时间',
        width: 150,
        dataIndex: 'createdTime',
    },
])
/**
 * 挂载，页面初始化后执行
 */
onMounted(() => {})
</script>

<style scoped lang="less"></style>
