<template>
    <ADrawer width="70%" v-model:visible="visible" title="登录日志" placement="right">
        <MyTablePage
            ref="MyTablePageRef"
            :url="dataUrl"
            :search-item="searchItem"
            :columns="columns"
            show-index
            pagination
            :height="-200"
            :showTools="false"
        >
        </MyTablePage>
    </ADrawer>
</template>
<!--路由地址：/system/sysLogLogin/index ,组件名称：sysLogLoginIndex	-->
<script setup lang="ts" name="sysLogLoginIndex">
import { nextTick, onMounted, ref } from 'vue'
import { getUserStore } from '@/store'
const MyTablePageRef = ref()
const visible = ref(false)
const userStore = getUserStore()
const show = () => {
    visible.value = true
    nextTick(() => {
        MyTablePageRef.value.search()
    })
}
defineExpose({ show })
const dataUrl = `${import.meta.env.VITE_API_URL_SYSTEM}/v1/sys/log/login/getList?accountName=${
    userStore.userInfo.accountName
}`

/*搜索条配置 api https://itvita.gitee.io/liuyunxi-antd-extend/#/YxSearch*/
const searchItem = ref<any[]>([
    {
        type: 'text',
        key: 'title',
        label: '操作标题',
        value: '',
        placeholder: '',
    },
])

/*列配置 api https://itvita.gitee.io/liuyunxi-antd-extend/#/YxTable*/
const columns = ref<any[]>([
    {
        title: '操作标题',
        dataIndex: 'title',
        hidden: false,
    },
    {
        title: '用户账号',
        dataIndex: 'accountName',
        hidden: false,
    },
    {
        title: '登录地点',
        dataIndex: 'address',
        hidden: false,
    },
    {
        title: 'ip地址',
        dataIndex: 'ipAddr',
        hidden: false,
    },
    {
        title: '记录描述',
        dataIndex: 'message',
        hidden: false,
    },
    {
        title: '状态',
        dataIndex: 'state',
        hidden: false,
        formatter: {
            type: 'tag',
            format: (row: any) => {
                if (row.state === '1') {
                    return {
                        value: '成功',
                        color: '#87d068',
                    }
                } else {
                    return {
                        value: '失败',
                        color: '#f5222d',
                    }
                }
            },
        },
    },
    {
        title: '登录时间',
        width: 180,
        dataIndex: 'createdTime',
    },
])

/**
 * 挂载，页面初始化后执行
 */
onMounted(() => {})
</script>

<style scoped lang="less"></style>
