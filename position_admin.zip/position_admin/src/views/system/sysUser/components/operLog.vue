<!--操作日志-->
<template>
    <ACard title="操作记录">
        <template #extra><a href="javascript:void(0)" @click="showMore">更多</a></template>
        <ATimeline>
            <ATimelineItem
                v-for="(item, index) in rows"
                :key="index"
                :color="item.state === '1' ? 'green' : 'red'"
            >
                <div>{{ item.createdTime }}&nbsp;&nbsp;{{ item.title }}</div>
                <div class="text-grey">
                    {{ item.ip }}&nbsp;&nbsp;{{ item.address }}&nbsp;&nbsp;{{ item.browser }}
                </div>
            </ATimelineItem>
        </ATimeline>
    </ACard>
    <OperLogMore ref="OperLogMoreRef"></OperLogMore>
</template>
<script setup lang="ts" name="operLog">
import { onMounted, ref } from 'vue'
import { getUserStore } from '@/store'
import { getList } from '@/api/common'
import OperLogMore from './operLogMore.vue'
const userStore = getUserStore()
const OperLogMoreRef = ref()
const dataUrl = `${import.meta.env.VITE_API_URL_SYSTEM}/v1/sys/log/oper/getList?createdBy=${
    userStore.userInfo.id
}`

const rows = ref([])

const showMore = () => {
    OperLogMoreRef.value.show()
}
onMounted(() => {
    getList(dataUrl, {
        pageNumber: 1,
        pageSize: 10,
    }).then((res) => {
        if (res.code === 1) {
            rows.value = res.data.rows
            console.log(rows.value)
        }
    })
})
</script>
<style scoped lang="less"></style>
