<template>
    <PageWrapper title="角色管理" sub-title="">
        <MyTablePage
            ref="MyTablePageRef"
            :search-item="searchItem"
            :url="dataUrl"
            :columns="columns"
            :action="action"
            :ellipsis="1"
            show-index
            pagination
            selection="checkbox"
        >
            <template #tools>
                <AButton v-permission="'sysRoleAdd'" type="primary" @click="handelAdd">
                    <template #icon>
                        <PlusOutlined />
                    </template>
                    添加
                </AButton>
                <AButton v-permission="'sysRoleDelete'" type="danger" @click="deletes()">
                    <template #icon>
                        <DeleteOutlined />
                    </template>
                    批量删除
                </AButton>
                <AButton
                    v-permission="'sysRoleExport'"
                    type="success"
                    @click="MyTablePageRef.handleExport('角色管理')"
                >
                    <template #icon>
                        <DownloadOutlined />
                    </template>
                    导出
                </AButton>
            </template>
        </MyTablePage>
        <Edit ref="EditRef" @ok="MyTablePageRef.search()"></Edit>
        <Auth ref="AuthRef"></Auth>
        <DataScope ref="DataScopeRef" @ok="MyTablePageRef.search()"></DataScope>
        <UserAuth ref="UserAuthRef"></UserAuth>
    </PageWrapper>
</template>
<!--路由地址：/system/sysRole/index ,组件名称：sysRoleIndex	-->
<script setup lang="ts" name="sysRoleIndex">
import { onMounted, ref } from 'vue'
import { DeleteOutlined, PlusOutlined, DownloadOutlined } from '@ant-design/icons-vue'
import { message, Modal } from 'ant-design-vue'
import { cloneDeep } from 'lodash-es'
import { del } from '@/api/system/sysRole'
import Edit from './edit.vue'
import UserAuth from './userAuth.vue'
const EditRef = ref()

import Auth from './auth.vue'
const AuthRef = ref()

import DataScope from './dataScope.vue'
const DataScopeRef = ref()
const UserAuthRef = ref()

const MyTablePageRef = ref()
const dataUrl = `${import.meta.env.VITE_API_URL_SYSTEM}/v1/sys/role/getList`

/*列配置 api https://itvita.gitee.io/liuyunxi-antd-extend/#/YxTable*/
const columns = ref<any[]>([
    {
        title: '角色名称',
        dataIndex: 'title',
        hidden: false,
        sorter: true,
    },
    {
        title: '角色编码', //只有系统内置的角色才会有编码
        dataIndex: 'roleCode',
        hidden: true,
    },
    {
        title: '系统默认',
        dataIndex: 'isDefault',
        hidden: false,
        sorter: true,
        formatter: {
            type: 'tag',
            format: (row: any): any => {
                if (row.isDefault * 1 === 1) {
                    return {
                        value: `是`,
                        color: 'blue', // css 颜色代码 blue,green,red,#xxx...
                    }
                } else {
                    return {
                        value: `否`,
                        color: 'gray', // css 颜色代码 blue,green,red,#xxx...
                    }
                }
            },
        },
    },
    {
        title: '状态',
        dataIndex: 'state',
        hidden: false,
        sorter: true,
        formatter: {
            type: 'tag',
            format: (row: any): any => {
                if (row.state * 1 === 1) {
                    return {
                        value: `启用`,
                        color: 'blue', // css 颜色代码 blue,green,red,#xxx...
                    }
                } else {
                    return {
                        value: `禁用`,
                        color: 'gray', // css 颜色代码 blue,green,red,#xxx...
                    }
                }
            },
        },
    },
    {
        title: '数据权限范围', //只有系统内置的角色才会有编码
        dataIndex: 'dataAuthType',
        formatter: {
            type: 'text',
            format: (row: any): any => {
                if (row.dataAuthType === '1') {
                    return {
                        value: `全部`,
                    }
                } else if (row.dataAuthType === '2') {
                    return {
                        value: `仅自己`,
                    }
                } else if (row.dataAuthType === '3') {
                    return {
                        value: `所属组织`,
                    }
                } else if (row.dataAuthType === '4') {
                    return {
                        value: `所属组织及以下`,
                    }
                } else if (row.dataAuthType === '5') {
                    return {
                        value: `自定义`,
                    }
                } else {
                    return {
                        value: row.dataAuthType,
                    }
                }
            },
        },
    },
    {
        title: '备注',
        dataIndex: 'remark',
        hidden: false,
    },
])
/*搜索条配置 api https://itvita.gitee.io/liuyunxi-antd-extend/#/YxSearch*/
const searchItem = ref<any[]>([
    {
        type: 'text',
        key: 'title',
        label: '角色名称',
        value: '',
        placeholder: '',
    },
])
/**
 * 批量删除方法
 * @param ids id数组
 */
const deletes = (ids?: string[]) => {
    if (ids === undefined) {
        const { selectedRowKeys } = MyTablePageRef.value.getSelection()
        ids = cloneDeep(selectedRowKeys)
    }
    if (!ids || ids?.length < 1) {
        Modal.warning({
            title: '请先选择删除项',
        })
        return
    }
    Modal.confirm({
        title: '确定删除？',
        content: '删除后将无法恢复',
        okType: 'danger',
        onOk() {
            del(ids).then((res: any) => {
                if (res.code === 1) {
                    message.success('删除成功')
                    MyTablePageRef.value.search()
                }
            })
        },
    })
}
/*table 操作列配置*/
const action = ref({
    width: 280,
    fixed: 'right',
    buttons: [
        {
            title: '编辑',
            color: 'primary', // primary,success,warn,danger,info
            icon: 'iconfont icon-bianji',
            hide: (row: any) => row.roleCode === 'Admin',
            permission: 'sysRoleEdit',
            event: (row: any) => {
                EditRef.value.show({ id: row.id })
            },
        },
        {
            title: '删除',
            color: '#f12424', // primary,success,warn,danger,info
            icon: 'iconfont icon-shanchu',
            hide: (row: any) => row.isDefault === '1',
            permission: 'sysRoleDelete',
            event: (row: any) => {
                deletes([row.id])
            },
        },
        {
            title: '菜单权限',
            color: 'success', // primary,success,warn,danger,info
            icon: 'iconfont icon-bianji',
            hide: (row: any) => row.roleCode === 'Admin',
            permission: 'sysRoleAuth',
            event: (row: any) => {
                AuthRef.value.show({ id: row.id })
            },
        },
        {
            title: '数据权限',
            color: 'success', // primary,success,warn,danger,info
            icon: 'iconfont icon-bianji',
            hide: (row: any) => row.roleCode === 'Admin',
            permission: 'sysRoleAuth',
            event: (row: any) => {
                DataScopeRef.value.show({ id: row.id })
            },
        },
        {
            title: '人员管理',
            color: 'primary', // primary,success,warn,danger,info
            icon: 'iconfont icon-bianji',
            hide: (row: any) => row.roleCode === 'Admin',
            permission: 'sysUserAuth',
            event: (row: any) => {
                UserAuthRef.value.show({ id: row.id, roleName: row.title })
            },
        },
    ],
})

/**
 * 添加
 */
const handelAdd = () => {
    EditRef.value.show()
}

/**
 * 挂载，页面初始化后执行
 */
onMounted(() => {
    MyTablePageRef.value.search()
})
</script>

<style scoped lang="less"></style>
