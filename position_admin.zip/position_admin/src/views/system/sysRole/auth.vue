<template>
    <YxModal
        ref="YxModalRef"
        title="权限设置"
        v-model:visible="visible"
        @ok="onSubmit"
        @cancel="onCancel"
        :submit-loading="submitLoading"
    >
        <ACard>
            <ACheckbox v-model:checked="checkAll" @change="onCheckAllChange"> 全选</ACheckbox>
            <ADivider style="margin-top: 5px" />
            <YxAuth :treeData="menus" v-model:value="checkedKeys"></YxAuth>
        </ACard>
    </YxModal>
</template>

<script setup lang="ts">
import { ref } from 'vue'
import { message } from 'ant-design-vue'
import { saveAuth, getAuth } from '@/api/system/sysRole'
import { leftCover } from '@/utils/ObjectUtils'
import YxAuth from '@/components/YxAuth'
import { getTreeByTenantId } from '@/api/platform/sysMenu'
/**
 * 基础数据定义
 */
const visible = ref(false)
const submitLoading = ref(false)
const defaultForm = {
    id: null, //主键ID
}
const formRef = ref<any>({
    ...defaultForm,
})
/*菜单数据*/
const menus = ref([])
/*选中项*/
const checkedKeys = ref([])
/*全选*/
const checkAll = ref(false)

const getId = (list: any[], ids: string[]) => {
    list.forEach((v: any) => {
        ids.push(v.id)
        if (v.children.length > 0) {
            getId(v.children, ids)
        }
    })
}
/*点击全选*/
const onCheckAllChange = (e: any) => {
    checkedKeys.value = []
    if (e.target.checked) {
        getId(menus.value, checkedKeys.value)
    }
}

/**
 * 显示弹窗
 */
const show = async (params?: any) => {
    params = params || {}
    visible.value = true
    /**
     * 初始参数
     */
    formRef.value = Object.assign({}, { ...defaultForm })
    leftCover(formRef.value, params || {})

    /**
     * 查询角色权限
     */
    checkedKeys.value = []
    await getAuth({ id: formRef.value.id }).then((res) => {
        if (res.code === 1) {
            checkedKeys.value = res.data
        }
    })

    await getTreeByTenantId({}).then((res) => {
        if (res.code === 1) {
            menus.value = res.data
        }
    })
}
defineExpose({ show })

const onSubmit = () => {
    submitLoading.value = true
    if (formRef.value.id) {
        saveAuth({
            id: formRef.value.id,
            checkedKeys: checkedKeys.value,
        }).then((res: any) => {
            if (res.code === 1) {
                message.success('提交成功')
            }
            submitLoading.value = false
            onCancel()
        })
    }
}
const onCancel = () => {
    visible.value = false
}
</script>

<style scoped lang="less"></style>
