<template>
    <AModal
        v-model:visible="visible"
        width="70%"
        title="人员授权"
        @ok="handleOk()"
        :confirm-loading="loading"
    >
        <MyTablePage
            ref="MyTablePageRef"
            :search-item="searchItem"
            :url="dataUrl"
            :columns="columns"
            :ellipsis="1"
            pagination
            show-index
            selection="checkbox"
        >
        </MyTablePage>
    </AModal>
</template>
<!--添加路由地址：/system/sysRole/add，修改路由地址：/system/sysRole/edit，组件地址：/system/sysRole/edit-->
<script setup lang="ts">
import { ref } from 'vue'
import { cloneDeep } from 'lodash-es'
import { message, Modal } from 'ant-design-vue'
import * as sysRole from '@/api/system/sysRole'

/**
 * 基础数据定义
 */
const roleId = ref('')
const visible = ref(false)
const loading = ref(false)
const MyTablePageRef = ref()
const dataUrl = ref('')

/*列配置 api https://itvita.gitee.io/liuyunxi-antd-extend/#/YxTable*/
const columns = ref([
    {
        title: '组织机构',
        dataIndex: 'deptCode',
        hidden: false,
        align: 'left',
        fixed: 'none',
        width: 300,
    },
    {
        title: '帐号',
        dataIndex: 'accountName',
        hidden: false,
        sorter: true,
        align: 'left',
        fixed: 'none',
    },
    {
        title: '姓名',
        dataIndex: 'userName',
        hidden: false,
        align: 'left',
        fixed: 'none',
        sorter: true,
    },
    {
        title: '身份类型',
        dataIndex: 'identityTypeCode',
        hidden: false,
        align: 'left',
        fixed: 'none',
        sorter: true,
    },
])

/*搜索条配置 api https://itvita.gitee.io/liuyunxi-antd-extend/#/YxSearch*/
const searchItem = ref([
    {
        type: 'text',
        key: 'userName',
        label: '姓名',
        value: '',
        placeholder: '',
    },
])
/**
 * 显示弹窗
 */
const show = (params?: any) => {
    params = params || {}
    console.log('打印params', params)
    roleId.value = params.roleId
    dataUrl.value = `${
        import.meta.env.VITE_API_URL_SYSTEM
    }/v1/sys/user/getExcludeRoleIdList?roleId=${roleId.value}`
    visible.value = true
    setTimeout(() => {
        MyTablePageRef.value.search()
    }, 300)
}

defineExpose({ show })

/**
 * 关闭弹窗
 */
const onCancel = () => {
    visible.value = false
}

/**
 * 接收方法
 */
const emits = defineEmits(['ok'])

const handleOk = (ids?: string[]) => {
    if (ids === undefined) {
        const { selectedRowKeys } = MyTablePageRef.value.getSelection()
        ids = cloneDeep(selectedRowKeys)
    }
    if (!ids || ids?.length < 1) {
        Modal.warning({
            title: '请先选择人员',
        })
        return
    }
    loading.value = true
    const param = { id: roleId.value, userIdList: ids }
    sysRole.editRoleUser(param).then((res: any) => {
        if (res.code === 1) {
            emits('ok')
            message.success('添加成功')
            onCancel()
        }
    })
    loading.value = false
    visible.value = false
}
</script>

<style scoped lang="less"></style>
