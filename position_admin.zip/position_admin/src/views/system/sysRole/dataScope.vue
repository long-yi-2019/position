<template>
    <YxModal
        ref="YxModalRef"
        :title="modalTitle"
        v-model:visible="visible"
        @ok="onSubmit"
        @cancel="onCancel"
        :submit-loading="submitLoading"
    >
        <AForm
            class="padding"
            ref="myFormRef"
            name="myFormRef"
            :model="formRef"
            :label-col="{ span: 4 }"
            :wrapper-col="{ span: 14 }"
        >
            <AFormItem label="权限范围" name="dataAuthType" :rules="[{ required: true }]">
                <ARadioGroup v-model:value="formRef.dataAuthType" :options="dataAuthTypeOptions" />
            </AFormItem>
            <AFormItem v-if="formRef.dataAuthType === '5'" label="自定义权限" :rules="[]">
                <ACheckbox
                    v-model:checked="isAllChecked"
                    @click="allChecked()"
                    style="margin-top: 5px"
                    >全选/全不选
                </ACheckbox>
                <ACheckbox
                    v-model:checked="isCheckStrictly"
                    style="margin-top: 5px"
                    @click="linkageChecked()"
                    >父子联动
                </ACheckbox>
                <ATree
                    v-model:expandedKeys="expandedKeys"
                    v-model:checkedKeys="checkedKeys"
                    v-model:selectedKeys="selectedKeys"
                    style="border: 1px solid #e7e7e7; margin-top: 12px; padding: 5px 8px"
                    :fieldNames="{ children: 'children', title: 'title', key: 'code' }"
                    checkable
                    :checkStrictly="!isCheckStrictly"
                    :tree-data="depTreeData"
                ></ATree>
            </AFormItem>
        </AForm>
    </YxModal>
</template>

<script setup lang="ts">
import { ref } from 'vue'
import { leftCover } from '@/utils/ObjectUtils.js'
import { editDataAuth, getRoleAuthList } from '@/api/system/sysRole.js'
import { getTree } from '@/api/system/sysDepartment.js'
import { FormInstance, message } from 'ant-design-vue'

const myFormRef = ref<FormInstance>()
const modalTitle = ref('数据权限')
const visible = ref(false)
const submitLoading = ref(false)
const depTreeData = ref<any>([])
const selectedKeys = ref<any>([])
const checkedKeys = ref<any>([])
const expandedKeys = ref<any>(['100'])
const isCheckStrictly = ref(false)
const isAllChecked = ref(false)
/**
 * 状态选项
 */
const dataAuthTypeOptions = ref([
    { label: '全部', value: '1' },
    { label: '仅自己', value: '2' },
    { label: '所属组织', value: '3' },
    { label: '所属组织及以下', value: '4' },
    { label: '自定义', value: '5' },
])

/**
 * 接收方法
 */
const emits = defineEmits(['ok'])

const defaultForm = {
    id: null, //主键ID
    dataAuthType: '2',
    authDepartmentCodeList: [],
}

const formRef = ref<any>({
    ...defaultForm,
})
/**
 * 显示弹窗
 */
const show = (params?: any) => {
    params = params || {}
    visible.value = true
    /**
     * 初始参数
     */
    formRef.value = Object.assign({}, { ...defaultForm })
    leftCover(formRef.value, params || {})

    isCheckStrictly.value = false
    isAllChecked.value = false

    if (params.id) {
        modalTitle.value = '编辑角色'
        getRoleAuthList({ id: params.id }).then((res: any) => {
            const data = res.data
            leftCover(formRef.value, parseParams(data))
            getTree({}).then((res: any) => {
                if (res.code === 1) {
                    depTreeData.value = res.data
                    expandedKeys.value = getAllIds(depTreeData.value || [])
                }
            })
        })
    }
}

const onSubmit = () => {
    myFormRef.value?.validate().then(() => {
        submitLoading.value = true
        editDataAuth(buildParams(formRef.value)).then((res: any) => {
            if (res.code === 1) {
                emits('ok')
                message.success('提交成功')
                onCancel()
            }
            submitLoading.value = false
        })
    })
}

const allChecked = () => {
    if (!isAllChecked.value) {
        checkedKeys.value = getAllIds(depTreeData.value || [])
        checkedKeys.value.checked = getAllIds(depTreeData.value || [])
    } else {
        checkedKeys.value = []
        checkedKeys.value.checked = []
    }
}

const linkageChecked = () => {
    checkedKeys.value = []
}

const getAllIds = (data: any) => {
    const codes: any = []
    for (const item of data) {
        codes.push(item.code)
        if (item.children && item.children.length > 0) {
            const childCodes = getAllIds(item.children)
            codes.push(...childCodes)
        }
    }
    return codes
}

const buildParams = (data?: any) => {
    const tdata = Object.assign({}, data)
    tdata.authDepartmentCodeList = isCheckStrictly.value
        ? checkedKeys.value
        : checkedKeys.value.checked
    return tdata
}

const parseParams = (data?: any) => {
    const tdata = Object.assign({}, data)
    checkedKeys.value = tdata.authDepartmentCodeList
    expandedKeys.value = tdata.authDepartmentCodeList
    return tdata
}

/**
 * 关闭弹窗
 */
const onCancel = () => {
    myFormRef.value?.resetFields()
    visible.value = false
}

defineExpose({ show })
</script>

<style scoped></style>
