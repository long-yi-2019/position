<template>
    <YxModal
        ref="YxModalRef"
        :title="modalTitle"
        v-model:visible="visible"
        @ok="onSubmit"
        @cancel="onCancel"
        :submit-loading="submitLoading"
    >
        <MyTablePage
            ref="MyTablePageRef"
            :search-item="searchItem"
            :url="dataUrl"
            :columns="columns"
            :action="action"
            :ellipsis="1"
            pagination
            show-index
            selection="checkbox"
        >
            <template #tools>
                <AButton v-permission="'sysUserAuth'" type="primary" @click="handelAdd">
                    <template #icon>
                        <PlusOutlined />
                    </template>
                    人员授权
                </AButton>
            </template>
        </MyTablePage>
        <UserAdd ref="UserAddRefRef" @ok="MyTablePageRef.search()"></UserAdd>
    </YxModal>
</template>
<!--添加路由地址：/system/sysRole/add，修改路由地址：/system/sysRole/edit，组件地址：/system/sysRole/edit-->
<script setup lang="ts">
import { ref } from 'vue'
import { cloneDeep } from 'lodash-es'
import { message, Modal } from 'ant-design-vue'
import * as sysRole from '@/api/system/sysRole'
import UserAdd from './userAdd.vue'
/**
 * 基础数据定义
 */
const roleId = ref('')
const visible = ref(false)
const submitLoading = ref(false)
const modalTitle = ref('人员管理')
const MyTablePageRef = ref()
const UserAddRefRef = ref()
const dataUrl = ref('')

/*列配置 api https://itvita.gitee.io/liuyunxi-antd-extend/#/YxTable*/
const columns = ref([
    {
        title: '组织机构',
        dataIndex: 'deptCode',
        hidden: false,
        align: 'left',
        fixed: 'none',
        width: 300,
    },
    {
        title: '帐号',
        dataIndex: 'accountName',
        hidden: false,
        sorter: true,
        align: 'left',
        fixed: 'none',
    },
    {
        title: '姓名',
        dataIndex: 'userName',
        hidden: false,
        align: 'left',
        fixed: 'none',
        sorter: true,
    },
    {
        title: '身份类型',
        dataIndex: 'identityTypeCode',
        hidden: false,
        align: 'left',
        fixed: 'none',
        sorter: true,
    },
])

/*搜索条配置 api https://itvita.gitee.io/liuyunxi-antd-extend/#/YxSearch*/
const searchItem = ref([
    {
        type: 'text',
        key: 'userName',
        label: '姓名',
        value: '',
        placeholder: '',
    },
])
/*table 操作列配置*/
const action = ref({
    width: 280,
    fixed: 'right',
    buttons: [
        {
            title: '取消授权',
            color: 'primary', // primary,success,warn,danger,info
            icon: 'iconfont icon-bianji',
            hide: (row: any) => row.roleCode === 'Admin',
            permission: 'sysUserAuth',
            event: (row: any) => {
                cancelRoleUser(row.id)
            },
        },
    ],
})
const cancelRoleUser = (userId) => {
    Modal.confirm({
        title: '确定取消授权？',
        content: '',
        okType: 'danger',
        onOk() {
            sysRole.cancelRoleUser({ roleId: roleId.value, userId: userId }).then((res: any) => {
                if (res.code === 1) {
                    message.success('取消成功')
                    MyTablePageRef.value.search()
                }
            })
        },
    })
}
/**
 * 显示弹窗
 */
const show = (params?: any) => {
    params = params || {}
    modalTitle.value = params.roleName + '-人员管理'
    roleId.value = params.id
    dataUrl.value = `${
        import.meta.env.VITE_API_URL_SYSTEM
    }/v1/sys/user/getIncludeRoleIdList?roleId=${roleId.value}`
    visible.value = true
    setTimeout(() => {
        MyTablePageRef.value.search()
    }, 500)
}
defineExpose({ show })

/**
 * 提交方法
 */
const onSubmit = (ids?: string[]) => {
    if (ids === undefined) {
        const { selectedRowKeys } = MyTablePageRef.value.getSelection()
        ids = cloneDeep(selectedRowKeys)
    }
    if (!ids || ids?.length < 1) {
        Modal.warning({
            title: '请先选择人员',
        })
        return
    }
    const param = { id: roleId.value, userIdList: ids }
    sysRole.editRoleUser(param).then((res: any) => {
        if (res.code === 1) {
            message.success('添加成功')
            onCancel()
        }
    })
}
/**
 * 关闭弹窗
 */
const onCancel = () => {
    visible.value = false
}
const handelAdd = () => {
    UserAddRefRef.value.show({ roleId: roleId.value })
}
</script>

<style scoped lang="less"></style>
