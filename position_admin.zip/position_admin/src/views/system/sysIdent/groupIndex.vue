<!--分组管理-->
<template>
    <ACard
        size="small"
        title="图标分组"
        :bordered="false"
        style="width: 300px; margin-top: 8px"
        :body-style="{ padding: 0, height: 'calc(100vh - 350px)', overflow: 'auto' }"
    >
        <template #extra
            ><a href="#"><PlusOutlined @click="handleEdit" /></a
        ></template>
        <ATabs
            v-model:activeKey="selectedKeys"
            tab-position="left"
            animated
            @tabClick="tabClick"
            class="yx-group-tabs"
        >
            <ATabPane :key="item.code" v-for="item in classifyList">
                <template #tab>
                    <div class="yx-group-pane text-left">
                        <div class="left">
                            {{ item.name }}
                        </div>
                        <div class="right">
                            <ADropdown>
                                <SettingOutlined />
                                <template #overlay>
                                    <AMenu>
                                        <AMenuItem>
                                            <FormOutlined />
                                            <a href="javascript:void(0)" @click="handleEdit(item)">
                                                编辑分组
                                            </a>
                                        </AMenuItem>
                                        <AMenuItem>
                                            <DeleteOutlined />
                                            <a
                                                href="javascript:void(0)"
                                                @click="handleDelete(item.id)"
                                            >
                                                删除分组
                                            </a>
                                        </AMenuItem>
                                    </AMenu>
                                </template>
                            </ADropdown>
                        </div>
                    </div>
                </template>
            </ATabPane>
        </ATabs>
    </ACard>
    <!--    <div class="group_title">-->
    <!--        <div class="left title">图标分组</div>-->
    <!--        <div class="right">-->
    <!--            <PlusOutlined @click="handleEdit" />-->
    <!--        </div>-->
    <!--    </div>-->

    <AModal
        v-model:visible="visible"
        :title="modalTitle"
        @ok="handleOk"
        :confirm-loading="submitLoading"
    >
        <AForm
            class="padding"
            ref="myFormRef"
            name="myFormRef"
            :model="formRef"
            :label-col="{ span: 6 }"
            :wrapper-col="{ span: 18 }"
        >
            <AFormItem
                label="名称"
                name="name"
                :rules="[{ max: 20, message: '必填，最大长度20', required: true }]"
            >
                <AInput v-model:value="formRef.name" placeholder=""></AInput>
            </AFormItem>
            <AFormItem label="序号" name="seq" :rules="[{ required: true }]">
                <AInputNumber v-model:value="formRef.seq" :min="1" placeholder=""></AInputNumber>
            </AFormItem>
        </AForm>
    </AModal>
</template>
<script setup lang="ts" name="groupIndex">
import { onMounted, ref } from 'vue'
import { DeleteOutlined, FormOutlined, PlusOutlined, SettingOutlined } from '@ant-design/icons-vue'
import { getList } from '@/api/common'
import { FormInstance, message, Modal } from 'ant-design-vue'
import { leftCover } from '@/utils/ObjectUtils'
import { save, edit, del } from '@/api/system/sysIdentClassify'
const classifyList = ref<any>([])
const selectedKeys = ref('')
const visible = ref(false)
/**
 * 基础数据定义
 */
const submitLoading = ref(false)
const modalTitle = ref('添加分组')

const myFormRef = ref<FormInstance>()
const defaultForm = {
    id: null, //主键ID
    name: '', //字典名称
    seq: '1', //顺序号
}
const formRef = ref<any>({
    ...defaultForm,
})

const getKeyList = async () => {
    await getList(
        `${
            import.meta.env.VITE_API_URL_SYSTEM
        }/v1/sys/ident/classify/getList?pageNumber=1&pageSize=-1`,
    ).then((res) => {
        if (res.code === 1) {
            classifyList.value = res.data.rows
        }
    })
}
const emits = defineEmits(['click'])
/**
 * tabs点击
 */
const tabClick = (res) => {
    emits('click', res)
}
const handleDelete = (id) => {
    Modal.confirm({
        title: '确定删除？',
        content: '删除后将无法恢复',
        okType: 'danger',
        onOk() {
            del([id]).then((res: any) => {
                if (res.code === 1) {
                    message.success('删除成功')
                    getKeyList()
                }
            })
        },
    })
}

/**
 * 添加/编辑
 * @param item
 */
const handleEdit = (item) => {
    item = item || {}
    visible.value = true
    /**
     * 初始参数
     */
    formRef.value = Object.assign({}, { ...defaultForm })
    leftCover(formRef.value, item || {})

    if (item.id) {
        modalTitle.value = '编辑分组'
    }
}

const init = async () => {
    await getKeyList()
    if (classifyList.value.length > 0) {
        const first = classifyList.value[0]
        selectedKeys.value = first?.code
        emits('click', selectedKeys.value)
    }
}
defineExpose({ init })

const handleOk = () => {
    myFormRef.value?.validate().then(() => {
        submitLoading.value = true
        if (formRef.value.id) {
            edit(formRef.value).then((res: any) => {
                if (res.code === 1) {
                    message.success('提交成功')
                    getKeyList()
                    visible.value = false
                }
                submitLoading.value = false
                myFormRef.value?.resetFields()
            })
        } else {
            save(formRef.value).then((res: any) => {
                if (res.code === 1) {
                    message.success('提交成功')
                    getKeyList()
                    visible.value = false
                }
                submitLoading.value = false
                myFormRef.value?.resetFields()
                visible.value = false
            })
        }
    })
}
onMounted(() => {})
</script>
<style scoped lang="less"></style>
