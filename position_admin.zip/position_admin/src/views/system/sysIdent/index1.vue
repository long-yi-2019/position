<template>
    <PageWrapper title="图标库" sub-title="">
        <div class="main">
            <div class="left">
                <GroupIndex ref="GroupIndexRef" @click="menuClick"></GroupIndex>
            </div>
            <div class="table-container">
                <MyTablePage
                    style="overflow: auto"
                    ref="MyTablePageRef"
                    :search-item="searchItem"
                    :url="dataUrl"
                    :columns="columns"
                    :action="action"
                    :ellipsis="1"
                    show-index
                    pagination
                    selection="checkbox"
                >
                    <template #tools>
                        <AButton v-permission="'sysIdentAdd'" type="primary" @click="handelAdd">
                            <template #icon>
                                <PlusOutlined />
                            </template>
                            添加图标
                        </AButton>
                        <AButton v-permission="'sysIdentDelete'" type="danger" @click="deletes()">
                            <template #icon>
                                <DeleteOutlined />
                            </template>
                            批量删除
                        </AButton>
                    </template>
                </MyTablePage>
            </div>
        </div>
        <Edit ref="EditRef" @ok="search"></Edit>
    </PageWrapper>
</template>
<!--路由地址：/system/sysIdent/index ,组件名称：sysIdentIndex	-->
<script setup lang="ts" name="sysIdentIndex">
import { onMounted, ref } from 'vue'
import { DeleteOutlined, PlusOutlined } from '@ant-design/icons-vue'
import { message, Modal } from 'ant-design-vue'
import { cloneDeep } from 'lodash-es'
import { del } from '@/api/system/sysIdent'
import Edit from './edit.vue'
const GroupIndexRef = ref()
const EditRef = ref()

const selectedKeys = ref<any>()
const MyTablePageRef = ref()
const dataUrl = `${import.meta.env.VITE_API_URL_SYSTEM}/v1/sys/ident/getList`
import { getUserStore } from '@/store'
import GroupIndex from '@/views/system/sysIdent/groupIndex.vue'

const rootUrl = import.meta.env.VITE_API_URL_STATIC

const userStore = getUserStore()
/*列配置 api https://itvita.gitee.io/liuyunxi-antd-extend/#/YxTable*/
const columns = ref<any[]>([
    {
        title: '名称',
        dataIndex: 'name',
        hidden: false,
    },
    {
        title: '图标',
        dataIndex: 'identImg',
        hidden: false,
        formatter: {
            type: 'image',
            format: (row: any): any => {
                const identImg = JSON.parse(row.identImg)[0]
                return [
                    {
                        name: rootUrl + identImg.name,
                        src: rootUrl + identImg.path,
                    },
                ]
            },
        },
    },
    {
        title: '备注',
        dataIndex: 'remark',
        hidden: false,
    },
])
/*搜索条配置 api https://itvita.gitee.io/liuyunxi-antd-extend/#/YxSearch*/
const searchItem = ref<any[]>([
    {
        type: 'text',
        key: 'name',
        label: '名称',
        value: '',
        placeholder: '',
    },
])
/**
 * 批量删除方法
 * @param ids id数组
 */
const deletes = (ids?: string[]) => {
    if (ids === undefined) {
        const { selectedRowKeys } = MyTablePageRef.value.getSelection()
        ids = cloneDeep(selectedRowKeys)
    }
    if (!ids || ids?.length < 1) {
        Modal.warning({
            title: '请先选择删除项',
        })
        return
    }
    Modal.confirm({
        title: '确定删除？',
        content: '删除后将无法恢复',
        okType: 'danger',
        onOk() {
            del(ids).then((res: any) => {
                if (res.code === 1) {
                    message.success('删除成功')
                    search()
                }
            })
        },
    })
}
/*table 操作列配置*/
const action = ref({
    width: 200,
    fixed: 'right',
    buttons: [
        {
            title: '详情',
            icon: 'iconfont icon-caidan',
            event: (row: any) => {
                MyTablePageRef.value.showDetail(row)
            },
        },
        {
            title: '编辑',
            icon: 'iconfont icon-bianji',
            permission: 'sysIdentEdit',
            hide: (row) => {
                return row.tenantId !== userStore.userInfo.tenantId
            },
            event: (row: any) => {
                EditRef.value.show({ id: row.id })
            },
        },
        {
            title: '删除',
            color: '#f12424', // primary,success,warn,danger,info
            icon: 'iconfont icon-shanchu',
            permission: 'sysIdentDelete',
            hide: (row) => {
                return row.tenantId !== userStore.userInfo.tenantId
            },
            event: (row: any) => {
                deletes([row.id])
            },
        },
    ],
})

/**
 * 添加
 */
const handelAdd = () => {
    if (!selectedKeys.value) {
        Modal.warning({
            title: '警告',
            content: '请先设置分组',
        })
        return
    }
    EditRef.value.show({ classifyCode: selectedKeys.value })
}

const menuClick = (key) => {
    selectedKeys.value = key
    MyTablePageRef.value.search({ classifyCode: key })
}

const search = () => {
    MyTablePageRef.value.search({ classifyCode: selectedKeys.value })
}

/**
 * 挂载，页面初始化后执行
 */
onMounted(async () => {
    GroupIndexRef.value.init()
})
</script>

<style scoped lang="less">
@import '@/theme/theme.less';

.main {
    background: @component-background;
}

.left {
    float: left;
    //margin-right: 20px;
    min-height: 100%;
    max-height: calc(100vh - 250px);
    padding: 10px;

    &::-webkit-scrollbar {
        width: 8px;
        height: 10px;
        background-color: #f8f9fa;
    }

    &::-webkit-scrollbar-thumb {
        background: rgba(0, 0, 0, 0.2);
        border-radius: 0;
    }
}
</style>
