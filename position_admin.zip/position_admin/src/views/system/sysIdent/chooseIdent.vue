<template>
    <AModal
        v-model:visible="visible"
        width="1000px"
        title="选择安全标识"
        :body-style="{ padding: 0 }"
        @ok="onSubmit"
    >
        <div class="main">
            <div class="left">
                <ul class="group-menu">
                    <li
                        class="group-item"
                        :class="active === item.code ? 'active' : ''"
                        :key="item.code"
                        v-for="item in classifyList"
                        @click="groupClick(item)"
                    >
                        <a class="group-item-link" href="javascript:void(0)">{{ item.name }}</a>
                    </li>
                </ul>
            </div>
            <div class="right">
                <div
                    class="images"
                    v-for="(item, index) in rows"
                    :key="index"
                    @click="chooseImg(item)"
                >
                    <div
                        class="images-item"
                        :style="{
                            backgroundImage: 'url(' + item.url + ')',
                        }"
                    ></div>
                    <div class="mask" :class="chooseId.indexOf(item.id) > -1 ? 'active' : ''"></div>
                    <i
                        v-if="chooseId.indexOf(item.id) > -1"
                        class="uwofont uwo-checkbox-fill"
                        style="font-size: 28px"
                    ></i>
                </div>
            </div>
        </div>
    </AModal>
</template>
<!--路由地址：/system/sysIdent/index ,组件名称：sysIdentIndex	-->
<script setup lang="ts" name="chooseIdent">
import { ref } from 'vue'
const classifyList = ref<any>([])
import { getList } from '@/api/common'

/**
 * 基础数据定义
 */
const visible = ref(false)
const active = ref('')
const chooseId = ref<any>([])
const chooseIdent = ref<any>([])
/**
 * 显示弹窗
 */
const show = () => {
    chooseId.value = []
    chooseIdent.value = []
    visible.value = true

    /**
     * 获取分组
     */
    getList(
        `${
            import.meta.env.VITE_API_URL_SYSTEM
        }/v1/sys/ident/classify/getList?pageNumber=1&pageSize=-1`,
    ).then((res) => {
        if (res.code === 1) {
            classifyList.value = res.data.rows
            active.value = classifyList.value[0].code
            search()
        }
    })
}
defineExpose({ show })
const rows = ref([])
const search = (params?: any) => {
    rows.value = []
    params = params || {}
    getList(`${import.meta.env.VITE_API_URL_SYSTEM}/v1/sys/ident/getList`, {
        ...params,
        pageNumber: 1,
        pageSize: -1, //每个分类都不会太多。直接查全部。
        classifyCode: active.value,
    }).then((res) => {
        if (res.code === 1) {
            let data = res.data.rows
            rows.value = data.map((d) => {
                const path = JSON.parse(d.identImg)[0].path
                d.url = import.meta.env.VITE_API_URL_STATIC + path
                return d
            })
        }
    })
}

const groupClick = (item) => {
    active.value = item.code
    search()
}

/**
 * 选择图标
 * @param item
 */
const chooseImg = (item) => {
    const index = chooseId.value.findIndex((v: any) => v === item.id)
    if (index === -1) {
        chooseId.value.push(item.id)
        chooseIdent.value.push(JSON.parse(item.identImg)[0])
    } else {
        chooseId.value.splice(index, 1)
        chooseIdent.value.splice(index, 1)
    }
}
const emits = defineEmits(['ok'])
const onSubmit = () => {
    emits('ok', chooseIdent.value)
    visible.value = false
}
</script>

<style scoped lang="less">
@import '@/theme/theme.less';

.main {
    background: @component-background;
    display: flex;
}

.left {
    padding: 10px;
    width: 150px;
    &::-webkit-scrollbar {
        width: 8px;
        height: 10px;
        background-color: #f8f9fa;
    }
    &::-webkit-scrollbar-thumb {
        background: rgba(0, 0, 0, 0.2);
        border-radius: 0;
    }
    .group-menu {
        height: 400px;
        overflow-y: auto;
        -webkit-box-flex: 1;
        -webkit-flex-grow: 1;
        flex-grow: 1;
        .group-item {
            border-radius: 4px;
            .group-item-link {
                position: relative;
                margin: 0;
                padding: 0 10px 0 28px;
                line-height: 40px;
                color: #222222;
                display: block;
            }
            &.active {
                background-color: @primary-2;
            }
            &:hover {
                background-color: @primary-2;
            }
        }
    }
}
.right {
    flex: 1;
    .images {
        display: inline-block;
        position: relative;
        width: 110px;
        height: 110px;
        margin: 5px;
        padding: 5px;
        .images-item {
            width: 100%;
            position: relative;
            display: block;
            height: 100%;
            background-size: contain;
            background-position: 50% 50%;
            background-repeat: no-repeat;
            -webkit-box-sizing: border-box;
            box-sizing: border-box;
            border-radius: 2px;
            overflow: hidden;
        }
        .mask {
            position: absolute;
            top: 0;
            right: 0;
            bottom: 0;
            left: 0;
            cursor: pointer;
            &:hover {
                border: 2px solid @primary-color;
            }
            &.active {
                border: 2px solid @primary-color;
                background-color: fade(@primary-color, 15%);
            }
        }
        .uwo-checkbox-fill {
            position: absolute;
            top: 0;
            left: 8px;
            color: @primary-color;
        }
    }
}
</style>
