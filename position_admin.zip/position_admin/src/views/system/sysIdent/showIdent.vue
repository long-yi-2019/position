<!--详情-->
<template>
    <YxModal
        ref="YxModalRef"
        :title="modalTitle"
        v-model:visible="visible"
        @ok="onSubmit"
        @cancel="onCancel"
        :submit-loading="submitLoading"
    >
        <div class="main">
            <div class="left">
                <GroupIndex ref="GroupIndexRef" @click="menuClick"></GroupIndex>
            </div>
            <div class="table-container">
                <MyTablePage
                    style="overflow: auto"
                    ref="MyTablePageRef"
                    :search-item="searchItem"
                    :url="dataUrl"
                    :columns="columns"
                    :ellipsis="1"
                    show-index
                    pagination
                    selection="checkbox"
                >
                </MyTablePage>
            </div>
        </div>
    </YxModal>
</template>
<script setup lang="ts" name="Ident">
import { nextTick, ref } from 'vue'
import GroupIndex from '@/views/system/sysIdent/groupIndex.vue'
const GroupIndexRef = ref()
/**
 * 基础数据定义
 */
const visible = ref(false)
const submitLoading = ref(false)
const modalTitle = ref('实验室信息牌')

const selectedKeys = ref<any>([])
const MyTablePageRef = ref()
const dataUrl = `${import.meta.env.VITE_API_URL_SYSTEM}/v1/sys/ident/getList`
const identType = ref<number>()

const rootUrl = import.meta.env.VITE_API_URL_STATIC

const show = (type: number) => {
    visible.value = true
    identType.value = type
    /**
     * 初始参数
     */
    nextTick(() => {
        GroupIndexRef.value.init()
    })
}
/*列配置 api https://itvita.gitee.io/liuyunxi-antd-extend/#/YxTable*/
const columns = ref<any[]>([
    {
        title: '名称',
        dataIndex: 'name',
        hidden: false,
    },
    {
        title: '图标',
        dataIndex: 'identImg',
        hidden: false,
        formatter: {
            type: 'image',
            format: (row: any): any => {
                const identImg = JSON.parse(row.identImg)[0]
                return [
                    {
                        name: rootUrl + identImg.name,
                        src: rootUrl + identImg.path,
                    },
                ]
            },
        },
    },
    {
        title: '备注',
        dataIndex: 'remark',
        hidden: false,
    },
])
/*搜索条配置 api https://itvita.gitee.io/liuyunxi-antd-extend/#/YxSearch*/
const searchItem = ref<any[]>([
    {
        type: 'text',
        key: 'name',
        label: '名称',
        value: '',
        placeholder: '',
    },
])
defineExpose({ show })
const emits = defineEmits(['ok'])

const menuClick = (key) => {
    selectedKeys.value = key
    MyTablePageRef.value.search({ classifyCode: key })
}
//确定
const onSubmit = () => {
    const rows = MyTablePageRef.value.getSelection().selectedRows
    emits('ok', identType.value, rows)
    onCancel()
}
/**
 * 关闭弹窗
 */
const onCancel = () => {
    visible.value = false
}
</script>
<style scoped lang="less">
@import '@/theme/theme.less';

.main {
    background: @component-background;
}

.left {
    float: left;
    //margin-right: 20px;
    min-height: 100%;
    max-height: calc(100vh - 250px);
    padding: 10px;

    &::-webkit-scrollbar {
        width: 8px;
        height: 10px;
        background-color: #f8f9fa;
    }

    &::-webkit-scrollbar-thumb {
        background: rgba(0, 0, 0, 0.2);
        border-radius: 0;
    }
}
</style>
