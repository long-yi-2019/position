<template>
    <PageWrapper title="安全图标库" sub-title="">
        <div class="main">
            <div class="left">
                <GroupIndex ref="GroupIndexRef" @click="menuClick"></GroupIndex>
            </div>
            <div class="table-container" style="padding: 0 10px">
                <YxSearch ref="YxSearchRef" :items="searchItem" @search="search" />
                <ARow :gutter="10">
                    <ACol :span="24" style="margin-bottom: 10px">
                        <AButton type="primary" @click="handelAdd"><PlusOutlined />添加</AButton>
                    </ACol>
                    <ACol
                        :xs="24"
                        :sm="24"
                        :md="12"
                        :lg="8"
                        :xl="6"
                        :xxl="4"
                        :xxxl="3"
                        v-for="(item, index) in rows"
                        :key="index"
                        style="margin-bottom: 10px"
                    >
                        <ACard hoverable>
                            <template #cover>
                                <div style="padding: 8px 0; height: 120px">
                                    <AImage
                                        height="100%"
                                        width="100%"
                                        style="object-fit: contain"
                                        :src="item.url"
                                    />
                                </div>
                            </template>
                            <template #actions>
                                <div @click="handleEdit(item)"><EditOutlined key="edit" />编辑</div>
                                <div @click="deletes([item.id])">
                                    <DeleteOutlined key="delete" />删除
                                </div>
                            </template>
                        </ACard>
                    </ACol>
                </ARow>
                <div
                    v-if="(!spinning && rows.length === 0) || spinning"
                    style="
                        flex: 1;
                        text-align: center;
                        background: rgba(0, 0, 0, 0.05);
                        border-radius: 4px;
                        padding: 30px 50px;
                    "
                >
                    <AEmpty v-if="!spinning && rows.length === 0" />
                    <ASpin :spinning="spinning" />
                </div>
            </div>
        </div>
        <Edit ref="EditRef" @ok="search"></Edit>
    </PageWrapper>
</template>
<!--路由地址：/system/sysIdent/index ,组件名称：sysIdentIndex	-->
<script setup lang="ts" name="sysIdentIndex">
import { onMounted, ref } from 'vue'
import { PlusOutlined, EditOutlined, DeleteOutlined } from '@ant-design/icons-vue'
import { message, Modal } from 'ant-design-vue'
import { cloneDeep } from 'lodash-es'
import { del } from '@/api/system/sysIdent'
import Edit from './edit.vue'
const GroupIndexRef = ref()
const YxSearchRef = ref()
const EditRef = ref()
const spinning = ref(false)
const selectedKeys = ref<any>()
const MyTablePageRef = ref()
// import { getUserStore } from '@/store'
import GroupIndex from '@/views/system/sysIdent/groupIndex.vue'
import { getList } from '@/api/common'
import { assignIn } from '@/utils/ObjectUtils'

const rows = ref([])

// const userStore = getUserStore()

/*搜索条配置 api https://itvita.gitee.io/liuyunxi-antd-extend/#/YxSearch*/
const searchItem = ref<any[]>([
    {
        type: 'text',
        key: 'name',
        label: '名称',
        value: '',
        placeholder: '',
    },
])
/**
 * 批量删除方法
 * @param ids id数组
 */
const deletes = (ids?: string[]) => {
    if (ids === undefined) {
        const { selectedRowKeys } = MyTablePageRef.value.getSelection()
        ids = cloneDeep(selectedRowKeys)
    }
    if (!ids || ids?.length < 1) {
        Modal.warning({
            title: '请先选择删除项',
        })
        return
    }
    Modal.confirm({
        title: '确定删除？',
        content: '删除后将无法恢复',
        okType: 'danger',
        onOk() {
            del(ids).then((res: any) => {
                if (res.code === 1) {
                    message.success('删除成功')
                    search()
                }
            })
        },
    })
}
const handleEdit = (row) => {
    EditRef.value.show({ id: row.id })
}

/**
 * 添加
 */
const handelAdd = () => {
    if (!selectedKeys.value) {
        Modal.warning({
            title: '警告',
            content: '请先设置分组',
        })
        return
    }
    EditRef.value.show({ classifyCode: selectedKeys.value })
}

const menuClick = (key) => {
    selectedKeys.value = key
    search()
}

const search = (params?: any) => {
    spinning.value = true
    rows.value = []
    params = params || {}
    if (YxSearchRef.value) {
        assignIn(params, YxSearchRef.value.getValues())
    }
    getList(`${import.meta.env.VITE_API_URL_SYSTEM}/v1/sys/ident/getList`, {
        ...params,
        pageNumber: 1,
        pageSize: -1, //每个分类都不会太多。直接查全部。
        classifyCode: selectedKeys.value,
    }).then((res) => {
        if (res.code === 1) {
            const data = res.data.rows
            rows.value = data.map((d) => {
                const path = JSON.parse(d.identImg)[0].path
                d.url = import.meta.env.VITE_API_URL_STATIC + path
                return d
            })
        }
        spinning.value = false
    })
}

/**
 * 挂载，页面初始化后执行
 */
onMounted(async () => {
    GroupIndexRef.value.init()
})
</script>

<style scoped lang="less">
@import '@/theme/theme.less';

.main {
    background: @component-background;
}

.left {
    float: left;
    //margin-right: 20px;
    min-height: 100%;
    max-height: calc(100vh - 250px);
    padding: 10px;

    &::-webkit-scrollbar {
        width: 8px;
        height: 10px;
        background-color: #f8f9fa;
    }

    &::-webkit-scrollbar-thumb {
        background: rgba(0, 0, 0, 0.2);
        border-radius: 0;
    }
}
</style>
