<template>
    <YxModal
        ref="YxModalRef"
        title="确认收到"
        v-model:visible="visible"
        @ok="onSubmit"
        @cancel="onCancel"
        :submit-loading="submitLoading"
    >
        <div style="background-color: #ffffff; padding: 30px 80px">
            <h1 style="text-align: center">{{ row.title }}</h1>
            <div class="margin-top">
                <span class="kxFont kx-attention"> 发布时间：{{ row.createdTime }} </span>

                <APopover placement="bottom" trigger="hover">
                    <template #content>
                        <AList
                            size="small"
                            :data-source="readData"
                            style="max-height: calc(100vh - 350px); overflow: auto"
                        >
                            <template #renderItem="{ item }">
                                <AListItem>
                                    <span style="width: 200px">{{ item.userName }}</span>
                                    <ATag v-if="item.isRead === '1'" color="#87d068">已读</ATag>
                                    <ATag v-else color="#f50">未读</ATag>
                                </AListItem>
                            </template>
                        </AList>
                    </template>
                    <template #title>
                        <span>接收人</span>
                    </template>
                    <a
                        href="javascript:void(0)"
                        style="margin-left: 10px; cursor: pointer"
                        class="kxFont kx-attention"
                    >
                        已读：{{ readText }}
                    </a>
                </APopover>
            </div>
            <ADivider />
            <div v-html="row.content"></div>
            <div v-if="row.appendix && row.appendix.length > 0">
                <h2>附件：</h2>
                <a
                    style="display: block"
                    v-for="(item, index) in row.appendix"
                    :key="index"
                    :href="item.url || staticUrl + item.path"
                    target="_blank"
                >
                    {{ item.name }}
                </a>
            </div>
        </div>
    </YxModal>
</template>
<!--添加路由地址：/system/sysNotice/add，修改路由地址：/system/sysNotice/edit，组件地址：/system/sysNotice/edit-->
<script setup lang="ts">
import { onMounted, ref } from 'vue'
import { getRead } from '@/api/system/sysNotice'
import { edit } from '@/api/system/sysNoticeUser'
import { cloneDeep } from 'lodash-es'
import { message } from 'ant-design-vue'
import { getNoticeStore } from '@/store'
const noticeStore = getNoticeStore()

const staticUrl = import.meta.env.VITE_API_URL_STATIC
const visible = ref(false)
const submitLoading = ref(false)
const readData = ref([])
const readText = ref('0')
const row = ref({
    id: null,
    nuId: null,
    title: '',
    createdTime: '',
    content: '',
    appendix: [],
})
const show = (param: any) => {
    const r = cloneDeep(param)
    r.appendix = JSON.parse(r.appendix || [])
    row.value = r
    visible.value = true

    getRead({ id: r.id }).then((res) => {
        if (res.code === 1) {
            readData.value = res.data
            let e = 0,
                n = 0
            readData.value.forEach((value: any) => {
                if (value.isRead === '1') {
                    e += 1
                }
                n += 1
            })
            readText.value = e + '/' + n
        }
    })
}
/**
 * 接收方法
 */
const emits = defineEmits(['ok'])
const onSubmit = () => {
    submitLoading.value = true
    edit({ id: row.value.nuId, isRead: '2' }).then((res) => {
        if (res.code === 1) {
            emits('ok')
            message.success('提交成功')
            // 未读通知数量
            noticeStore.getUnreadNum()
            onCancel()
        }
    })
}
/**
 * 关闭弹窗
 */
const onCancel = () => {
    visible.value = false
}
defineExpose({ show })
onMounted(() => {})
</script>

<style scoped lang="less"></style>
