<template>
    <PageWrapper title="发布公告" sub-title="">
        <MyTablePage
            ref="MyTablePageRef"
            :search-item="searchItem"
            :url="dataUrl"
            :columns="columns"
            :action="action"
            :ellipsis="1"
            show-index
            pagination
            selection="checkbox"
        >
            <template #tools>
                <AButton v-permission="'sysNoticeAdd'" type="primary" @click="handelAdd">
                    <template #icon>
                        <PlusOutlined />
                    </template>
                    添加
                </AButton>
                <AButton v-permission="'sysNoticeDelete'" type="danger" @click="deletes()">
                    <template #icon>
                        <DeleteOutlined />
                    </template>
                    批量删除
                </AButton>
                <AButton
                    v-permission="'sysNoticeExport'"
                    type="success"
                    @click="MyTablePageRef.handleExport('通知公告')"
                >
                    <template #icon>
                        <DownloadOutlined />
                    </template>
                    导出
                </AButton>
            </template>
        </MyTablePage>
        <Edit ref="EditRef" @ok="MyTablePageRef.search()"></Edit>
        <Detail ref="detailRef"></Detail>
    </PageWrapper>
</template>
<!--路由地址：/system/sysNotice/index ,组件名称：sysNoticeIndex	-->
<script setup lang="ts" name="sysNoticeIndex">
import { onMounted, ref } from 'vue'
import { DeleteOutlined, PlusOutlined, DownloadOutlined } from '@ant-design/icons-vue'
import { message, Modal } from 'ant-design-vue'
import { cloneDeep } from 'lodash-es'
import { del } from '@/api/system/sysNotice'
import Edit from './edit.vue'
import Detail from './detail.vue'

const EditRef = ref()
const detailRef = ref()
const MyTablePageRef = ref()
const dataUrl = `${import.meta.env.VITE_API_URL_SYSTEM}/v1/sys/notice/getList`

/*列配置 api https://itvita.gitee.io/liuyunxi-antd-extend/#/YxTable*/
const columns = ref<any[]>([
    {
        title: '标题',
        dataIndex: 'title',
        hidden: false,
        sorter: true,
        width: 400,
    },
    {
        title: '发布时间',
        dataIndex: 'createdTime',
        hidden: false,
        sorter: true,
        width: 100,
    },
    {
        title: '要求回复',
        hidden: false,
        sorter: true,
        width: 100,
        formatter: {
            type: 'text',
            format: (row) => {
                if (row.requireReply === '1') {
                    return {
                        value: '是',
                    }
                } else {
                    return {
                        value: '否',
                    }
                }
            },
        },
    },
    {
        title: '已读',
        hidden: false,
        sorter: true,
        width: 100,
        click: (row: any) => {
            detailRef.value.show(row)
        },
        formatter: {
            type: 'text',
            format: (row) => {
                return {
                    value: row.readUserNum,
                    color: 'success',
                }
            },
        },
    },
    {
        title: '未读',
        hidden: false,
        sorter: true,
        width: 100,
        click: (row: any) => {
            detailRef.value.show(row)
        },
        formatter: {
            type: 'text',
            format: (row) => {
                return {
                    value: row.userNum - row.readUserNum,
                    color: 'danger',
                }
            },
        },
    },
    {
        title: '内容',
        dataIndex: 'content',
        hidden: true,
        sorter: true,
        width: 200,
    },
    {
        title: '附件',
        dataIndex: 'appendix',
        hidden: true,
        sorter: true,
        width: 200,
    },
])
/*搜索条配置 api https://itvita.gitee.io/liuyunxi-antd-extend/#/YxSearch*/
const searchItem = ref<any[]>([
    {
        type: 'text',
        key: 'title',
        label: '标题',
        value: '',
        placeholder: '',
    },
])
/**
 * 批量删除方法
 * @param ids id数组
 */
const deletes = (ids?: string[]) => {
    if (ids === undefined) {
        const { selectedRowKeys } = MyTablePageRef.value.getSelection()
        ids = cloneDeep(selectedRowKeys)
    }
    if (!ids || ids?.length < 1) {
        Modal.warning({
            title: '请先选择删除项',
        })
        return
    }
    Modal.confirm({
        title: '确定删除？',
        content: '删除后将无法恢复',
        okType: 'danger',
        onOk() {
            del(ids).then((res: any) => {
                if (res.code === 1) {
                    message.success('删除成功')
                    MyTablePageRef.value.search()
                }
            })
        },
    })
}
/*table 操作列配置*/
const action = ref({
    width: 200,
    fixed: 'right',
    buttons: [
        {
            title: '详情',
            icon: 'iconfont icon-caidan',
            event: (row: any) => {
                // MyTablePageRef.value.showDetail(row)
                detailRef.value.show(row)
            },
        },
        {
            title: '编辑',
            icon: 'iconfont icon-bianji',
            permission: 'sysNoticeEdit',
            event: (row: any) => {
                EditRef.value.show({ id: row.id })
            },
        },
        {
            title: '删除',
            color: '#f12424', // primary,success,warn,danger,info
            icon: 'iconfont icon-shanchu',
            permission: 'sysNoticeDelete',
            event: (row: any) => {
                deletes([row.id])
            },
        },
    ],
})

/**
 * 添加
 */
const handelAdd = () => {
    EditRef.value.show()
}

/**
 * 挂载，页面初始化后执行
 */
onMounted(() => {
    MyTablePageRef.value.search()
})
</script>

<style scoped lang="less"></style>
