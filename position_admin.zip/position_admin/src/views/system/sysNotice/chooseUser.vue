<!--选择人员-->
<template>
    <YxModal
        ref="YxModalRef"
        title="选择人员"
        v-model:visible="visible"
        @ok="onSubmit"
        @cancel="onCancel"
        :submit-loading="submitLoading"
    >
        <ARow :gutter="0">
            <ACol :span="18">
                <MyTreeTablePage
                    ref="MyTreeTablePageRef"
                    :search-item="searchItem"
                    :url="dataUrl"
                    :columns="columns"
                    :action="action"
                    :ellipsis="1"
                    :tree="treeConfig"
                >
                    <template #tools>
                        <AButton v-permission="'sysUserAdd'" type="primary" @click="handelAdd()">
                            <template #icon>
                                <PlusOutlined />
                            </template>
                            选择全部
                        </AButton>
                    </template>
                </MyTreeTablePage>
            </ACol>
            <ACol :span="6">
                <ACard
                    size="mini"
                    :bodyStyle="{
                        maxHeight: 'calc(100vh - 316px)',
                        overflow: 'auto',
                    }"
                >
                    <template #title> 已选：{{ selected.length }} </template>
                    <template #extra
                        ><a class="text-red" href="javascript:void(0)" @click="handelRemove()"
                            >全部移除</a
                        ></template
                    >
                    <AList size="small" bordered :data-source="selected">
                        <template #renderItem="{ item }">
                            <AListItem>
                                <template #actions>
                                    <a
                                        class="text-red"
                                        href="javascript:void(0)"
                                        @click="handelRemove(item)"
                                        >移除</a
                                    >
                                </template>
                                {{ item.userName }}
                            </AListItem>
                        </template>
                    </AList>
                </ACard>
            </ACol>
        </ARow>
    </YxModal>
</template>
<script setup lang="ts" name="chooseUser">
import { nextTick, onMounted, reactive, ref } from 'vue'
import { PlusOutlined } from '@ant-design/icons-vue'
// import { message, Modal } from 'ant-design-vue'
// import { cloneDeep } from 'lodash-es'
// import { del } from '@/api/system/sysUser'
const MyTreeTablePageRef = ref()

const visible = ref(false)
const submitLoading = ref(false)

const selected = ref<any>([])

/**
 * 移除
 */
const handelRemove = (item: any) => {
    if (item === undefined) {
        selected.value = []
    } else {
        selected.value = selected.value.filter((r: any) => r.id !== item.id)
    }
}
/**
 * 显示弹窗
 */
const show = (params?: any) => {
    selected.value = Object.assign([], params)
    console.log(params)
    visible.value = true
    /**
     * 初始参数
     */
    nextTick(() => {
        MyTreeTablePageRef.value.init()
    })
}
defineExpose({ show })

/**
 * 接收方法
 */
const emits = defineEmits(['ok', 'change'])

/**
 * 提交方法
 */
const onSubmit = () => {
    submitLoading.value = true
    emits('ok', selected.value)
    emits('change', selected.value)
    submitLoading.value = false
    onCancel()
}
/**
 * 关闭弹窗
 */
const onCancel = () => {
    visible.value = false
}

const dataUrl = `${import.meta.env.VITE_API_URL_SYSTEM}/v1/sys/user/getList?state=1`
const selectNode = ref({
    id: '0',
    code: '1',
    name: '跟目录',
})

/*列配置 api https://itvita.gitee.io/liuyunxi-antd-extend/#/YxTable*/
const columns = ref([
    {
        title: '姓名',
        dataIndex: 'userName',
        hidden: false,
        align: 'left',
        fixed: 'none',
        sorter: true,
    },
    {
        title: '帐号',
        dataIndex: 'accountName',
        hidden: false,
        sorter: true,
        align: 'left',
        fixed: 'none',
    },
])

/*搜索条配置 api https://itvita.gitee.io/liuyunxi-antd-extend/#/YxSearch*/
const searchItem = ref([
    {
        type: 'text',
        key: 'userName',
        label: '姓名',
        value: '',
        placeholder: '',
    },
    {
        type: 'text',
        key: 'phoneNumber',
        label: '手机号',
        value: '',
        placeholder: '',
    },
])

/**
 * 添加
 */
const handelAdd = () => {
    const data = MyTreeTablePageRef.value.getData()
    selected.value = Object.assign([], data)
}

/*操作列配置*/
const action = ref({
    width: 80,
    fixed: 'right',
    buttons: [
        {
            title: '选择',
            icon: 'pointer-up',
            event: (row: any) => {
                const result = selected.value.filter((r: any) => r.id === row.id)
                if (result.length < 1) {
                    selected.value.push(row)
                }
            },
        },
    ],
})

/*树形配置*/
const treeConfig = reactive({
    url: `${import.meta.env.VITE_API_URL_SYSTEM}/v1/sys/department/getZtree`,
    drag: false,
    add: false,
    edit: false,
    remove: false,
    handelClick: (treeNodes: any) => {
        selectNode.value = treeNodes
        MyTreeTablePageRef.value.search()
    },
})

onMounted(() => {})
</script>
<style scoped lang="less"></style>
