<template>
    <YxModal
        ref="YxModalRef"
        :title="modalTitle"
        v-model:visible="visible"
        @ok="onSubmit"
        @cancel="onCancel"
        :submit-loading="submitLoading"
    >
        <AForm
            class="padding"
            ref="myFormRef"
            name="myFormRef"
            :model="formRef"
            :label-col="{ span: 4 }"
            :wrapper-col="{ span: 14 }"
        >
            <AFormItem
                label="标题"
                name="title"
                :rules="[{ max: 90, message: '必填，最大长度90', required: true }]"
            >
                <AInput v-model:value="formRef.title" placeholder=""></AInput>
            </AFormItem>
            <AFormItem label="内容" name="content" :rules="[{ required: true }]">
                <YxRichText
                    height="300px"
                    upload-url=""
                    root-url=""
                    :size="3"
                    :compress="1"
                    :headers="{
                        token: '',
                    }"
                    v-model:value="formRef.content"
                ></YxRichText>
            </AFormItem>
            <AFormItem label="要求回复" name="requireReply" extra="">
                <ARadioGroup v-model:value="formRef.requireReply" :options="requireReplyOptions" />
            </AFormItem>
            <AFormItem label="附件" name="appendix" ref="appendix" extra="最多上传5个且单个最大50M">
                <YxUpload
                    v-model:value="formRef.appendix"
                    :action="action"
                    :rootUrl="rootUrl"
                    :headers="getTokenHeader"
                    :compress="0.5"
                    :max="5"
                    @change="
                        () => {
                            $refs.appendix.onFieldChange()
                        }
                    "
                    :size="50"
                    accept=".jpg,.jpeg,.png,.doc,.docx,.xls,.xlsx,.pdf"
                ></YxUpload>
            </AFormItem>
            <AFormItem
                label="接收人"
                name="recipient"
                ref="recipient"
                :rules="[{ required: true, message: '请选择接收人', trigger: 'change' }]"
            >
                <AButton type="primary" size="mini" @click="chooseUser">选择人员</AButton>
                <div>
                    <template v-for="(item, index) in formRef.recipient" :key="index">
                        <ATag
                            @close.prevent="handleClose(item)"
                            :closable="true"
                            class="margin-top-xs"
                            color="blue"
                        >
                            {{ item.userName }}
                        </ATag>
                    </template>
                </div>
            </AFormItem>
        </AForm>
    </YxModal>
    <ChooseUser ref="ChooseUserRef" @ok="chooseOk"></ChooseUser>
</template>
<!--添加路由地址：/system/sysNotice/add，修改路由地址：/system/sysNotice/edit，组件地址：/system/sysNotice/edit-->
<script setup lang="ts">
import { FormInstance, message } from 'ant-design-vue'
import ChooseUser from './chooseUser.vue'
import { getTokenHeader } from '@/utils/tokenUtil'
import { ref } from 'vue'
import { edit, get, save } from '@/api/system/sysNotice'
import { cloneDeep } from 'lodash-es'
import { leftCover } from '@/utils/ObjectUtils'
import { getNoticeStore } from '@/store'
const noticeStore = getNoticeStore()

const action = import.meta.env.VITE_API_URL_UPLOAD
const rootUrl = import.meta.env.VITE_API_URL_STATIC
const ChooseUserRef = ref()
const recipient = ref()

/**
 * 基础数据定义
 */
const visible = ref(false)
const submitLoading = ref(false)
const modalTitle = ref('发布通知公告')

const myFormRef = ref<FormInstance>()
const defaultForm = {
    id: null, //主键ID
    title: '', //标题
    content: '', //内容
    requireReply: '1', //是否要求回复
    appendix: [] as any, //附件
    recipient: [] as any, //接收人
}
const formRef = ref<any>({
    ...defaultForm,
})
/**
 * 要求回复选项
 */
const requireReplyOptions = ref([
    { label: '是', value: '1' },
    { label: '否', value: '0' },
])

/**
 * 选择人员
 */
const chooseUser = () => {
    ChooseUserRef.value.show(formRef.value.recipient)
}
/**
 * 选择完成
 * @param sel
 */
const chooseOk = (sel: any) => {
    formRef.value.recipient = [...sel]
    recipient.value.onFieldChange()
}
/**
 * 删除人员
 */
const handleClose = (item: any) => {
    const tags = formRef.value.recipient.filter((tag: any) => tag !== item)
    formRef.value.recipient = tags
}
/**
 * 显示弹窗
 */
const show = (params?: any) => {
    params = params || {}
    visible.value = true
    /**
     * 初始参数
     */
    formRef.value = Object.assign({}, { ...defaultForm })
    leftCover(formRef.value, params || {})

    if (params.id) {
        modalTitle.value = '编辑通知公告'
        get({ id: params.id }).then((res: any) => {
            const data = res.data
            data.appendix = JSON.parse(data.appendix)
            data.recipient = data.recipientInfo
            leftCover(formRef.value, data)
        })
    }
}
defineExpose({ show })

/**
 * 接收方法
 */
const emits = defineEmits(['ok'])
/**
 * 提交方法
 */
const onSubmit = () => {
    console.log(formRef.value)
    myFormRef.value?.validate().then(() => {
        submitLoading.value = true
        const params = cloneDeep(formRef.value)
        console.log(params)
        params.appendix = JSON.stringify(params.appendix)
        let recipient: any[] = []
        params.recipient.forEach((v: any) => {
            recipient.push(v.id)
        })
        params.recipient = recipient
        if (params.id) {
            edit(params).then((res: any) => {
                if (res.code === 1) {
                    emits('ok')
                    message.success('提交成功')
                    // 未读通知数量
                    noticeStore.getUnreadNum()
                    onCancel()
                }
                submitLoading.value = false
            })
        } else {
            save(params).then((res: any) => {
                if (res.code === 1) {
                    emits('ok')
                    message.success('提交成功')
                    // 未读通知数量
                    noticeStore.getUnreadNum()
                    onCancel()
                }
                submitLoading.value = false
            })
        }
    })
}
/**
 * 关闭弹窗
 */
const onCancel = () => {
    myFormRef.value?.resetFields()
    visible.value = false
}
</script>

<style scoped lang="less"></style>
