<!--我的收到的通知公告-->
<template>
    <PageWrapper title="我的消息" sub-title="">
        <MyTablePage
            :showTools="false"
            ref="MyTablePageRef"
            :search-item="searchItem"
            :url="dataUrl"
            :columns="columns"
            :action="action"
            :ellipsis="1"
            show-index
            pagination
        >
        </MyTablePage>
        <Detail ref="detailRef"></Detail>
        <Replay ref="ReplayRef" @ok="MyTablePageRef.search()"></Replay>
    </PageWrapper>
</template>
<script setup lang="ts" name="myNotice">
import { onMounted, ref } from 'vue'
const detailRef = ref()
const ReplayRef = ref()
const MyTablePageRef = ref()
const dataUrl = `${import.meta.env.VITE_API_URL_SYSTEM}/v1/sys/notice/getMyList`
import Detail from './detail.vue'
import Replay from './replay.vue'
import { edit } from '@/api/system/sysNoticeUser'
import { getNoticeStore } from '@/store'
const noticeStore = getNoticeStore()
/*列配置 api https://itvita.gitee.io/liuyunxi-antd-extend/#/YxTable*/
const columns = ref<any[]>([
    {
        title: '标题',
        dataIndex: 'title',
        hidden: false,
        sorter: true,
        width: 280,
    },
    {
        title: '发布日期',
        dataIndex: 'createdTime',
        hidden: false,
        sorter: true,
        width: 120,
    },
    {
        title: '状态',
        dataIndex: 'isRead',
        hidden: false,
        sorter: true,
        width: 70,
        formatter: {
            type: 'text',
            format: (row: any) => {
                if (row.isRead === '1') {
                    return {
                        value: '已读',
                        color: 'success',
                    }
                } else if (row.isRead === '2') {
                    return {
                        value: '已读并回复',
                        color: 'success',
                    }
                } else {
                    return {
                        value: '未读',
                        color: 'danger',
                    }
                }
            },
        },
    },
    {
        title: '附件',
        dataIndex: 'appendix',
        hidden: true,
        sorter: true,
        width: 200,
    },
])

/*搜索条配置 api https://itvita.gitee.io/liuyunxi-antd-extend/#/YxSearch*/
const searchItem = ref<any[]>([
    {
        type: 'text',
        key: 'title',
        label: '标题',
        value: '',
        placeholder: '',
    },
])

/*table 操作列配置*/
const action = ref({
    width: 200,
    buttons: [
        {
            title: '详情',
            icon: 'iconfont icon-caidan',
            event: (row: any) => {
                if (row.isRead === '0') {
                    edit({ id: row.nuId, isRead: '1' }).then((res) => {
                        if (res.code === 1) {
                            row.isRead = '1'
                            noticeStore.unReadNum = noticeStore.unReadNum - 1
                        }
                    })
                }
                detailRef.value.show(row)
            },
        },
        {
            title: '确认收到',
            icon: 'iconfont icon-caidan',
            hide: (row: any) => row.requireReply === '0' || row.isRead === '2',
            event: (row: any) => {
                ReplayRef.value.show(row)
            },
        },
        {
            title: '标记已读',
            icon: 'iconfont icon-bianji',
            hide: (row: any) => row.isRead !== '0',
            event: (row: any) => {
                edit({ id: row.nuId, isRead: '1' }).then((res) => {
                    if (res.code === 1) {
                        row.isRead = '1'
                        // 未读通知数量
                        noticeStore.getUnreadNum()
                    }
                })
            },
        },
    ],
})
/**
 * 挂载，页面初始化后执行
 */
onMounted(() => {
    MyTablePageRef.value.search()
})
</script>
<style scoped lang="less"></style>
