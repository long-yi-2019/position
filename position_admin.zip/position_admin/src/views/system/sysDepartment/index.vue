<template>
    <PageWrapper title="机构管理" sub-title="">
        <MyTreeTablePage
            ref="MyTreeTablePageRef"
            :search-item="searchItem"
            :url="dataUrl"
            :columns="columns"
            :action="action"
            :ellipsis="1"
            pagination
            show-index
            :tree="treeConfig"
        >
            <template #tools>
                <AButton v-permission="'sysDepartmentAdd'" type="primary" @click="handelAdd()">
                    <template #icon>
                        <PlusOutlined />
                    </template>
                    添加
                </AButton>
                <AButton
                    v-permission="'sysDepartmentImport'"
                    type="primary"
                    @click="handelImport()"
                >
                    <template #icon>
                        <PlusOutlined />
                    </template>
                    导入
                </AButton>
                <AButton
                    v-permission="'sysDepartmentExport'"
                    type="success"
                    @click="MyTreeTablePageRef.handleExport('机构')"
                >
                    <template #icon>
                        <DownloadOutlined />
                    </template>
                    导出
                </AButton>
            </template>
        </MyTreeTablePage>
        <Edit ref="EditRef" @ok="MyTreeTablePageRef.init()"></Edit>
    </PageWrapper>
</template>
<!--路由地址：/system/sysDepartment/index ,组件名称：sysDepartmentIndex	-->
<script setup lang="ts" name="sysDepartmentIndex">
import { PlusOutlined, DownloadOutlined } from '@ant-design/icons-vue'
import { onMounted, reactive, ref } from 'vue'
import { message, Modal } from 'ant-design-vue'
import { del } from '@/api/system/sysDepartment'

import Edit from './edit.vue'
const EditRef = ref()
const MyTreeTablePageRef = ref()
const dataUrl = `${import.meta.env.VITE_API_URL_SYSTEM}/v1/sys/department/getList`
const selectNode = ref({
    id: '',
    name: '',
    code: '',
    type: '',
})

/*列配置 api https://itvita.gitee.io/liuyunxi-antd-extend/#/YxTable*/
const columns = ref([
    {
        title: '顺序号',
        dataIndex: 'seq',
        hidden: true,
        align: 'left',
        fixed: 'none',
    },
    {
        title: '名称',
        dataIndex: 'name',
        hidden: false,
        align: 'left',
        fixed: 'none',
    },
    {
        title: '组织代码',
        dataIndex: 'deptCode',
        hidden: true,
        align: 'left',
        fixed: 'none',
    },
    {
        title: '层级编码',
        dataIndex: 'code',
        hidden: true,
        align: 'left',
        fixed: 'none',
    },
    {
        title: '全称',
        dataIndex: 'fullName',
        hidden: true,
        align: 'left',
        fixed: 'none',
    },
    {
        title: '备注',
        dataIndex: 'remark',
        hidden: false,
        align: 'left',
        fixed: 'none',
    },
])

/*搜索条配置 api https://itvita.gitee.io/liuyunxi-antd-extend/#/YxSearch*/
const searchItem = ref([
    {
        type: 'text',
        key: 'name',
        label: '名称',
        value: '',
        placeholder: '',
    },
])

/**
 * 添加
 * @param treeNode
 */
const handelAdd = (treeNode?: any) => {
    if (treeNode) {
        selectNode.value = {
            id: treeNode.id,
            name: treeNode.name,
            code: treeNode.code,
            type: treeNode.data.type,
        }
    }
    EditRef.value.show({ parentId: selectNode.value.id, type: selectNode.value.type })
}

/**
 * 编辑
 * @param id 选中ID
 */
const handelEdit = ({ id }: { id: string }) => {
    EditRef.value.show({ id: id })
}

/**
 * 删除，选中的ID数组
 * @param ids
 */
const handelDelete = (ids?: string[]) => {
    Modal.confirm({
        title: '确定删除？',
        content: '如果该机构有子节点，则子节点也会被删除，且删除后无法恢复！！！',
        okType: 'danger',
        onOk() {
            del(ids).then((res: any) => {
                if (res.code === 1) {
                    message.success('删除成功').then(() => {})
                    MyTreeTablePageRef.value.init()
                }
            })
        },
    })
}

/*操作列配置*/
const action = ref({
    width: 200,
    fixed: 'right',
    buttons: [
        {
            title: '详情',
            icon: 'iconfont icon-caidan',
            event: (row: any) => {
                MyTreeTablePageRef.value.showDetail(row)
            },
        },
        {
            title: '编辑',
            icon: 'iconfont icon-bianji',
            permission: 'sysDepartmentEdit',
            event: (row: any) => {
                handelEdit({ id: row.id })
            },
        },
        {
            title: '删除',
            color: '#f12424', // primary,success,warn,danger,info
            icon: 'iconfont icon-shanchu',
            permission: 'sysDepartmentDelete',
            event: (row: any) => {
                handelDelete([row.id])
            },
        },
    ],
})

/*树形配置*/
const treeConfig = reactive({
    url: `${import.meta.env.VITE_API_URL_SYSTEM}/v1/sys/department/getZtree`,
    drag: true,
    add: true,
    edit: true,
    remove: true,
    handelClick: (treeNode: any) => {
        selectNode.value = {
            id: treeNode.id,
            name: treeNode.name,
            code: treeNode.code,
            type: treeNode.data.type,
        }
        MyTreeTablePageRef.value.search()
    },
    handelAdd: handelAdd,
    handelRemove: (treeNodes: any) => {
        if (treeNodes.code === '100') {
            Modal.warning({
                title: '警告',
                content: '跟节点禁止删除',
            })
            return
        }
        handelDelete([treeNodes.id])
    },
    handelEdit: (treeNodes: any) => {
        handelEdit({ id: treeNodes.id })
    },
})

/**
 * 挂载，页面初始化后执行
 */
onMounted(() => {
    MyTreeTablePageRef.value.init()
})

const handelImport = () => {
    MyTreeTablePageRef.value.handleImport({
        uploadUrl: `${import.meta.env.VITE_API_URL_SYSTEM}/v1/sys/department/import`,
        templateUrl: `${import.meta.env.VITE_API_URL_SYSTEM}/v1/sys/department/import/template`,
        templateName: '机构导入模板.xlsx',
    })
}
</script>

<style scoped lang="less"></style>
