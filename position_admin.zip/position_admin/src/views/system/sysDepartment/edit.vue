<template>
    <YxModal
        ref="YxModalRef"
        :title="modalTitle"
        v-model:visible="visible"
        @ok="onSubmit"
        @cancel="onCancel"
        :submit-loading="submitLoading"
    >
        <AForm
            class="padding"
            ref="myFormRef"
            name="myFormRef"
            :model="formRef"
            :label-col="{ span: 4 }"
            :wrapper-col="{ span: 14 }"
        >
            <AFormItem label="上级机构" name="parentId" :rules="[]">
                <ATreeSelect
                    v-model:value="formRef.parentId"
                    v-model:searchValue="parentIdSearchValue"
                    :disabled="!!formRef.id"
                    show-search
                    style="width: 100%"
                    treeNodeFilterProp="title"
                    :dropdown-style="{ maxHeight: '400px', overflow: 'auto' }"
                    placeholder=""
                    allow-clear
                    tree-default-expand-all
                    :tree-data="parentIdOptions"
                    @select="parentSelect"
                    :fieldNames="{
                        children: 'children',
                        label: 'title',
                        key: 'id',
                        value: 'id',
                    }"
                >
                    <template #title="{ title }">
                        <template
                            v-for="(fragment, i) in (title || '')
                                .toString()
                                .split(
                                    new RegExp(
                                        `(?<=${parentIdSearchValue})|(?=${parentIdSearchValue})`,
                                        'i',
                                    ),
                                )"
                        >
                            <span
                                v-if="fragment.toLowerCase() === parentIdSearchValue.toLowerCase()"
                                :key="i"
                                style="color: #08c"
                            >
                                {{ fragment }}
                            </span>
                            <template v-else>{{ fragment }}</template>
                        </template>
                    </template>
                </ATreeSelect>
            </AFormItem>

            <AFormItem
                label="名称"
                name="name"
                :rules="[{ max: 30, message: '必填，最大长度30', required: true }]"
            >
                <AInput v-model:value="formRef.name" placeholder=""></AInput>
            </AFormItem>
            <AFormItem
                label="编码"
                name="deptCode"
                :rules="[{ max: 30, message: '必填，最大长度20', required: true }]"
            >
                <AInput v-model:value="formRef.deptCode" placeholder=""></AInput>
            </AFormItem>
            <AFormItem label="机构类型" name="type" extra="" :rules="[{ required: true }]">
                <ARadioGroup
                    :disabled="disableType"
                    v-model:value="formRef.type"
                    :options="[
                        { label: '部门', value: '2' },
                        { label: '院系', value: '3' },
                        { label: '科研中心', value: '4' },
                        { label: '附属医院', value: '5' },
                    ]"
                ></ARadioGroup>
            </AFormItem>

            <AFormItem label="顺序号" name="seq" :rules="[{ required: true }]">
                <AInput v-model:value="formRef.seq" placeholder=""></AInput>
            </AFormItem>
            <AFormItem label="备注" name="remark" :rules="[{}]">
                <ATextarea v-model:value="formRef.remark" placeholder="" :rows="3" />
            </AFormItem>
        </AForm>
    </YxModal>
</template>
<!--添加路由地址：/system/sysDepartment/add，修改路由地址：/system/sysDepartment/edit，组件地址：/system/sysDepartment/edit-->
<script setup lang="ts">
import { FormInstance, message } from 'ant-design-vue'
import { ref } from 'vue'
import { save, edit, get } from '@/api/system/sysDepartment'
import { leftCover } from '@/utils/ObjectUtils'

/**
 * 基础数据定义
 */
const visible = ref(false)
const submitLoading = ref(false)
const modalTitle = ref('添加机构')
const disableType = ref(false)
const myFormRef = ref<FormInstance>()
const defaultForm = {
    id: null, //主键ID
    parentId: '', //上级ID
    type: '', //类型；1学校，2部门，3院系，4科研中心，5附属医院',
    seq: '30', //顺序号
    name: '', //名称
    deptCode: '', //编码
    remark: '', //备注
}

const formRef = ref<any>(defaultForm)

/**
 * 上级ID选项
 */
import { getList } from '@/api/common'
import { cloneDeep } from 'lodash-es'
const parentIdOptions = ref([])
/**
 * 树形下拉搜索值
 */
const parentIdSearchValue = ref('')

/**
 * 显示弹窗
 */
const show = (params?: any) => {
    params = params || {}
    visible.value = true
    /**
     * 初始参数
     */
    formRef.value = Object.assign({}, { ...defaultForm })
    formRef.value.parentId = params.parentId
    if (params.type === '1') {
        formRef.value.type = ''
        disableType.value = false
    } else {
        formRef.value.type = params.type
        disableType.value = true
    }

    if (params.id) {
        modalTitle.value = '编辑机构'
        get({ id: params.id }).then((res: any) => {
            const data = res.data
            leftCover(formRef.value, data)
        })
    }

    /**查询上级ID数据*/
    getList(`${import.meta.env.VITE_API_URL_SYSTEM}/v1/sys/department/getTree?hasRoot=1`).then(
        (res) => {
            if (res.code === 1) {
                parentIdOptions.value = res.data
            }
        },
    )
}
defineExpose({ show })
const parentSelect = (value, node) => {
    if (node.data.type === '1') {
        formRef.value.type = ''
        disableType.value = false
    } else {
        formRef.value.type = node.data.type
        disableType.value = true
    }
}
/**
 * 接收方法
 */
const emits = defineEmits(['ok'])
/**
 * 提交方法
 */
const onSubmit = () => {
    myFormRef.value?.validate().then(() => {
        submitLoading.value = true
        const params = cloneDeep(formRef.value)
        params.serve = 'department'
        if (params.id) {
            edit(params).then((res: any) => {
                if (res.code === 1) {
                    emits('ok')
                    message.success('提交成功')
                    onCancel()
                }
                submitLoading.value = false
            })
        } else {
            save(params).then((res: any) => {
                if (res.code === 1) {
                    emits('ok')
                    message.success('提交成功')
                    onCancel()
                }
                submitLoading.value = false
            })
        }
    })
}
/**
 * 关闭弹窗
 */
const onCancel = () => {
    myFormRef.value?.resetFields()
    visible.value = false
}
</script>

<style scoped lang="less"></style>
