<!--分组管理-->
<template>
    <ACard
        size="small"
        title="字典分类"
        :bordered="false"
        style="width: 300px; margin-top: 8px"
        :body-style="{ padding: 0, height: 'calc(100vh - 350px)', overflow: 'auto' }"
    >
        <ATabs v-model:activeKey="selectedKeys" tab-position="left" animated class="yx-group-tabs">
            <ATabPane :key="item.code" v-for="item in classifyList">
                <template #tab>
                    <div class="yx-group-pane text-left">
                        <div class="left">
                            {{ item.name }}
                        </div>
                    </div>
                </template>
            </ATabPane>
        </ATabs>
    </ACard>
</template>
<script setup lang="ts" name="groupIndex">
import { onMounted, ref, watch } from 'vue'
import { getList } from '@/api/common'
const classifyList = ref<any>([])
const selectedKeys = ref('0')

watch(selectedKeys, () => {
    emits('click', selectedKeys.value)
})

const getKeyList = async () => {
    await getList(`${import.meta.env.VITE_API_URL_SYSTEM}/v1/sys/dict/list/key`).then((res) => {
        if (res.code === 1) {
            classifyList.value = res.data
        }
    })
}
const emits = defineEmits(['click'])

const init = async () => {
    await getKeyList()
    if (classifyList.value.length > 0) {
        const first = classifyList.value[0]
        selectedKeys.value = first?.code
        emits('click', selectedKeys.value)
    }
}
defineExpose({ init })

onMounted(() => {})
</script>
<style scoped lang="less"></style>
