<template>
    <PageWrapper title="数据字典" sub-title="">
        <div class="main">
            <div class="left">
                <GroupIndex ref="GroupIndexRef" @click="menuClick"></GroupIndex>
            </div>
            <div class="table-container">
                <MyTablePage
                    style="overflow: auto"
                    ref="MyTablePageRef"
                    :search-item="searchItem"
                    :url="dataUrl"
                    :columns="columns"
                    :action="action"
                    :ellipsis="1"
                    show-index
                    pagination
                    selection="checkbox"
                >
                    <template #tools>
                        <AButton v-permission="'sysDictAdd'" type="primary" @click="handelAdd">
                            <template #icon>
                                <PlusOutlined />
                            </template>
                            添加
                        </AButton>
                        <AButton v-permission="'sysDictDelete'" type="danger" @click="deletes()">
                            <template #icon>
                                <DeleteOutlined />
                            </template>
                            批量删除
                        </AButton>
                    </template>
                </MyTablePage>
            </div>
        </div>
        <Edit ref="EditRef" @ok="search"></Edit>
    </PageWrapper>
</template>
<!--路由地址：/system/sysDict/index ,组件名称：sysDictIndex	-->
<script setup lang="ts" name="sysDictIndex">
import { onMounted, ref } from 'vue'
import { DeleteOutlined, PlusOutlined } from '@ant-design/icons-vue'
import { message, Modal } from 'ant-design-vue'
import { cloneDeep } from 'lodash-es'
import { del } from '@/api/system/sysDict'
import Edit from './edit.vue'
import GroupIndex from './groupIndex.vue'
const EditRef = ref()
const dictKey = ref<any>('')
const MyTablePageRef = ref()
const dataUrl = `${import.meta.env.VITE_API_URL_SYSTEM}/v1/sys/dict/getList`
const GroupIndexRef = ref()
/*列配置 api https://itvita.gitee.io/liuyunxi-antd-extend/#/YxTable*/
const columns = ref<any[]>([
    {
        title: '字典值',
        dataIndex: 'name',
        hidden: false,
    },
    {
        title: '顺序号',
        dataIndex: 'seq',
        hidden: false,
    },
])
/*搜索条配置 api https://itvita.gitee.io/liuyunxi-antd-extend/#/YxSearch*/
const searchItem = ref<any[]>([
    {
        type: 'text',
        key: 'name',
        label: '字典值',
        value: '',
        placeholder: '',
    },
])
/**
 * 批量删除方法
 * @param ids id数组
 */
const deletes = (ids?: string[]) => {
    if (ids === undefined) {
        const { selectedRowKeys } = MyTablePageRef.value.getSelection()
        ids = cloneDeep(selectedRowKeys)
    }
    if (!ids || ids?.length < 1) {
        Modal.warning({
            title: '请先选择删除项',
        })
        return
    }
    Modal.confirm({
        title: '确定删除？',
        content: '删除后将无法恢复',
        okType: 'danger',
        onOk() {
            del(ids).then((res: any) => {
                if (res.code === 1) {
                    message.success('删除成功')
                    search()
                }
            })
        },
    })
}
/*table 操作列配置*/
const action = ref({
    width: 200,
    fixed: 'right',
    buttons: [
        {
            title: '编辑',
            icon: 'iconfont icon-bianji',
            permission: 'sysDictEdit',
            event: (row: any) => {
                EditRef.value.show({ id: row.id })
            },
        },
        {
            title: '删除',
            color: '#f12424', // primary,success,warn,danger,info
            icon: 'iconfont icon-shanchu',
            permission: 'sysDictDelete',
            event: (row: any) => {
                deletes([row.id])
            },
        },
    ],
})

/**
 * 添加
 */
const handelAdd = () => {
    EditRef.value.show({ dictKey: dictKey.value })
}

const menuClick = (key: any) => {
    dictKey.value = key
    MyTablePageRef.value.search({ dictKey: dictKey.value })
}

const search = () => {
    MyTablePageRef.value.search({ dictKey: dictKey.value })
}

/**
 * 挂载，页面初始化后执行
 */
onMounted(async () => {
    GroupIndexRef.value.init()
})
</script>

<style scoped lang="less">
@import '@/theme/theme.less';
.main {
    background: @component-background;
}
.left {
    float: left;
    //margin-right: 20px;
    min-height: 100%;
    max-height: calc(100vh - 250px);
    padding: 10px;
    &::-webkit-scrollbar {
        width: 8px;
        height: 10px;
        background-color: #f8f9fa;
    }

    &::-webkit-scrollbar-thumb {
        background: rgba(0, 0, 0, 0.2);
        border-radius: 0;
    }
}
</style>
