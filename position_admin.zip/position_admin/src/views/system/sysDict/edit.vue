<template>
    <YxModal
        ref="YxModalRef"
        :title="modalTitle"
        v-model:visible="visible"
        @ok="onSubmit"
        @cancel="onCancel"
        :submit-loading="submitLoading"
    >
        <AForm
            class="padding"
            ref="myFormRef"
            name="myFormRef"
            :model="formRef"
            :label-col="{ span: 4 }"
            :wrapper-col="{ span: 14 }"
        >
            <AFormItem label="字典值" name="name" :rules="[{ max: 50, required: true }]">
                <AInput v-model:value="formRef.name" placeholder=""></AInput>
            </AFormItem>
            <AFormItem label="顺序号" name="seq" :rules="[{ required: true }]">
                <AInputNumber v-model:value="formRef.seq" placeholder=""></AInputNumber>
            </AFormItem>
        </AForm>
    </YxModal>
</template>
<!--添加路由地址：/system/sysDict/add，修改路由地址：/system/sysDict/edit，组件地址：/system/sysDict/edit-->
<script setup lang="ts">
import { FormInstance, message } from 'ant-design-vue'
import { ref } from 'vue'
import { save, edit, get } from '@/api/system/sysDict'
import { leftCover } from '@/utils/ObjectUtils'

/**
 * 基础数据定义
 */
const visible = ref(false)
const submitLoading = ref(false)
const modalTitle = ref('添加数据字典')

const myFormRef = ref<FormInstance>()
const defaultForm = {
    id: null, //主键ID
    dictKey: '', //父级编码
    name: '', //字典名称
    seq: 30, //顺序号
}
const formRef = ref<any>({
    ...defaultForm,
})
/**
 * 显示弹窗
 */
const show = (params?: any) => {
    params = params || {}
    visible.value = true
    /**
     * 初始参数
     */
    formRef.value = Object.assign({}, { ...defaultForm })
    leftCover(formRef.value, params)

    if (params.id) {
        modalTitle.value = '编辑数据字典'
        get({ id: params.id }).then((res: any) => {
            const data = res.data
            leftCover(formRef.value, data)
        })
    }
}
defineExpose({ show })

/**
 * 接收方法
 */
const emits = defineEmits(['ok'])
/**
 * 提交方法
 */
const onSubmit = () => {
    myFormRef.value?.validate().then(() => {
        submitLoading.value = true
        if (formRef.value.id) {
            edit(formRef.value).then((res: any) => {
                if (res.code === 1) {
                    emits('ok')
                    message.success('提交成功')
                    onCancel()
                }
                submitLoading.value = false
            })
        } else {
            save(formRef.value).then((res: any) => {
                console.log('res', res)
                if (res.code === 1) {
                    emits('ok')
                    message.success('提交成功')
                    onCancel()
                }
                submitLoading.value = false
            })
        }
    })
}
/**
 * 关闭弹窗
 */
const onCancel = () => {
    myFormRef.value?.resetFields()
    visible.value = false
}
</script>

<style scoped lang="less"></style>
