<template>
    <YxModal
        ref="YxModalRef"
        :title="modalTitle"
        v-model:visible="visible"
        @ok="onSubmit"
        @cancel="onCancel"
        :submit-loading="submitLoading"
    >
        <AForm
            class="bg-white padding"
            ref="myFormRef"
            name="myFormRef"
            :model="formRef"
            :label-col="{ span: 4 }"
            :wrapper-col="{ span: 14 }"
        >
            <AFormItem
                label="巡检任务名称"
                name="name"
                extra=""
                :rules="[{ required: true, message: '请输入巡检任务名称', trigger: 'blur' }]"
            >
                <AInput
                    v-model:value="formRef.name"
                    placeholder=""
                    show-count
                    :maxlength="50"
                ></AInput>
            </AFormItem>
            <AFormItem
                label="巡检路线"
                name="inspectionRoute"
                extra=""
                :rules="[{ required: true, message: '请选择巡检路线', trigger: 'blur' }]"
            >
                <ARadioGroup
                    placeholder=""
                    v-model:value="formRef.inspectionRoute"
                    :options="inspectionRouteOptions"
                />
            </AFormItem>
            <AFormItem label="启用时间" name="startTime" extra="" :rules="[]">
                <YxDatePicker
                    v-model:value="formRef.startTime"
                    placeholder=""
                    show-time="yyyy-MM-dd HH:mm:ss"
                ></YxDatePicker>
            </AFormItem>
            <AFormItem label="停用时间" name="stopTime" extra="" :rules="[]">
                <YxDatePicker
                    v-model:value="formRef.stopTime"
                    placeholder=""
                    show-time="yyyy-MM-dd HH:mm:ss"
                ></YxDatePicker>
            </AFormItem>
            <AFormItem
                label="执行人"
                name="person"
                extra=""
                :rules="[{ required: true, message: '请选择执行人', trigger: 'blur' }]"
            >
                <!--tree-default-expand-all-->
                <ATreeSelect
                    v-model:value="formRef.person"
                    v-model:searchValue="personSearchValue"
                    show-search
                    style="width: 100%"
                    treeNodeFilterProp="title"
                    :dropdown-style="{ maxHeight: '400px', overflow: 'auto' }"
                    placeholder=""
                    allow-clear
                    :tree-data="personOptions"
                    :multiple="true"
                    :fieldNames="{
                        children: 'children',
                        label: 'title',
                        key: 'id',
                        value: 'id',
                    }"
                >
                    <template #title="{ title }">
                        <template
                            v-for="(fragment, i) in (title || '')
                                .toString()
                                .split(
                                    new RegExp(
                                        `(?<=${personSearchValue})|(?=${personSearchValue})`,
                                        'i',
                                    ),
                                )"
                        >
                            <span
                                v-if="fragment.toLowerCase() === personSearchValue.toLowerCase()"
                                :key="i"
                                style="color: #08c"
                            >
                                {{ fragment }}
                            </span>
                            <template v-else>{{ fragment }}</template>
                        </template>
                    </template>
                </ATreeSelect>
            </AFormItem>
            <AFormItem
                label="重复周期"
                name="repeatDay"
                extra=""
                :rules="[{ required: true, message: '请选择重复周期', trigger: 'blur' }]"
            >
                <ACheckboxGroup
                    placeholder=""
                    v-model:value="formRef.repeatDay"
                    :options="repeatDayOptions"
                />
            </AFormItem>
            <AFormItem
                label="是否启用"
                name="isUse"
                extra=""
                :rules="[{ required: true, message: '请选择是否启用', trigger: 'blur' }]"
            >
                <ARadioGroup placeholder="" v-model:value="formRef.isUse" :options="isUseOptions" />
            </AFormItem>
        </AForm>
    </YxModal>
</template>
<!--添加路由地址：/inspection/task/inspectionTask/add，修改路由地址：/inspection/task/inspectionTask/edit，组件地址：/inspection/task/inspectionTask/edit-->
<script setup lang="ts">
import { FormInstance, message } from 'ant-design-vue'
import { ref } from 'vue'
import { edit, get, save } from '@/api/inspection/task/inspectionTask'
import { cloneDeep } from 'lodash-es'
import { leftCover } from '@/utils/ObjectUtils'
import { getList } from '@/api/common'

/**
 * 基础数据定义
 */
const visible = ref(false)
const submitLoading = ref(false)
const modalTitle = ref('添加巡检任务')

const myFormRef = ref<FormInstance>()

const defaultForm = {
    id: null, //主键ID
    name: '', //巡检任务名称
    inspectionRoute: '', //巡检路线
    startTime: '', //启用时间
    stopTime: '', //停用时间
    person: '', //执行人
    repeatDay: [], //重复周期
    isUse: '', //是否启用
}
const formRef = ref<any>({ ...defaultForm })

/**
 * 巡检路线选项
 */
const inspectionRouteOptions = ref([])
/**
 * 执行人选项
 */
const personOptions = ref([])
/**
 * 树形下拉搜索值
 */
const personSearchValue = ref('')

/**
 * 重复周期选项
 */
const repeatDayOptions = [
    { label: '每天', value: '1' },
    { label: '每周一', value: '2' },
    { label: '每周二', value: '3' },
    { label: '每周三', value: '4' },
    { label: '每周四', value: '5' },
    { label: '每周五', value: '6' },
    { label: '每周六', value: '7' },
    { label: '每周日', value: '8' },
]
/**
 * 是否启用选项
 */
const isUseOptions = [
    { label: '启用', value: '1' },
    { label: '停用', value: '0' },
]
/**
 * 显示弹窗
 */
const show = (params?: any) => {
    params = params || {}
    visible.value = true
    /**
     * 初始参数
     */
    formRef.value = Object.assign({}, { ...defaultForm })
    formRef.value.parentId = params.parentId
    leftCover(formRef.value, params || {})

    if (params.id) {
        modalTitle.value = '编辑巡检任务'
        get({ id: params.id }).then((res: any) => {
            const data = res.data
            leftCover(formRef.value, data)
        })
    }
    /**查询上级ID数据*/
    getList(`${import.meta.env.VITE_API_URL_SYSTEM}/v1/inspection/task/getTree`).then((res) => {
        if (res.code === 1) {
            personOptions.value = res.data
            console.log(personOptions.value)
        }
    })
    getList(`${import.meta.env.VITE_API_URL_SYSTEM}/v1/inspection/route/getAllRoute`).then(
        (res) => {
            if (res.code === 1) {
                inspectionRouteOptions.value = res.data.map((item) => ({
                    label: item.routeName, // 使用 res.data 中的内容作为标签和值
                    value: item.routeName,
                }))
            }
        },
    )
}
defineExpose({ show })

/**
 * 接收方法
 */
const emits = defineEmits(['ok'])
/**
 * 提交方法
 */
const onSubmit = () => {
    myFormRef.value?.validate().then(() => {
        submitLoading.value = true
        const params = cloneDeep(formRef.value)
        for (let k in params) {
            if (typeof params[k] === 'object') {
                if (params[k]) {
                    params[k] = JSON.stringify(params[k])
                }
            }
        }
        if (params.id) {
            edit(params).then((res: any) => {
                if (res.code === 1) {
                    emits('ok')
                    message.success('提交成功')
                    onCancel()
                }
                submitLoading.value = false
            })
        } else {
            save(params).then((res: any) => {
                if (res.code === 1) {
                    emits('ok')
                    message.success('提交成功')
                    onCancel()
                }
                submitLoading.value = false
            })
        }
    })
}
/**
 * 关闭弹窗
 */
const onCancel = () => {
    myFormRef.value?.resetFields()
    visible.value = false
}
</script>

<style scoped lang="less"></style>
