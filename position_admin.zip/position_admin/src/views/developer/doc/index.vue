<template>
    <iframe class="doc" :src="docUrl"> </iframe>
</template>

<script setup lang="ts" name="swaggerIndex">
const docUrl = import.meta.env.VITE_API_URL_DOC
// This starter template is using Vue 3 <script setup> SFCs
// Check out https://vuejs.org/api/sfc-script-setup.html#script-setup
</script>

<style scoped lang="less">
.doc {
    width: 100%;
    height: 100%;
}
</style>
