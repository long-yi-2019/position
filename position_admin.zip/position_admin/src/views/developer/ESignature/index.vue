<!--电子签名-->
<template>
    <div>
        <MySign ref="MySignRef" @ok="handleOk">
            <AButton>{{ src ? '修改' : '签名' }}</AButton>
        </MySign>
        <AImage v-if="src" :width="100" :src="src" />
    </div>
</template>
<script setup lang="ts" name="ESignature">
import MySign from '@/components/MySign.vue'
import { ref } from 'vue'
const staticRoot = import.meta.env.VITE_API_URL_STATIC
const src = ref()
const handleOk = (data: any) => {
    src.value = staticRoot + data.path
}
</script>
<style scoped lang="less"></style>
