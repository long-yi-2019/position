<!--动态表单-->
<template>
    <div>动态表单</div>
</template>
<script setup lang="ts" name="dynamicForms">
import { onMounted } from 'vue'

onMounted(() => {})
</script>
<style scoped lang="less"></style>
