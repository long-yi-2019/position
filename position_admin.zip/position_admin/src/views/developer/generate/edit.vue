<template>
    <YxModal
        ref="YxModalRef"
        title="代码生成配置"
        v-model:visible="visible"
        @cancel="onCancel"
        @ok="onOk"
        okText="生成代码"
        cancelText="关闭"
        :submit-loading="submitLoading"
    >
        <div>
            <ATabs>
                <ATabPane key="1" tab="基本配置">
                    <BasicInfo :id="id"></BasicInfo>
                </ATabPane>
                <ATabPane key="2" tab="后端基础配置">
                    <JavaInfo :id="id"></JavaInfo>
                </ATabPane>
                <ATabPane key="3" tab="前端基础配置">
                    <VueInfo :id="id"></VueInfo>
                </ATabPane>
                <ATabPane key="4" tab="列表属性配置">
                    <TableInfo :id="id"></TableInfo>
                </ATabPane>
                <ATabPane key="5" tab="搜索条属性配置">
                    <SearchInfo :id="id"></SearchInfo>
                </ATabPane>
                <ATabPane key="6" tab="表单属性配置">
                    <FormInfo :id="id"></FormInfo>
                </ATabPane>
            </ATabs>
        </div>
    </YxModal>
</template>

<script setup lang="ts">
import { ref } from 'vue'
import BasicInfo from './component/BasicInfo.vue'
import JavaInfo from './component/JavaInfo.vue'
import VueInfo from './component/VueInfo.vue'
import TableInfo from './component/table/TableInfo.vue'
import FormInfo from '@/views/developer/generate/component/form/FormInfo.vue'
import SearchInfo from '@/views/developer/generate/component/search/SearchInfo.vue'
import { message } from 'ant-design-vue'
import { create } from '@/api/tools/StTableInfo'

const activeKey = ref('0')
const id = ref()
/**
 * 基础数据定义
 */
const visible = ref(false)
const submitLoading = ref(false)
const onCancel = () => {
    visible.value = false
}
const show = (params?: any) => {
    params = params || {}
    id.value = params.id
    activeKey.value = '1'
    visible.value = true
}
const onOk = () => {
    if (!import.meta.env.DEV) {
        message.error('此功能仅对开发环境开放')
        return
    }
    create({ id: id.value }).then((res) => {
        if (res.code === 1) {
            message.success('生成成功')
        }
    })
}
defineExpose({ show })
</script>

<style scoped lang="less"></style>
