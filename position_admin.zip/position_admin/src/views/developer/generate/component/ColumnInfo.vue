<template>
    <div style="margin-top: -10px">
        <MyTablePage
            ref="MyTablePageRef"
            :url="dataUrl"
            :columns="columns"
            :ellipsis="1"
            show-index
            :height="-30"
        >
            <template #tools>
                <AButton style="margin-left: 10px" @click="goBack">
                    <template #icon> <ArrowLeftOutlined /> </template>返回</AButton
                >
                <AButton style="margin-left: 10px" @click="handelSnyc" :loading="loading">
                    <template #icon> <SyncOutlined /> </template>同步表结构</AButton
                >
            </template>
        </MyTablePage>
    </div>
</template>

<script setup lang="ts">
import { onMounted, ref } from 'vue'
import PageConfig from './ColumnPageConfig'
import { SyncOutlined, ArrowLeftOutlined } from '@ant-design/icons-vue'

import { useRoute, useRouter } from 'vue-router'
const MyTablePageRef = ref()
//MyTablePageRef
const { columns, dataUrl } = PageConfig()
import { columnSync } from '@/api/tools/StTableColumnInfo'
const router = useRouter()
const route = useRoute()
const loading = ref(false)
/**
 * 返回
 */
const goBack = () => {
    router.back()
}
/**
 * 同步表结构
 */
const handelSnyc = async () => {
    loading.value = true
    await columnSync({ tableInfoId: route.query.id }).then((res) => {
        if (res.code === 1) {
            MyTablePageRef.value.search({ tableInfoId: route.query.id })
        }
    })
    loading.value = false
}
onMounted(() => {
    MyTablePageRef.value.search({ tableInfoId: route.query.id })
})
</script>

<style scoped lang="less"></style>
