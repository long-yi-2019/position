<template>
    <AForm
        class="bg-white padding"
        ref="myFormRef"
        name="myFormRef"
        :model="formRef"
        :label-col="{ span: 4 }"
        :wrapper-col="{ span: 14 }"
    >
        <AFormItem
            label="后端模板"
            name="javaTemplate"
            :rules="[{ required: true, message: '请选择后端模板' }]"
        >
            <ASelect v-model:value="formRef.javaTemplate" :options="javaTemplateOptions"></ASelect>
        </AFormItem>

        <AFormItem
            label="api包名"
            name="apiPackageName"
            :rules="[{ required: true, message: '请输入api包名', max: 200 }]"
        >
            <AInput v-model:value="formRef.apiPackageName"></AInput>
        </AFormItem>

        <AFormItem
            label="api模块路径"
            name="apiPath"
            :rules="[{ required: true, message: '请输入api模块路径', max: 200 }]"
        >
            <AInput v-model:value="formRef.apiPath"></AInput>
        </AFormItem>

        <AFormItem
            label="module包名"
            name="modulePackageName"
            :rules="[{ required: true, message: '请输入module包名', max: 200 }]"
        >
            <AInput v-model:value="formRef.modulePackageName"></AInput>
        </AFormItem>

        <AFormItem
            label="module模块路径"
            name="modulePath"
            :rules="[{ required: true, message: '请输入module模块路径', max: 200 }]"
        >
            <AInput v-model:value="formRef.modulePath"></AInput>
        </AFormItem>

        <AFormItem
            label="service包名"
            name="servicePackageName"
            :rules="[{ required: true, message: '请输入service包名', max: 200 }]"
        >
            <AInput v-model:value="formRef.servicePackageName"></AInput>
        </AFormItem>

        <AFormItem
            label="service模块路径"
            name="servicePath"
            :rules="[{ required: true, message: '请输入service模块路径', max: 200 }]"
        >
            <AInput v-model:value="formRef.servicePath"></AInput>
        </AFormItem>

        <AFormItem
            label="controller跟映射地址"
            name="rootMapping"
            :rules="[{ required: true, message: '请输入controller跟映射地址', max: 20 }]"
        >
            <AInput v-model:value="formRef.rootMapping"></AInput>
        </AFormItem>

        <AFormItem :wrapper-col="{ span: 14, offset: 4 }">
            <AButton type="primary" @click.prevent="onSubmit" :loading="submitLoading"
                >保存
            </AButton>
        </AFormItem>
    </AForm>
</template>

<script setup lang="ts">
import type { SelectProps } from 'ant-design-vue'
import { message } from 'ant-design-vue'
import { ref } from 'vue'
import { get, save, update } from '@/api/tools/StTableInfo'
import { leftCover } from '@/utils/ObjectUtils'
const myFormRef = ref<any>()
const submitLoading = ref(false)
const formRef = ref<any>({
    id: null, //主键ID
    javaTemplate: '1', //后端模板;1单表基础，2单表树形
    apiPackageName: '', //api包名
    apiPath: '', //api模块路径
    modulePackageName: '', //module包名
    modulePath: '', //module模块路径
    servicePackageName: '', //service包名
    servicePath: '', //service模块路径
    rootMapping: '', //controller跟映射地址
})
const javaTemplateOptions = ref<SelectProps['options']>([
    {
        value: '1',
        label: '单表基础',
    },
    {
        value: '2',
        label: '单表树形',
    },
])
const props = defineProps<{
    id: string
}>()

Object.assign(formRef.value, props)
if (props.id) {
    get({ id: props.id }).then((res) => {
        leftCover(formRef.value, res.data)
    })
}
const onSubmit = () => {
    myFormRef.value.validate().then(() => {
        submitLoading.value = true
        if (formRef.value.id) {
            update(formRef.value).then((res) => {
                if (res.code === 1) {
                    message.success('保存成功')
                }
                submitLoading.value = false
            })
        } else {
            save(formRef.value).then((res) => {
                if (res.code === 1) {
                    message.success('保存成功')
                }
                submitLoading.value = false
            })
        }
    })
}
</script>

<style scoped lang="less"></style>
