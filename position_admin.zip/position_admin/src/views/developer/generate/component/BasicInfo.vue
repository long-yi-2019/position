<template>
    <AForm
        class="bg-white padding"
        ref="myFormRef"
        name="myFormRef"
        :model="formRef"
        :label-col="{ span: 4 }"
        :wrapper-col="{ span: 14 }"
    >
        <AFormItem
            label="表名称"
            name="tableName"
            :rules="[{ required: true, message: '请输入表名称,最大长度50', max: 50 }]"
        >
            <AInput v-model:value="formRef.tableName"></AInput>
        </AFormItem>

        <AFormItem
            label="表描述"
            name="tableComment"
            :rules="[{ required: true, message: '请输入表描述,最大长度500', max: 500 }]"
        >
            <AInput v-model:value="formRef.tableComment"></AInput>
        </AFormItem>

        <AFormItem
            label="实体类名称"
            name="className"
            :rules="[{ required: true, message: '请输入实体类名称,最大长度50', max: 50 }]"
        >
            <AInput v-model:value="formRef.className"></AInput>
        </AFormItem>

        <AFormItem
            label="作者"
            name="author"
            :rules="[{ required: true, message: '请输入作者,最大长度90', max: 90 }]"
        >
            <AInput v-model:value="formRef.author"></AInput>
        </AFormItem>

        <AFormItem :wrapper-col="{ span: 14, offset: 4 }">
            <AButton type="primary" @click.prevent="onSubmit" :loading="submitLoading"
                >保存
            </AButton>
        </AFormItem>
    </AForm>
</template>

<script setup lang="ts">
import { getCurrentInstance, ref } from 'vue'
import { get, save, update } from '@/api/tools/StTableInfo'
import { leftCover } from '@/utils/ObjectUtils'
const { proxy } = getCurrentInstance() as any
const myFormRef = ref<any>()
const submitLoading = ref(false)
const formRef = ref<any>({
    id: null, //主键ID
    tableName: '', //表名称
    tableComment: '', //表描述
    className: '', //实体名称
    author: '', //作者
})
const props = defineProps<{
    id: string
}>()

Object.assign(formRef.value, { props })
if (props.id) {
    get({ id: props.id }).then((res) => {
        leftCover(formRef.value, res.data)
    })
}
const onSubmit = () => {
    myFormRef.value.validate().then(() => {
        submitLoading.value = true
        if (formRef.value.id) {
            update(formRef.value).then((res) => {
                if (res.code === 1) {
                    proxy.$message.success('保存成功')
                }
                submitLoading.value = false
            })
        } else {
            save(formRef.value).then((res) => {
                if (res.code === 1) {
                    proxy.$message.success('保存成功')
                }
                submitLoading.value = false
            })
        }
    })
}
</script>

<style scoped lang="less"></style>
