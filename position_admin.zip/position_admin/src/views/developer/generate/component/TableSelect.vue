<template>
    <AModal v-model:visible="visible" title="表选择" @ok="handleOk" :confirm-loading="loading">
        <ASelect
            v-model:value="value"
            show-search
            placeholder="请选择"
            style="width: 100%"
            :options="options"
            :filter-option="filterOption"
        ></ASelect>
    </AModal>
</template>

<script setup lang="ts">
import { ref } from 'vue'
import type { SelectProps } from 'ant-design-vue'
import { getAllTable, save } from '@/api/tools/StTableInfo'

const value = ref('')
const loading = ref(false)
const options = ref<SelectProps['options']>([])
const visible = ref(false)
const emits = defineEmits(['ok'])
const handleOk = async () => {
    loading.value = true
    if (value.value) {
        const item = options.value?.filter((v) => v.value === value.value)
        if (item && item.length > 0) {
            await save({
                tableName: item[0]?.value,
                tableComment: item[0]?.label,
            }).then((res) => {
                if (res.code === 1) {
                    emits('ok', item && item[0])
                }
            })
        }
    }
    loading.value = false
    visible.value = false
}
const show = () => {
    options.value = []
    visible.value = true
    getAllTable().then((res) => {
        if (res.code === 1) {
            res.data.forEach((v: any) => {
                options.value?.push({
                    value: v.tableName,
                    label: v.tableComment,
                })
            })
        }
    })
}
const filterOption = (input: string, option: any) => {
    return (
        option.value.toLowerCase().indexOf(input.toLowerCase()) >= 0 ||
        option.label.toLowerCase().indexOf(input.toLowerCase()) >= 0
    )
}
defineExpose({ show })
</script>

<style scoped lang="less"></style>
