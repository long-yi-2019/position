<template>
    <AForm
        class="bg-white padding"
        ref="myFormRef"
        name="myFormRef"
        :model="formRef"
        :label-col="{ span: 4 }"
        :wrapper-col="{ span: 14 }"
    >
        <AFormItem
            label="前端模板"
            name="vueTemplate"
            :rules="[{ required: true, message: '请选择前端模板' }]"
        >
            <ASelect v-model:value="formRef.vueTemplate" :options="vueTemplateOptions"></ASelect>
        </AFormItem>

        <AFormItem
            v-if="formRef.vueTemplate === '2'"
            label="树形数据地址"
            name="treeUrl"
            :rules="[{ required: true, message: '请输入树形数据地址' }]"
        >
            <AInput v-model:value="formRef.treeUrl" placeholder="/业务名称/getZtree"></AInput>
        </AFormItem>

        <AFormItem
            v-if="formRef.vueTemplate === '2'"
            label="树形关系"
            name="treeRel"
            :rules="[{ required: true, message: '请选择树形关系' }]"
        >
            <ARadioGroup placeholder="" v-model:value="formRef.treeRel" :options="treeRelOptions" />
        </AFormItem>

        <AFormItem
            v-if="formRef.treeRel === '2'"
            label="引用键名"
            name="relKey"
            :rules="[{ required: true, message: '请输入引用键名' }]"
        >
            <AInput v-model:value="formRef.relKey" placeholder=""></AInput>
        </AFormItem>

        <AFormItem
            label="项目路径"
            name="vueProjectPath"
            :rules="[{ required: true, message: '请输入项目路径', max: 200 }]"
        >
            <AInput v-model:value="formRef.vueProjectPath"></AInput>
        </AFormItem>

        <AFormItem
            label="环境变量"
            name="vueApiBase"
            :rules="[{ required: true, message: '请输入环境变量', max: 90 }]"
        >
            <AInput v-model:value="formRef.vueApiBase"></AInput>
        </AFormItem>

        <AFormItem
            label="api模块路径"
            name="vueApiPath"
            :rules="[{ required: true, message: '请输入api模块路径', max: 200 }]"
        >
            <AInput v-model:value="formRef.vueApiPath"></AInput>
        </AFormItem>

        <AFormItem
            label="vue模块路径"
            name="vueViewPath"
            :rules="[{ required: true, message: '请输入vue模块路径', max: 200 }]"
        >
            <AInput v-model:value="formRef.vueViewPath"></AInput>
        </AFormItem>

        <AFormItem :wrapper-col="{ span: 14, offset: 4 }">
            <AButton type="primary" @click.prevent="onSubmit" :loading="submitLoading"
                >保存
            </AButton>
        </AFormItem>
    </AForm>
</template>

<script setup lang="ts">
import type { SelectProps } from 'ant-design-vue'
import { message } from 'ant-design-vue'
import { ref } from 'vue'
import { get, save, update } from '@/api/tools/StTableInfo'
import { leftCover } from '@/utils/ObjectUtils'
const myFormRef = ref<any>()
const submitLoading = ref(false)
const formRef = ref<any>({
    id: null, //主键ID
    vueTemplate: '1', //1搜索列表，2树形+列表
    treeUrl: '', //树形数据地址
    treeRel: '1', //树形关系
    relKey: '', //引用键名
    vueProjectPath: '', //项目路径
    vueApiBase: '', //环境变量;baseUrl
    vueApiPath: '', //api模块路径
    vueViewPath: '', //vue模块路径
})
const vueTemplateOptions = ref<SelectProps['options']>([
    {
        value: '1',
        label: '搜索列表',
    },
    {
        value: '2',
        label: '树形+列表',
    },
])
const treeRelOptions = ref([
    {
        value: '1',
        label: '父子',
    },
    {
        value: '2',
        label: '引用',
    },
])

const props = defineProps<{
    id: string
}>()

Object.assign(formRef.value, props)
if (props.id) {
    get({ id: props.id }).then((res) => {
        leftCover(formRef.value, res.data)
    })
}
const onSubmit = () => {
    myFormRef.value.validate().then(() => {
        submitLoading.value = true
        if (formRef.value.id) {
            update(formRef.value).then((res) => {
                if (res.code === 1) {
                    message.success('保存成功')
                }
                submitLoading.value = false
            })
        } else {
            save(formRef.value).then((res) => {
                if (res.code === 1) {
                    message.success('保存成功')
                }
                submitLoading.value = false
            })
        }
    })
}
</script>

<style scoped lang="less"></style>
