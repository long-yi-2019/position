<template>
    <div style="margin-top: -10px">
        <MyTablePage
            ref="MyTablePageRef"
            :url="dataUrl"
            :columns="columns"
            :ellipsis="1"
            show-index
            :height="-20"
            :drag="true"
            @dragend="handelDragend"
        >
            <template #tools>
                <AButton style="margin-left: 10px" @click="handelSnyc" :loading="loading">
                    <template #icon> <SyncOutlined /> </template>同步表结构</AButton
                >
            </template>
        </MyTablePage>
    </div>
</template>

<script setup lang="ts" name="VueColumnInfo">
import { onMounted, ref } from 'vue'
import PageConfig from './TablePageConfig'
import { SyncOutlined } from '@ant-design/icons-vue'

const MyTablePageRef = ref()
//MyTablePageRef
const { columns, dataUrl } = PageConfig()
import { columnSync, sort } from '@/api/tools/StTableColumnInfo'
const loading = ref(false)

const props = defineProps<{
    id: string
}>()

/**
 * 拖动排序结束
 */
const handelDragend = ({ item, newIndex, oldIndex, rows }: any) => {
    let moveType = 'prev'
    let target: { id: string }
    if (newIndex > oldIndex) {
        moveType = 'next'
        target = rows[newIndex - 1]
    } else {
        target = rows[newIndex + 1]
    }
    sort({ moveType: moveType, dragId: item.id, targetId: target.id }).then(() => {})
}
/**
 * 同步表结构
 */
const handelSnyc = async () => {
    loading.value = true
    await columnSync({ tableInfoId: props.id }).then((res) => {
        if (res.code === 1) {
            MyTablePageRef.value.search({ tableInfoId: props.id })
        }
    })
    loading.value = false
}
onMounted(() => {
    MyTablePageRef.value.search({ tableInfoId: props.id })
})
</script>

<style scoped lang="less"></style>
