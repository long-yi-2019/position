import { getCurrentInstance, ref } from 'vue'
// import { useRouter } from 'vue-router'
import { update } from '@/api/tools/StTableColumnInfo'
//tableRef: any
export default function PageConfig() {
    // const router = useRouter()
    const { proxy } = getCurrentInstance() as any

    const dataUrl = `${import.meta.env.VITE_API_URL_GEN}/v1/st/table/column/info/getList`

    const columns = ref([
        {
            title: '字段列名',
            dataIndex: 'columnName',
            fixed: 'left',
            hidden: true,
        },
        {
            title: '字段描述',
            dataIndex: 'columnComment',
            fixed: 'left',
            formatter: {
                type: 'input',
                format: (row: any): any => {
                    return {
                        pressEnter: (e: any) => {
                            const value = e.target.value
                            update({ id: row.id, columnComment: value }).then((res) => {
                                if (res.code === 1) {
                                    proxy.$message.success('保存成功')
                                }
                            })
                        },
                        value: row.columnComment,
                    }
                },
            },
        },
        {
            title: '列类型',
            dataIndex: 'columnType',
            hidden: true,
        },
        {
            title: 'java属性名称',
            dataIndex: 'propertyName',
            formatter: {
                type: 'text',
                format: (row: any): any => {
                    return {
                        value: row.propertyName,
                        color: row.inList === '1' ? 'success' : '',
                    }
                },
            },
        },
        {
            title: 'java类型',
            dataIndex: 'javaType',
        },
        {
            title: '列表',
            dataIndex: 'inList',
            formatter: {
                type: 'select',
                format: (row: any): any => {
                    return {
                        /*同a-select*/
                        change: (value: any) => {
                            update({ id: row.id, inList: value }).then((res) => {
                                if (res.code === 1) {
                                    proxy.$message.success('保存成功')
                                }
                            })
                        },
                        value: [
                            {
                                label: `是`,
                                value: '1',
                            },
                            {
                                label: `否`,
                                value: '0',
                            },
                        ],
                    }
                },
            },
        },
        {
            title: '默认隐藏',
            dataIndex: 'listHidden',
            formatter: {
                type: 'select',
                format: (row: any): any => {
                    return {
                        /*同a-select*/
                        change: (value: any) => {
                            update({ id: row.id, listHidden: value }).then((res) => {
                                if (res.code === 1) {
                                    proxy.$message.success('保存成功')
                                }
                            })
                        },
                        value: [
                            {
                                label: `是`,
                                value: '1',
                            },
                            {
                                label: `否`,
                                value: '0',
                            },
                        ],
                    }
                },
            },
        },
        {
            title: '对齐方式',
            dataIndex: 'listAlign',
            formatter: {
                type: 'select',
                format: (row: any): any => {
                    return {
                        /*同a-select*/
                        change: (value: any) => {
                            update({ id: row.id, listAlign: value }).then((res) => {
                                if (res.code === 1) {
                                    proxy.$message.success('保存成功')
                                }
                            })
                        },
                        value: [
                            {
                                label: `左对齐`,
                                value: '1',
                            },
                            {
                                label: `居中`,
                                value: '2',
                            },
                            {
                                label: `右对齐`,
                                value: '3',
                            },
                        ],
                    }
                },
            },
        },
        {
            title: '列固定',
            dataIndex: 'listFixed',
            formatter: {
                type: 'select',
                format: (row: any): any => {
                    return {
                        /*同a-select*/
                        change: (value: any) => {
                            update({ id: row.id, listFixed: value }).then((res) => {
                                if (res.code === 1) {
                                    proxy.$message.success('保存成功')
                                }
                            })
                        },
                        value: [
                            {
                                label: `不固定`,
                                value: '0',
                            },
                            {
                                label: `固定左侧`,
                                value: '1',
                            },
                            {
                                label: `固定右侧`,
                                value: '2',
                            },
                        ],
                    }
                },
            },
        },
        {
            title: '格式化配置',
            dataIndex: 'listFormat',
        },
    ])

    return { dataUrl, columns }
}
