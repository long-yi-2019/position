import { getCurrentInstance, ref } from 'vue'
// import { useRouter } from 'vue-router'
import { update } from '@/api/tools/StTableColumnInfo'
//tableRef: any
export default function PageConfig() {
    // const router = useRouter()
    const { proxy } = getCurrentInstance() as any

    const dataUrl = `${import.meta.env.VITE_API_URL_GEN}/v1/st/table/column/info/getList`

    const columns = ref<any[]>([
        {
            title: '字段列名',
            dataIndex: 'columnName',
            fixed: 'left',
            hidden: true,
        },
        {
            title: '字段描述',
            dataIndex: 'columnComment',
            fixed: 'left',
            formatter: {
                type: 'input',
                format: (row: any): any => {
                    return {
                        pressEnter: (e: any) => {
                            const value = e.target.value
                            update({ id: row.id, columnComment: value }).then((res) => {
                                if (res.code === 1) {
                                    proxy.$message.success('保存成功')
                                }
                            })
                        },
                        value: row.columnComment,
                    }
                },
            },
        },
        {
            title: '列类型',
            dataIndex: 'columnType',
            hidden: true,
        },
        {
            title: 'java属性名称',
            dataIndex: 'propertyName',
            formatter: {
                type: 'text',
                format: (row: any): any => {
                    return {
                        value: row.propertyName,
                        color: row.inQuery === '1' ? 'success' : '',
                    }
                },
            },
        },
        {
            title: 'java类型',
            dataIndex: 'javaType',
        },
        {
            title: '查询',
            dataIndex: 'inQuery',
            formatter: {
                type: 'select',
                format: (row: any): any => {
                    return {
                        /*同a-select*/
                        change: (value: any) => {
                            const param: any = { id: row.id, inQuery: value }
                            if (row.inQuery === '0') {
                                param.queryType = ''
                            }
                            update(param).then((res) => {
                                if (res.code === 1) {
                                    proxy.$message.success('保存成功')
                                    row.queryType = ''
                                }
                            })
                        },
                        value: [
                            {
                                label: `是`,
                                value: '1',
                            },
                            {
                                label: `否`,
                                value: '0',
                            },
                        ],
                    }
                },
            },
        },
        {
            title: '查询方式',
            dataIndex: 'queryType',
            formatter: {
                type: 'select',
                format: (row: any): any => {
                    return {
                        /*同a-select*/
                        change: (value: any) => {
                            if (row.inQuery === '0') {
                                proxy.$message.error('未加入查询，该设置无效')
                                row.queryType = ''
                                return
                            }
                            update({ id: row.id, queryType: value }).then((res) => {
                                if (res.code === 1) {
                                    proxy.$message.success('保存成功')
                                }
                            })
                        },
                        value: [
                            {
                                label: `等于`,
                                value: '=',
                            },
                            {
                                label: `大于`,
                                value: '>',
                            },
                            {
                                label: `大于等于`,
                                value: '>=',
                            },
                            {
                                label: `小于`,
                                value: '<',
                            },
                            {
                                label: `小于等于`,
                                value: '<',
                            },
                            {
                                label: `包含`,
                                value: 'like',
                            },
                            {
                                label: `左包含`,
                                value: 'likeRight',
                            },
                            {
                                label: `右包含`,
                                value: 'likeLeft',
                            },
                        ],
                    }
                },
            },
        },
    ])

    return { dataUrl, columns }
}
