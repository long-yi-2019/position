<template>
    <AModal
        v-model:visible="visible"
        title="基础配置复制"
        @ok="handleOk"
        :confirm-loading="loading"
    >
        <ASelect
            v-model:value="value"
            show-search
            placeholder="请选择"
            style="width: 100%"
            :options="options"
            :filter-option="filterOption"
        ></ASelect>
    </AModal>
</template>

<script setup lang="ts">
import { ref } from 'vue'
import type { SelectProps } from 'ant-design-vue'
import { getGenTable, update } from '@/api/tools/StTableInfo'

const value = ref('')
const id = ref('')
const loading = ref(false)
const options = ref<SelectProps['options']>([])
const data = ref()
const visible = ref(false)
const emits = defineEmits(['ok'])
const handleOk = async () => {
    loading.value = true
    if (value.value && id.value) {
        const item = data.value?.filter((v: any) => v.tableName === value.value)
        if (item && item.length > 0) {
            await update({
                author: item[0]?.author,
                javaTemplate: item[0]?.javaTemplate,
                apiPackageName: item[0]?.apiPackageName,
                apiPath: item[0]?.apiPath,
                modulePackageName: item[0]?.modulePackageName,
                modulePath: item[0]?.modulePath,
                servicePackageName: item[0]?.servicePackageName,
                servicePath: item[0]?.servicePath,
                rootMapping: item[0]?.rootMapping,
                vueTemplate: item[0]?.vueTemplate,
                vueProjectPath: item[0]?.vueProjectPath,
                vueApiBase: item[0]?.vueApiBase,
                vueApiPath: item[0]?.vueApiPath,
                vueViewPath: item[0]?.vueViewPath,
                id: id.value,
            }).then((res) => {
                if (res.code === 1) {
                    emits('ok', item && item[0])
                }
            })
        }
    }
    loading.value = false
    visible.value = false
}
const show = (tid: string) => {
    id.value = tid
    options.value = []
    visible.value = true
    getGenTable().then((res) => {
        if (res.code === 1) {
            data.value = res.data
            res.data.forEach((v: any) => {
                options.value?.push({
                    value: v.tableName,
                    label: v.tableComment,
                })
            })
        }
    })
}
const filterOption = (input: string, option: any) => {
    return (
        option.value.toLowerCase().indexOf(input.toLowerCase()) >= 0 ||
        option.label.toLowerCase().indexOf(input.toLowerCase()) >= 0
    )
}
defineExpose({ show })
</script>

<style scoped lang="less"></style>
