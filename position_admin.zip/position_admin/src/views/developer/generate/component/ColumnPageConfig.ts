import { getCurrentInstance, ref } from 'vue'
// import { useRouter } from 'vue-router'
import { update } from '@/api/tools/StTableColumnInfo'
//tableRef: any
export default function PageConfig() {
    // const router = useRouter()
    const { proxy } = getCurrentInstance() as any

    const dataUrl = `${import.meta.env.VITE_API_URL_GEN}/v1/st/table/column/info/getList`

    const columns = ref([
        {
            title: '字段列名',
            dataIndex: 'columnName',
            fixed: 'left',
        },
        {
            title: '字段描述',
            dataIndex: 'columnComment',
            fixed: 'left',
            formatter: {
                type: 'input',
                format: (row: any): any => {
                    return {
                        pressEnter: (e: any) => {
                            update({ id: row.id, columnComment: e.target.value }).then((res) => {
                                if (res.code === 1) {
                                    proxy.$message.success('保存成功')
                                }
                            })
                        },
                        value: row.columnComment,
                    }
                },
            },
        },
        {
            title: '列类型',
            dataIndex: 'columnType',
        },
        {
            title: 'java类型',
            dataIndex: 'javaType',
        },
        {
            title: 'java属性名称',
            dataIndex: 'propertyName',
        },
        {
            title: '列表',
            dataIndex: 'inList',
            formatter: {
                type: 'select',
                format: (row: any): any => {
                    return {
                        /*同a-select*/
                        change: (value: any) => {
                            update({ id: row.id, inList: value }).then((res) => {
                                if (res.code === 1) {
                                    proxy.$message.success('保存成功')
                                }
                            })
                        },
                        value: [
                            {
                                label: `是`,
                                value: '1',
                            },
                            {
                                label: `否`,
                                value: '0',
                            },
                        ],
                    }
                },
            },
        },
        {
            title: '查询',
            dataIndex: 'inQuery',
            formatter: {
                type: 'select',
                format: (row: any): any => {
                    return {
                        /*同a-select*/
                        change: (value: any) => {
                            const param: any = { id: row.id, inQuery: value }
                            if (row.inQuery === '0') {
                                param.queryType = ''
                            }
                            update(param).then((res) => {
                                if (res.code === 1) {
                                    proxy.$message.success('保存成功')
                                    row.queryType = ''
                                }
                            })
                        },
                        value: [
                            {
                                label: `是`,
                                value: '1',
                            },
                            {
                                label: `否`,
                                value: '0',
                            },
                        ],
                    }
                },
            },
        },
        {
            title: '查询方式',
            dataIndex: 'queryType',
            formatter: {
                type: 'select',
                format: (row: any): any => {
                    return {
                        /*同a-select*/
                        change: (value: any) => {
                            if (row.inQuery === '0') {
                                proxy.$message.error('未加入查询，该设置无效')
                                row.queryType = ''
                                return
                            }
                            update({ id: row.id, queryType: value }).then((res) => {
                                if (res.code === 1) {
                                    proxy.$message.success('保存成功')
                                }
                            })
                        },
                        value: [
                            {
                                label: `等于`,
                                value: '=',
                            },
                            {
                                label: `大于`,
                                value: '>',
                            },
                            {
                                label: `大于等于`,
                                value: '>=',
                            },
                            {
                                label: `小于`,
                                value: '<',
                            },
                            {
                                label: `小于等于`,
                                value: '<',
                            },
                            {
                                label: `包含`,
                                value: 'like',
                            },
                            {
                                label: `左包含`,
                                value: 'likeRight',
                            },
                            {
                                label: `右包含`,
                                value: 'likeLeft',
                            },
                        ],
                    }
                },
            },
        },
        {
            title: '表单',
            dataIndex: 'inForm',
            formatter: {
                type: 'select',
                format: (row: any): any => {
                    return {
                        /*同a-select*/
                        change: (value: any) => {
                            update({ id: row.id, inForm: value }).then((res) => {
                                if (res.code === 1) {
                                    proxy.$message.success('保存成功')
                                }
                            })
                        },
                        value: [
                            {
                                label: `是`,
                                value: '1',
                            },
                            {
                                label: `否`,
                                value: '0',
                            },
                        ],
                    }
                },
            },
        },
        {
            title: '校验方式',
            dataIndex: 'formValid',
            click: (row: any) => {
                console.log(row)
            },
        },
        {
            title: 'UI建议',
            dataIndex: 'uiAdvise',
            formatter: {
                type: 'select',
                format: (row: any): any => {
                    return {
                        /*同a-select*/
                        change: (value: any) => {
                            update({ id: row.id, uiAdvise: value }).then((res) => {
                                if (res.code === 1) {
                                    proxy.$message.success('保存成功')
                                }
                            })
                        },
                        value: [
                            {
                                label: `文本输入框`,
                                value: 'text',
                            },
                            {
                                label: `大文本输入框`,
                                value: 'textarea',
                            },
                            {
                                label: `数字输入框`,
                                value: 'number',
                            },
                            {
                                label: `下拉选择`,
                                value: 'select',
                            },
                            {
                                label: `级联选择`,
                                value: 'cascade',
                            },
                            {
                                label: `单选框`,
                                value: 'radio',
                            },
                            {
                                label: `复选框`,
                                value: 'checkbox',
                            },
                            {
                                label: `日期选择框`,
                                value: 'date-picker',
                            },
                            {
                                label: `日期选择框`,
                                value: 'date-picker',
                            },
                            {
                                label: `日期范围选择框`,
                                value: 'date-range-picker',
                            },
                            {
                                label: `月选择框`,
                                value: 'month-picker',
                            },
                            {
                                label: `月范围选择框`,
                                value: 'month-range-picker',
                            },
                            {
                                label: `文件上传`,
                                value: 'upload',
                            },
                        ],
                    }
                },
            },
        },
        {
            title: '字典类型',
            dataIndex: 'distType',
            click: (row: any) => {
                console.log(row)
            },
        },
    ])

    return { dataUrl, columns }
}
