<template>
    <AModal
        v-model:visible="visible"
        title="校验方式配置"
        @ok="handleOk"
        @cancel="handelCancel"
        :confirm-loading="loading"
        :destroyOnClose="true"
        :maskClosable="false"
        :closable="false"
    >
        <AForm
            class="bg-white padding"
            ref="myFormRef"
            name="myFormRef"
            :label-col="{ span: 5 }"
            :wrapper-col="{ span: 17 }"
            :model="formRef"
        >
            <AFormItem
                label="类别"
                name="type"
                :rules="[{ required: true, message: '请选择类别' }]"
            >
                <ARadioGroup
                    v-model:value="formRef.type"
                    :options="[
                        { label: '自定义', value: '1' },
                        { label: '数据字典', value: '2' },
                        { label: '接口数据', value: '3' },
                    ]"
                />
            </AFormItem>
            <AFormItem
                v-if="formRef.type === '1'"
                label="自定义"
                name="custom"
                :rules="[{ required: true, message: '必填' }]"
            >
                <ASpace
                    v-for="(cus, index) in formRef.custom"
                    :key="index"
                    style="display: flex; margin-bottom: 8px"
                    align="baseline"
                >
                    <AFormItem
                        :name="['custom', index, 'label']"
                        :rules="{
                            required: true,
                            message: 'label必填',
                        }"
                    >
                        <AInput v-model:value="cus.label" placeholder="Label" />
                    </AFormItem>
                    <AFormItem
                        :name="['custom', index, 'value']"
                        :rules="{
                            required: true,
                            message: 'value必填',
                        }"
                    >
                        <AInput v-model:value="cus.value" placeholder="Value" />
                    </AFormItem>
                    <MinusCircleOutlined @click="removeCustom(cus)" />
                </ASpace>
                <AFormItem>
                    <AButton type="dashed" block @click="addCustom">
                        <PlusOutlined />
                        添加选项
                    </AButton>
                </AFormItem>
            </AFormItem>

            <AFormItem
                v-if="formRef.type === '3'"
                label="环境变量"
                name="envName"
                :rules="[{ required: true }]"
            >
                <AInput v-model:value="formRef.envName"></AInput>
            </AFormItem>
            <AFormItem
                v-if="formRef.type === '3'"
                label="接口地址"
                name="apiUrl"
                :rules="[{ required: true }]"
            >
                <AInput v-model:value="formRef.apiUrl"></AInput>
            </AFormItem>
        </AForm>
    </AModal>
</template>

<script setup lang="ts">
import { ref } from 'vue'
import { PlusOutlined, MinusCircleOutlined } from '@ant-design/icons-vue'
import { assignIn, cloneDeep } from 'lodash-es'
import { update } from '@/api/tools/StTableColumnInfo'
const loading = ref(false)
const visible = ref(false)
const defaultFormRef = {
    type: '1', //1 自定义，2 数据字典，3 接口
    custom: [], //自定义数据
    envName: 'VITE_API_URL', //环境变量名称
    apiUrl: '', //接口地址
    valueName: 'id',
}
const rows = ref()
const formRef = ref<any>(cloneDeep(defaultFormRef))

/**
 * 取消按钮
 */
const handelCancel = () => {
    formRef.value = cloneDeep(defaultFormRef)
    loading.value = false
    visible.value = false
}

/**
 * 提交方法
 */
const emits = defineEmits(['ok'])
const handleOk = async () => {
    loading.value = true

    update({ id: rows.value.id, distType: JSON.stringify(formRef.value) }).then((res) => {
        if (res.code === 1) {
            rows.value.distType = JSON.stringify(formRef.value)
            emits('ok', JSON.stringify(formRef.value))
            handelCancel()
        }
        loading.value = false
    })
}

/**
 * 显示弹窗
 * @param row
 */
const show = (row: any) => {
    rows.value = row
    if (rows.value.distType) {
        const distType = JSON.parse(rows.value.distType)
        assignIn(formRef.value, distType)
    }
    visible.value = true
}

defineExpose({ show })

/**
 * 自定义选项添加
 */
const addCustom = () => {
    console.log(formRef.value)
    formRef.value.custom.push({
        label: '',
        value: '',
    })
}
/**
 * 自定义选项删除
 */
const removeCustom = (item: any) => {
    let index = formRef.value.custom.indexOf(item)
    if (index !== -1) {
        formRef.value.custom.splice(index, 1)
    }
}
</script>

<style scoped lang="less"></style>
