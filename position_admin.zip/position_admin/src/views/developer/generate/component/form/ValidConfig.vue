<template>
    <AModal
        v-model:visible="visible"
        title="校验方式配置"
        @ok="handleOk"
        @cancel="handelCancel"
        :confirm-loading="loading"
        :destroyOnClose="true"
        :maskClosable="false"
        :closable="false"
    >
        <AForm
            class="padding"
            ref="myFormRef"
            name="myFormRef"
            :label-col="{ span: 6 }"
            :wrapper-col="{ span: 16 }"
            :model="formRef"
        >
            <AFormItem label="必填" name="required">
                <ACheckbox v-model:checked="formRef.required"></ACheckbox>
            </AFormItem>
            <AFormItem label="最小长度" name="min">
                <AInputNumber
                    style="width: 100%"
                    v-model:value="formRef.min"
                    :min="0"
                    :max="99999999"
                />
            </AFormItem>
            <AFormItem label="最大长度" name="max">
                <AInputNumber
                    style="width: 100%"
                    v-model:value="formRef.max"
                    :min="1"
                    :max="99999999"
                />
            </AFormItem>
            <AFormItem label="必须长度" name="len">
                <AInputNumber
                    style="width: 100%"
                    v-model:value="formRef.len"
                    :min="1"
                    :max="99999999"
                />
            </AFormItem>
            <AFormItem label="正则表达式" name="pattern">
                <!--                <AInput v-model:value="formRef.pattern"></AInput>-->
                <AInput v-model:value="formRef.pattern">
                    <template #addonBefore>
                        <ASelect v-model:value="formRef.pattern" style="width: 120px">
                            <ASelectOption value="">自定义</ASelectOption>
                            <ASelectOption value="^1[3|4|5|6|7|8|9]\d{9}$">手机号</ASelectOption>
                            <ASelectOption value="^(\d3,4\d3,4|\d{3,4}-)?\d{7,8}$"
                                >固定电话
                            </ASelectOption>
                            <!--                          ^\w+[-+.]\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*$-->
                            <ASelectOption
                                value="^[a-zA-Z0-9_-]+@[a-zA-Z0-9_-]+(\.[a-zA-Z0-9_-]+)+$"
                                >邮箱
                            </ASelectOption>
                            <ASelectOption value="^[0-9]*$">数字</ASelectOption>
                            <ASelectOption value="^[0-9]+(.[0-9]{2})?$">两位小数</ASelectOption>
                            <ASelectOption value="^\d+$">正整数</ASelectOption>
                            <ASelectOption value="^\+?[1-9][0-9]*$">非零的正整数</ASelectOption>
                            <ASelectOption value="^[\u4e00-\u9fa5],{0,}$">汉字</ASelectOption>
                            <ASelectOption
                                value="^(?:http(s)?:\/\/)?[\w.-]+(?:\.[\w\.-]+)+[\w\-\._~:/?#[\]@!\$&'\*\+,;=.]+$"
                                >URL
                            </ASelectOption>
                            <ASelectOption
                                value="^\d{6}(18|19|20)?\d{2}(0[1-9]|1[12])(0[1-9]|[12]\d|3[01])\d{3}(\d|X)$"
                                >身份证号
                            </ASelectOption>
                        </ASelect>
                    </template>
                </AInput>
            </AFormItem>
            <AFormItem label="错误提示" name="message">
                <AInput v-model:value="formRef.message"></AInput>
            </AFormItem>
        </AForm>
    </AModal>
</template>

<script setup lang="ts">
import { ref } from 'vue'
import { cloneDeep } from 'lodash-es'
import { isNotEmpty } from '@/utils/ValidateUtils'
import { update } from '@/api/tools/StTableColumnInfo'
import { leftCover } from '@/utils/ObjectUtils'

const loading = ref(false)
const visible = ref(false)
const defaultFormRef = {
    required: false, //是否必选
    min: '', //最小长度
    len: '', //字段长度
    max: '', //最大长度
    pattern: '', //正则表达式校验
    message: '', //校验文案
}
const rows = ref()
const formRef = ref<any>(cloneDeep(defaultFormRef))

/**
 * 取消按钮
 */
const handelCancel = () => {
    formRef.value = cloneDeep(defaultFormRef)
    loading.value = false
    visible.value = false
}

/**
 * 提交方法
 */
const emits = defineEmits(['ok'])
const handleOk = async () => {
    loading.value = true
    const rules = {} as any
    for (let i in formRef.value) {
        if (isNotEmpty(formRef.value[i]) && formRef.value[i] !== false) {
            rules[i] = formRef.value[i]
        }
    }

    update({ id: rows.value.id, formValid: JSON.stringify(rules) }).then((res) => {
        if (res.code === 1) {
            rows.value.formValid = JSON.stringify(rules)
            emits('ok', rules)
            handelCancel()
        }
        loading.value = false
    })
}

/**
 * 显示弹窗
 * @param row
 */
const show = (row: any) => {
    rows.value = row
    if (rows.value.formValid) {
        const formValid = JSON.parse(rows.value.formValid)
        leftCover(formRef.value, formValid)
    }
    visible.value = true
}

defineExpose({ show })
</script>

<style scoped lang="less"></style>
