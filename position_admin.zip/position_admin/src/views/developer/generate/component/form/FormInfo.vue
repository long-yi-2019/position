<template>
    <div style="margin-top: -10px">
        <MyTablePage
            ref="MyTablePageRef"
            :url="dataUrl"
            :columns="columns"
            :ellipsis="1"
            show-index
            :height="-20"
            :drag="true"
            @dragend="handelDragend"
        >
            <template #tools>
                <AButton style="margin-left: 10px" @click="handelSync" :loading="loading">
                    <template #icon> <SyncOutlined /> </template>同步表结构</AButton
                >
            </template>
        </MyTablePage>
        <ValidConfig ref="ValidConfigRefs"></ValidConfig>
        <OptionConfig ref="OptionConfigRefs"></OptionConfig>
    </div>
</template>

<script setup lang="ts" name="VueColumnInfo">
import { onMounted, ref } from 'vue'
import { SyncOutlined } from '@ant-design/icons-vue'
import { message } from 'ant-design-vue'
import { sort, update } from '@/api/tools/StTableColumnInfo'
const MyTablePageRef = ref()
const ValidConfigRefs = ref()
const OptionConfigRefs = ref()
//MyTablePageRef
import { columnSync } from '@/api/tools/StTableColumnInfo'
import ValidConfig from '@/views/developer/generate/component/form/ValidConfig.vue'
import OptionConfig from '@/views/developer/generate/component/form/OptionConfig.vue'

const columns = ref([
    {
        title: '字段列名',
        dataIndex: 'columnName',
        fixed: 'left',
        hidden: true,
    },
    {
        title: '字段描述',
        dataIndex: 'columnComment',
        fixed: 'left',
        formatter: {
            type: 'input',
            format: (row: any): any => {
                return {
                    pressEnter: (e: any) => {
                        const value = e.target.value
                        update({ id: row.id, columnComment: value }).then((res) => {
                            if (res.code === 1) {
                                message.success('保存成功')
                            }
                        })
                    },
                    value: row.columnComment,
                }
            },
        },
    },
    {
        title: '列类型',
        dataIndex: 'columnType',
        hidden: true,
    },
    {
        title: 'java属性名称',
        dataIndex: 'propertyName',
        formatter: {
            type: 'text',
            format: (row: any): any => {
                return {
                    value: row.propertyName,
                    color: row.inForm === '1' ? 'success' : '',
                }
            },
        },
    },
    {
        title: 'java类型',
        dataIndex: 'javaType',
    },
    {
        title: '表单',
        dataIndex: 'inForm',
        formatter: {
            type: 'select',
            format: (row: any): any => {
                return {
                    /*同a-select*/
                    change: (value: any) => {
                        update({ id: row.id, inForm: value }).then((res) => {
                            if (res.code === 1) {
                                message.success('保存成功')
                            }
                        })
                    },
                    value: [
                        {
                            label: `是`,
                            value: '1',
                        },
                        {
                            label: `否`,
                            value: '0',
                        },
                    ],
                }
            },
        },
    },
    {
        title: '默认值',
        dataIndex: 'defaultValue',
        formatter: {
            type: 'input',
            format: (row: any): any => {
                return {
                    pressEnter: (e: any) => {
                        const value = e.target.value
                        update({ id: row.id, defaultValue: value }).then((res) => {
                            if (res.code === 1) {
                                message.success('保存成功')
                            }
                        })
                    },
                    value: row.columnComment,
                }
            },
        },
    },
    {
        title: '空提示',
        dataIndex: 'placeholder',
        formatter: {
            type: 'input',
            format: (row: any): any => {
                return {
                    pressEnter: (e: any) => {
                        const value = e.target.value
                        update({ id: row.id, placeholder: value }).then((res) => {
                            if (res.code === 1) {
                                message.success('保存成功')
                            }
                        })
                    },
                    value: row.columnComment,
                }
            },
        },
    },

    {
        title: 'UI建议',
        dataIndex: 'uiAdvise',
        formatter: {
            type: 'select',
            format: (row: any): any => {
                return {
                    /*同a-select*/
                    change: (value: any) => {
                        update({ id: row.id, uiAdvise: value }).then((res) => {
                            if (res.code === 1) {
                                message.success('保存成功')
                            }
                        })
                    },
                    value: [
                        {
                            label: `文本输入框`,
                            value: 'text',
                        },
                        {
                            label: `数字输入框`,
                            value: 'number',
                        },
                        {
                            label: `密码框`,
                            value: 'password',
                        },
                        {
                            label: `大文本输入框`,
                            value: 'textarea',
                        },
                        {
                            label: `下拉选择`,
                            value: 'select',
                        },
                        {
                            label: `单选框`,
                            value: 'radio',
                        },
                        {
                            label: `复选框`,
                            value: 'checkbox',
                        },
                        {
                            label: `树形下拉框`,
                            value: 'treeSelect',
                        },
                        {
                            label: `日期选择框`,
                            value: 'datePicker',
                        },
                        {
                            label: `文件上传`,
                            value: 'upload',
                        },
                        {
                            label: `富文本`,
                            value: 'rick',
                        },
                    ],
                }
            },
        },
    },
    {
        title: '校验方式',
        dataIndex: 'formValid',
        click: (row: any) => {
            if (row.inForm === '1') {
                ValidConfigRefs.value.show(row)
            } else {
                message.error('该列未加入form')
            }
        },
    },
    {
        title: '选项配置',
        dataIndex: 'distType',
        click: (row: any) => {
            if (
                row.uiAdvise === 'select' ||
                row.uiAdvise === 'radio' ||
                row.uiAdvise === 'cascade' ||
                row.uiAdvise === 'treeSelect' ||
                row.uiAdvise === 'checkbox'
            ) {
                OptionConfigRefs.value.show(row)
            } else {
                message.error('该配置仅适用于下拉，单选，多选，级联')
            }
        },
    },
])
const dataUrl = `${import.meta.env.VITE_API_URL_GEN}/v1/st/table/column/info/getList`

const loading = ref(false)

const props = defineProps<{
    id: string
}>()
/**
 * 拖动排序结束
 */
const handelDragend = ({ item, newIndex, oldIndex, rows }: any) => {
    let moveType = 'prev'
    let target: { id: string }
    if (newIndex > oldIndex) {
        moveType = 'next'
        target = rows[newIndex - 1]
    } else {
        target = rows[newIndex + 1]
    }
    sort({ moveType: moveType, dragId: item.id, targetId: target.id }).then(() => {})
}
/**
 * 同步表结构
 */
const handelSync = async () => {
    loading.value = true
    await columnSync({ tableInfoId: props.id }).then((res) => {
        if (res.code === 1) {
            MyTablePageRef.value.search({ tableInfoId: props.id })
        }
    })
    loading.value = false
}
onMounted(() => {
    MyTablePageRef.value.search({ tableInfoId: props.id })
})
</script>

<style scoped lang="less"></style>
