<template>
    <PageWrapper title="代码生成" sub-title="通过配置生成代码，有效节省撸码时间">
        <MyTablePage
            ref="MyTablePageRef"
            :search-item="searchItem"
            :url="dataUrl"
            :columns="columns"
            :action="action"
            :ellipsis="1"
            show-index
            pagination
            selection="checkbox"
        >
            <template #tools>
                <AButton type="primary" @click="goAdd()">
                    <template #icon>
                        <PlusOutlined />
                    </template>
                    添加
                </AButton>
                <AButton type="danger" @click="goDels()">
                    <template #icon>
                        <PlusOutlined />
                    </template>
                    批量删除
                </AButton>
            </template>
        </MyTablePage>
        <TableSelect ref="tableSelectRef" @ok="selectOk" title="选择数据表"></TableSelect>
        <ConfigSelect
            ref="configSelectRef"
            @ok="configSelectOk"
            title="复制基础配置"
        ></ConfigSelect>
        <Edit ref="editRef"></Edit>
    </PageWrapper>
</template>

<script setup lang="ts" name="SysTableInfoUpdate">
import { onActivated, onMounted, ref } from 'vue'
import { PlusOutlined } from '@ant-design/icons-vue'
import { message, Modal } from 'ant-design-vue'
import TableSelect from './component/TableSelect.vue'
import ConfigSelect from './component/ConfigSelect.vue'
import { create, del } from '@/api/tools/StTableInfo'
import Edit from './edit.vue'
import { cloneDeep } from 'lodash-es'
const MyTablePageRef = ref()
const configSelectRef = ref()
const editRef = ref()
const dataUrl = `${import.meta.env.VITE_API_URL_GEN}/v1/st/table/info/getList`

const tableSelectRef = ref()

const columns = ref<any[]>([
    {
        title: '表名',
        dataIndex: 'tableName',
        sorter: true,
        align: 'left',
    },
    {
        title: '表描述',
        dataIndex: 'tableComment',
        align: 'left',
    },
    {
        title: '实体名称',
        dataIndex: 'className',
        sorter: true,
        align: 'left',
    },
    {
        title: '创建时间',
        dataIndex: 'createdTime',
        sorter: true,
        align: 'left',
    },
    {
        title: '更新时间',
        dataIndex: 'updatedTime',
        sorter: true,
        align: 'left',
    },
])

const action = ref({
    width: 250,
    fixed: 'right',
    buttons: [
        {
            title: '编辑',
            icon: 'iconfont icon-bianji',
            event: (row: any) => {
                editRef.value.show({ id: row.id })
                // router
                //     .push({
                //         path: './edit',
                //         query: { id: row.id },
                //     })
                //     .then(() => {})
            },
        },
        {
            title: '删除',
            color: '#f12424', // primary,success,warn,danger,info
            icon: 'iconfont icon-shanchu',
            event: (row: any) => {
                dels([row.id])
            },
        },
        {
            title: '复制',
            color: 'warn', // primary,success,warn,danger,info
            icon: 'iconfont icon-bianji',
            event: (row: any) => {
                configSelectRef.value.show(row.id)
            },
        },
        {
            title: '生成',
            color: 'success', // primary,success,warn,danger,info
            icon: 'iconfont icon-bianji',
            event: (row: any) => {
                if (!import.meta.env.DEV) {
                    message.error('此功能仅对开发环境开放')
                    return
                }
                create({ id: row.id }).then((res) => {
                    if (res.code === 1) {
                        message.success('生成成功')
                    }
                })
            },
        },
    ],
})

const searchItem = ref([
    {
        type: 'text',
        key: 'tableName',
        label: '表名',
        value: '',
        placeholder: '',
    },
    {
        type: 'text',
        key: 'tableComment',
        label: '表描述',
        value: '',
        placeholder: '',
    },
])

/**
 * 批量删除方法
 * @param ids
 */
const dels = (ids?: string[]) => {
    if (ids === undefined) {
        const { selectedRowKeys } = MyTablePageRef.value.getSelection()
        ids = cloneDeep(selectedRowKeys)
    }
    if (!ids || ids?.length < 1) {
        Modal.confirm({
            title: '请先选择删除项！',
        })
        return
    }
    Modal.confirm({
        title: '确定删除？',
        content: '删除后将无法恢复',
        okType: 'danger',
        onOk() {
            del(ids).then((res: any) => {
                if (res.code === 1) {
                    message.success('删除成功').then(() => {})
                    MyTablePageRef.value.search()
                }
            })
        },
    })
}

/**
 * 添加
 */
const goAdd = () => {
    tableSelectRef.value.show()
}
const selectOk = () => {
    MyTablePageRef.value.search()
}
const configSelectOk = () => {
    message.success('基础属性复制完成')
}

/**
 * 批量删除
 */
const goDels = () => {
    dels()
}
const activated = ref(false)
onActivated(() => {
    if (activated.value) {
        MyTablePageRef.value.search()
    } else {
        activated.value = true
    }
})

onMounted(() => {
    MyTablePageRef.value.search()
})
</script>

<style scoped lang="less" name="sysRoleList"></style>
