<!--流程设计-->
<template>
    <YxModal
        ref="YxModalRef"
        title="流程设计"
        v-model:visible="visible"
        @ok="onSubmit"
        @cancel="onCancel"
        :submit-loading="submitLoading"
    >
        <div class="zoom">
            <ASpace>
                <div class="zoom_in">
                    <MinusSquareOutlined style="font-size: 30px; color: #75787c" />
                </div>
                <div class="zoom_num"><span>100%</span></div>
                <div class="zoom_out">
                    <PlusSquareOutlined style="font-size: 30px; color: #75787c" />
                </div>
            </ASpace>
        </div>
        <!--      开始-->
        <RenderFlowModule
            @startClick="startClick"
            @approveClick="approveClick"
            @notifyClick="notifyClick"
            @routeClick="routeClick"
            @addApprove="addApprove"
            @addNotify="addNotify"
            @removeItem="removeItem"
            :nodes="nodes"
        ></RenderFlowModule>
        <StartConfig ref="startConfigRef" @ok="startConfigOk"></StartConfig>
        <ApproveConfig ref="approveConfigRef" @ok="approveConfigOK"></ApproveConfig>
        <NotifyConfig ref="notifyConfigRef" @ok="notifyConfigOk"></NotifyConfig>
        <RouteConfig ref="routeConfigRef"></RouteConfig>
    </YxModal>
</template>
<script setup lang="ts" name="workflowDesign">
import { onMounted, ref } from 'vue'
import { MinusSquareOutlined, PlusSquareOutlined } from '@ant-design/icons-vue'
import RenderFlowModule from './components/RenderFlowModule'
import StartConfig from '@/views/developer/workflow/components/StartConfig.vue'
import ApproveConfig from '@/views/developer/workflow/components/ApproveConfig.vue'
import NotifyConfig from '@/views/developer/workflow/components/NotifyConfig.vue'
import RouteConfig from '@/views/developer/workflow/components/RouteConfig.vue'
import idUtils from '@/utils/IdUtils'
const approveConfigRef = ref()
const startConfigRef = ref()
const notifyConfigRef = ref()
const routeConfigRef = ref()
const nodes = ref([
    {
        id: '1',
        type: 'START', //节点类型，开始
        authority: [
            //谁能申请（部门或人员）
            {
                code: '100',
                name: '全部',
            },
        ],
    },
    {
        id: '2',
        type: 'APPROVE',
        name: '审批人',
        approveType: '3', //审批类型
        optionScope: '1', //可选范围:1不限范围，2指定范围
        optionScopeData: [], //指定的用户信息｛id,name｝
        selectMethod: '2', //选人方式:1单选，2多选
        approveMethod: '3', //多人审批方式，1或签，2会签，3依次审批
    },
    {
        id: 'notify1',
        type: 'NOTIFY',
        name: '抄送人',
        optionScopeData: [], //指定抄送人
        allowCusSelect: '1', //申请人自选
        notifyToMe: '0', //抄送给自己
    },
    {
        id: 'end1',
        type: 'END',
    },
])

/**
 * 通过id在指定节点插入对象
 */
const insertChild = (tree, id, obj) => {
    try {
        tree.forEach((item, i) => {
            if (item.id === id) {
                tree.splice(i + 1, 0, obj)
                throw new Error('正常结束')
            }
            if (item.children && item.children.length > 0) {
                item.children.forEach((child) => {
                    insertChild(child, id, obj) // 递归调用自身
                })
            }
        })
    } catch (e) {
        /* empty */
    }
}

/**
 * 添加审批节点
 */
const addApprove = (item) => {
    const nowTime = new Date().getTime()
    insertChild(nodes.value, item.id, {
        id: 'A' + idUtils.random(5) + nowTime,
        type: 'APPROVE',
        name: '审批人',
        approveType: '3', //审批类型
        optionScope: '1', //可选范围:1不限范围，2指定范围
        optionScopeData: [], //指定的用户信息｛id,name｝
        selectMethod: '2', //选人方式:1单选，2多选
        approveMethod: '3', //多人审批方式，1或签，2会签，3依次审批
    })
}

/**
 * 通过id在指定节点删除
 */
const removeNode = (tree, id) => {
    try {
        tree.forEach((item, i) => {
            console.log(item.id === id, item.id, id)
            if (item.id === id) {
                console.log('可以删除了。')
                tree.splice(i, 1)
                throw new Error('正常结束')
            }
            if (item.children && item.children.length > 0) {
                item.children.forEach((child) => {
                    removeNode(child, id) // 递归调用自身
                })
            }
        })
    } catch (e) {
        /* empty */
    }
}

/**
 * 添加抄送节点
 * @param item
 */
const addNotify = (item) => {
    const nowTime = new Date().getTime()
    insertChild(nodes.value, item.id, {
        id: 'N' + idUtils.random(5) + nowTime,
        type: 'NOTIFY',
        name: '抄送人',
        optionScopeData: [], //指定抄送人
        allowCusSelect: '1', //申请人自选
        notifyToMe: '0', //抄送给自己
    })
}
const removeItem = (item) => {
    console.log(item)
    if (item.type === 'NOTIFY' || item.type === 'APPROVE') {
        removeNode(nodes.value, item.id)
    }
}

/**
 * 通过id找到对象
 */
const setChild = (tree, data) => {
    tree.forEach((item, i) => {
        if (item.id === data.id) {
            Object.assign(tree[i], data)
        }
        if (item.children) {
            if (item.children && item.children.length > 0) {
                item.children.forEach((child) => {
                    setChild(child, data) // 递归调用自身
                })
            }
        }
    })
}

/**
 * 申请人配置
 * @param item
 */
const startClick = (item) => {
    startConfigRef.value.show(item)
}
const startConfigOk = (item) => {
    nodes.value[0].authority = item
}
const approveClick = (item) => {
    approveConfigRef.value.show(item)
}
const approveConfigOK = (item) => {
    setChild(nodes.value, item)
}

const notifyClick = (item) => {
    notifyConfigRef.value.show(item)
}
const notifyConfigOk = (item) => {
    setChild(nodes.value, item)
}
const routeClick = (item) => {
    console.log(item)
    routeConfigRef.value.show(item)
}
/**
 * 基础数据定义
 */
const visible = ref(true)
const submitLoading = ref(false)
const show = (params?: any) => {
    console.log(params)
    visible.value = true
}

defineExpose({ show })
const onSubmit = () => {}
/**
 * 关闭弹窗
 */
const onCancel = () => {
    visible.value = false
}
onMounted(() => {})
</script>
<style lang="less">
@import url(./workFlowDesign.less);
</style>
