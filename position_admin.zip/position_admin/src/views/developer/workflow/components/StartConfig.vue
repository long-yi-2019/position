<!--开始节点-申请人配置-->
<template>
    <ADrawer
        v-model:visible="visible"
        title="申请人设置"
        placement="right"
        width="30%"
        :maskClosable="false"
        :keyboard="false"
        :closable="false"
    >
        <div>
            <ATypographyParagraph>
                <ATypographyText strong>可提交申请的成员</ATypographyText>
            </ATypographyParagraph>
            <ATypographyParagraph>
                <ATypographyText>
                    模板可见范围内成员可提交申请，修改后，模板可见范围将被同步修改
                </ATypographyText>
            </ATypographyParagraph>

            <ATreeSelect
                v-model:value="treeValue"
                style="width: 100%"
                :tree-data="treeData"
                tree-checkable
                allow-clear
                :show-checked-strategy="SHOW_PARENT"
                placeholder="请选择"
                tree-node-filter-prop="label"
                :treeIcon="true"
                :fieldNames="{
                    children: 'children',
                    label: 'title',
                    key: 'code',
                    value: 'code',
                }"
            >
                <template #title="data">
                    <template v-if="data.ext1 === 1">
                        <FolderOutlined style="margin-right: 5px" />{{ data.title }}
                    </template>
                    <template v-else>
                        <UserOutlined style="margin-right: 5px" />{{ data.title }}
                    </template>
                </template>
            </ATreeSelect>
        </div>
        <template #extra>
            <ASpace>
                <AButton @click="onClose">取消</AButton>
                <AButton type="primary" @click="onOk">确定</AButton>
            </ASpace>
        </template>
    </ADrawer>
</template>
<script setup lang="ts" name="StartConfig">
import { nextTick, onMounted, ref } from 'vue'
import { TreeSelect } from 'ant-design-vue'
import { getList } from '@/api/common'
const SHOW_PARENT = TreeSelect.SHOW_PARENT
import { FolderOutlined, UserOutlined } from '@ant-design/icons-vue'
const visible = ref<boolean>(false)
const treeValue = ref([])
const treeData = ref([])
const show = (item: any) => {
    treeValue.value = []

    visible.value = true
    getList(import.meta.env.VITE_API_URL_SYSTEM + '/v1/sys/department/getTreeAndUser', {}).then(
        (res) => {
            if (res.code === 1) {
                treeData.value = res.data
                nextTick(() => {
                    const d = [] as any
                    item.authority.forEach((v: any) => {
                        d.push(v.code)
                    })
                    treeValue.value = d
                })
            }
        },
    )
}
const findChild = (tree, array, result) => {
    tree.forEach((item) => {
        if (array.indexOf(item.code) > -1) {
            result.push({
                code: item.code,
                name: item.title,
            })
        }
        if (item.children) {
            findChild(item.children, array, result) // 递归调用自身
        }
    })
}
const emits = defineEmits(['ok'])
const onOk = () => {
    const authority = [] as any
    findChild(treeData.value, treeValue.value, authority)
    emits('ok', JSON.parse(JSON.stringify(authority)))
    onClose()
}
const onClose = () => {
    visible.value = false
}
defineExpose({ show })
onMounted(() => {})
</script>
<style scoped lang="less"></style>
