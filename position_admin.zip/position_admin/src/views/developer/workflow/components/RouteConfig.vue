<!--开始节点-申请人配置-->
<template>
    <ADrawer
        v-model:visible="visible"
        title="条件设置"
        placement="right"
        width="30%"
        :maskClosable="false"
        :keyboard="false"
        :closable="false"
    >
        <div>
            <ATypographyParagraph>
                <ATypographyText strong>可提交申请的成员</ATypographyText>
            </ATypographyParagraph>
            <ATypographyParagraph>
                <ATypographyText>
                    模板可见范围内成员可提交申请，修改后，模板可见范围将被同步修改
                </ATypographyText>
            </ATypographyParagraph>

            <ATag
                v-for="(tag, index) in tags"
                style="margin-bottom: 10px"
                :key="index"
                :closable="true"
                @close="handleClose(tag)"
            >
                {{ tag }}
            </ATag>
            <a href="javascript:void(0)">添加</a>
        </div>
        <template #extra>
            <ASpace>
                <AButton @click="onClose">取消</AButton>
                <AButton type="primary" @click="onClose">确定</AButton>
            </ASpace>
        </template>
    </ADrawer>
</template>
<script setup lang="ts" name="RouteConfig">
import { onMounted, ref } from 'vue'
const visible = ref<boolean>(false)

const tags = ref(['部门1', '部门1', '部门1', '部门1', '部门2', '张三李', '我的名字要多长就有多长'])
const handleClose = (tag) => {
    console.log('删除标签', tag)
}
const show = (item: any) => {
    console.log(item)
    visible.value = true
}
const onClose = () => {
    visible.value = false
}
defineExpose({ show })
onMounted(() => {})
</script>
<style scoped lang="less"></style>
