<!--开始节点-申请人配置-->
<template>
    <ADrawer
        v-model:visible="visible"
        title="审批人设置"
        placement="right"
        width="30%"
        :maskClosable="false"
        :keyboard="false"
        :closable="false"
    >
        <AForm ref="myFormRef" layout="vertical" :model="formState">
            <AFormItem
                label=""
                name="name"
                :rules="[{ max: 20, message: '必填；最大长度20', required: true }]"
            >
                <AInput v-model:value="formState.name" placeholder="节点名称" />
            </AFormItem>
            <AFormItem label="">
                <ARadioGroup v-model:value="formState.approveType">
                    <ARadio value="1">指定成员</ARadio>
                    <ARadio value="2">申请人本人</ARadio>
                    <ARadio value="3">申请人自选</ARadio>
                    <ARadio value="4">指定角色</ARadio>
                </ARadioGroup>
            </AFormItem>
            <ADivider />
            <!--    指定成员      -->
            <template v-if="formState.approveType == '1'">
                <AFormItem
                    label=""
                    name="optionScope"
                    :rules="[
                        {
                            validator: validateOptionScope,
                            trigger: 'change',
                            required: true,
                        },
                    ]"
                >
                    <a href="javaScript:void(0)" @click="showUserMultipleSelection">选择</a>
                    <div>
                        <ATag
                            v-for="item in formState.optionScopeData"
                            :key="item.id"
                            style="margin-top: 8px"
                            closable
                            color="#2db7f5"
                            @close.prevent="removeScopeUser(item)"
                        >
                            {{ item.name }}
                        </ATag>
                    </div>
                </AFormItem>
                <AFormItem label="多人审批方式" v-if="formState.optionScopeData.length > 1">
                    <ARadioGroup v-model:value="formState.approveMethod">
                        <ARadio :style="radioStyle" value="1">或签（ 一名成员同意即可 ）</ARadio>
                        <ARadio :style="radioStyle" value="2">会签（ 须所有成员同意 ）</ARadio>
                        <ARadio :style="radioStyle" value="3">依次审批（按顺序依次审批）</ARadio>
                    </ARadioGroup>
                </AFormItem>
            </template>
            <!--    申请人自选-->
            <template v-if="formState.approveType == '3'">
                <AFormItem
                    label="可选范围"
                    name="optionScope"
                    :rules="[
                        {
                            validator: validateOptionScope,
                            trigger: 'change',
                            required: true,
                        },
                    ]"
                >
                    <ARadioGroup v-model:value="formState.optionScope">
                        <ARadio value="1">不限范围</ARadio>
                        <ARadio value="2">指定范围</ARadio>
                    </ARadioGroup>
                    <template v-if="formState.optionScope == '2'">
                        <a href="javaScript:void(0)" @click="showUserMultipleSelection">选择</a>
                        <div>
                            <ATag
                                v-for="item in formState.optionScopeData"
                                :key="item.id"
                                style="margin-top: 8px"
                                closable
                                color="#2db7f5"
                                @close.prevent
                            >
                                {{ item.name }}
                            </ATag>
                        </div>
                    </template>
                </AFormItem>
                <AFormItem label="选人方式">
                    <ARadioGroup v-model:value="formState.selectMethod">
                        <ARadio value="1">单选</ARadio>
                        <ARadio value="2">多选</ARadio>
                    </ARadioGroup>
                </AFormItem>
                <AFormItem label="多人审批方式" v-if="formState.selectMethod == '2'">
                    <ARadioGroup v-model:value="formState.approveMethod">
                        <ARadio :style="radioStyle" value="1">或签（ 一名成员同意即可 ）</ARadio>
                        <ARadio :style="radioStyle" value="2">会签（ 须所有成员同意 ）</ARadio>
                        <ARadio :style="radioStyle" value="3">依次审批（按顺序依次审批）</ARadio>
                    </ARadioGroup>
                </AFormItem>
            </template>
            <template v-if="formState.approveType == '4'">
                <AFormItem
                    label="选择角色"
                    name="roles"
                    :rules="[{ validator: validateRoles, trigger: 'change', required: true }]"
                >
                    <ACheckboxGroup v-model:value="checkRoleIds" style="width: 100%">
                        <ARow>
                            <ACol :span="8" v-for="item in roleList" :key="item.id">
                                <ACheckbox :value="item.id">
                                    {{ item.title }}
                                </ACheckbox>
                            </ACol>
                        </ARow>
                    </ACheckboxGroup>
                </AFormItem>
                <AFormItem label="多人审批方式">
                    <ARadioGroup v-model:value="formState.approveMethod">
                        <ARadio :style="radioStyle" value="1">或签（ 一名成员同意即可 ）</ARadio>
                        <ARadio :style="radioStyle" value="2">会签（ 须所有成员同意 ）</ARadio>
                        <ARadio :style="radioStyle" value="3">依次审批（按顺序依次审批）</ARadio>
                    </ARadioGroup>
                </AFormItem>
            </template>
        </AForm>
        <template #extra>
            <ASpace>
                <AButton @click="onClose">取消</AButton>
                <AButton type="primary" @click="onSubmit">确定</AButton>
            </ASpace>
        </template>
        <UserMultipleSelection
            @ok="handleUserMultipleSelectionOk"
            ref="userMultipleSelectionRef"
        ></UserMultipleSelection>
    </ADrawer>
</template>
<script setup lang="ts" name="ApproveConfig">
import { onMounted, reactive, ref, watch } from 'vue'
import UserMultipleSelection from '@/components/UserMultipleSelection.vue'
import { FormInstance } from 'ant-design-vue'
import { getList } from '@/api/common'
const visible = ref<boolean>(false)
const myFormRef = ref<FormInstance>()
const userMultipleSelectionRef = ref()
const radioStyle = reactive({
    display: 'flex',
    height: '30px',
    lineHeight: '30px',
})
const checkRoleIds = ref<any>([]) //角色选中项
const roleList = ref([])
watch(checkRoleIds, () => {
    formState.value.roles = roleList.value
        .filter((v: any) => checkRoleIds.value.indexOf(v.id) > -1)
        .map((value: any) => {
            return {
                id: value.id,
                name: value.title,
            }
        })
})
const defOptions = {
    optionScope: '1', //可选范围:1不限范围，2指定范围
    optionScopeData: [], //指定的用户信息｛id,name｝
    selectMethod: '2', //选人方式:1单选，2多选
    approveMethod: '3', //多人审批方式，1或签，2会签，3依次审批
    roles: [] as any, //指定审批角色｛id,name｝
}
const defFrom = {
    id: '',
    name: '审批人',
    type: 'APPROVE',
    approveType: '3', //审批类型
    ...defOptions,
}

const formState = ref({ ...defFrom })

let validateOptionScope = async () => {
    if (formState.value.optionScope == '2') {
        if (formState.value.optionScopeData.length < 1) {
            return Promise.reject('请选择用户范围')
        }
    }

    if (formState.value.approveType == '1') {
        if (formState.value.optionScopeData.length < 1) {
            return Promise.reject('请选择用户范围')
        }
    }

    return Promise.resolve()
}
let validateRoles = async () => {
    if (checkRoleIds.value.length < 1) {
        return Promise.reject('请选择审批角色')
    }

    return Promise.resolve()
}

/**
 * 指定用户范围
 */
const showUserMultipleSelection = () => {
    userMultipleSelectionRef.value.show(formState.value.optionScopeData)
}
const handleUserMultipleSelectionOk = (checkList) => {
    formState.value.optionScopeData = JSON.parse(JSON.stringify(checkList))
    myFormRef.value?.validateFields()
}
/**
 * 移除范围内用户
 */
const removeScopeUser = (item) => {
    formState.value.optionScopeData = formState.value.optionScopeData.filter(
        (u: any) => u.id != item.id,
    )
}

watch(
    () => formState.value.approveType,
    (val) => {
        formState.value = Object.assign(formState.value, { ...defOptions })
        if (val === '4') {
            getList(`${import.meta.env.VITE_API_URL_SYSTEM}/v1/sys/role/getList`, {
                pageNumber: 1,
                pageSize: -1,
            }).then((res) => {
                if (res.code === 1) {
                    const data = res.data
                    roleList.value = data.rows
                }
            })
        }
    },
)

const emits = defineEmits(['ok'])

const show = (item: any) => {
    formState.value = Object.assign(defFrom, JSON.parse(JSON.stringify(item)))
    visible.value = true
}
const onSubmit = () => {
    myFormRef.value?.validate().then(() => {
        emits('ok', JSON.parse(JSON.stringify(formState.value)))
        onClose()
    })
}
const onClose = () => {
    visible.value = false
}
defineExpose({ show })
onMounted(() => {})
</script>
<style scoped lang="less"></style>
