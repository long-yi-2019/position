<!--开始节点-申请人配置-->
<template>
    <ADrawer
        v-model:visible="visible"
        title="通知人设置"
        placement="right"
        width="30%"
        :maskClosable="false"
        :keyboard="false"
        :closable="false"
    >
        <AForm ref="myFormRef" layout="vertical" :model="formState">
            <AFormItem
                label=""
                name="name"
                :rules="[{ max: 20, message: '必填；最大长度20', required: true }]"
            >
                <AInput v-model:value="formState.name" placeholder="节点名称" />
            </AFormItem>
            <AFormItem label="指定抄送人" name="optionScopeData">
                <a href="javaScript:void(0)" @click="showUserMultipleSelection">选择</a>
                <div>
                    <ATag
                        v-for="item in formState.optionScopeData"
                        :key="item.id"
                        style="margin-top: 8px"
                        closable
                        color="#2db7f5"
                        @close.prevent
                    >
                        {{ item.name }}
                    </ATag>
                </div>
            </AFormItem>
            <AFormItem label="允许申请人自选" name="allowCusSelect" extra="申请人自行选择抄送人">
                <ARadioGroup v-model:value="formState.allowCusSelect">
                    <ARadio value="1">是</ARadio>
                    <ARadio value="0">否</ARadio>
                </ARadioGroup>
            </AFormItem>
            <AFormItem label="抄送给自己" name="notifyToMe" extra="">
                <ARadioGroup v-model:value="formState.notifyToMe">
                    <ARadio value="1">是</ARadio>
                    <ARadio value="0">否</ARadio>
                </ARadioGroup>
            </AFormItem>
        </AForm>
        <template #extra>
            <ASpace>
                <AButton @click="onClose">取消</AButton>
                <AButton type="primary" @click="onSubmit">确定</AButton>
            </ASpace>
        </template>
        <UserMultipleSelection
            @ok="handleUserMultipleSelectionOk"
            ref="userMultipleSelectionRef"
        ></UserMultipleSelection>
    </ADrawer>
</template>
<script setup lang="ts" name="NotifyConfig">
import { onMounted, ref } from 'vue'
import UserMultipleSelection from '@/components/UserMultipleSelection.vue'
import { FormInstance, message } from 'ant-design-vue'
const userMultipleSelectionRef = ref()
const visible = ref<boolean>(false)

const myFormRef = ref<FormInstance>()
const defFrom = {
    id: 'notify1',
    type: 'NOTIFY',
    name: '抄送人',
    optionScopeData: [], //指定抄送人
    allowCusSelect: '1', //申请人自选
    notifyToMe: '0', //抄送给自己
}

const formState = ref({ ...defFrom })

/**
 * 指定抄送人
 */
const showUserMultipleSelection = () => {
    userMultipleSelectionRef.value.show(formState.value.optionScopeData)
}
const handleUserMultipleSelectionOk = (checkList) => {
    formState.value.optionScopeData = JSON.parse(JSON.stringify(checkList))
}

const show = (item: any) => {
    formState.value = Object.assign(defFrom, JSON.parse(JSON.stringify(item)))
    visible.value = true
}
const onClose = () => {
    visible.value = false
}
defineExpose({ show })

const emits = defineEmits(['ok'])
const onSubmit = () => {
    myFormRef.value?.validate().then(() => {
        if (
            formState.value.optionScopeData.length > 0 ||
            formState.value.allowCusSelect === '1' ||
            formState.value.notifyToMe === '1'
        ) {
            emits('ok', JSON.parse(JSON.stringify(formState.value)))
            onClose()
        } else {
            message.error('请至少选择一项')
        }
    })
}

onMounted(() => {})
</script>
<style scoped lang="less"></style>
