import { defineComponent, h, Fragment } from 'vue'
import { CloseOutlined, PlusCircleFilled, RightOutlined } from '@ant-design/icons-vue'

const React = { createElement: h, Fragment }
export default defineComponent({
    props: {
        nodes: {
            type: Array,
            default: () => [],
        },
    },
    emits: [
        'startClick', //申请人节点点击
        'approveClick', //审批人节点点击
        'notifyClick', //通知人节点点击
        'routeClick', //条件节点点击
        'addApprove', //添加审批节点
        'addNotify', //添加通知节点
        'removeItem', //删除节点
    ],
    setup(props, context) {
        const popoverSlot = (item) => {
            return {
                content: () => {
                    return (
                        <div class="add-node-menu">
                            <div
                                class="menu-item menu-approver"
                                onClick={() => context.emit('addApprove', item)}
                            >
                                <i class="iconfont icon-shenpi1 menu-item-icon"></i>
                                <div>审批人</div>
                            </div>
                            <div
                                class="menu-item menu-notifier"
                                onClick={() => context.emit('addNotify', item)}
                            >
                                <i class="iconfont icon-chaosong1 menu-item-icon"></i>
                                <div>抄送人</div>
                            </div>
                            {/*<div class="menu-item menu-branch">*/}
                            {/*    <i class="iconfont icon-fenzhi menu-item-icon"></i>*/}
                            {/*    <div>条件分支</div>*/}
                            {/*</div>*/}
                        </div>
                    )
                },
            }
        }
        const renderAppUser = (authority) => {
            return authority.map((auth) => {
                return <span style={{ marginRight: '5px' }}>{auth.name}</span>
            })
        }
        /*申请人 - 开始节点*/
        const renderStart = (item) => {
            return (
                <div class="node-container">
                    <div id="START" class="node-box node-creator">
                        <div class="title">
                            <span class="node-title-name">申请人</span>
                        </div>
                        <div class="content" onClick={() => context.emit('startClick', item)}>
                            <div class="content-text">{renderAppUser(item.authority)}</div>
                            <RightOutlined style="color: #bfbfbf" />
                        </div>
                    </div>
                    <div class="add-node-btn-box">
                        <div class="add-node-btn">
                            <a-popover placement="right" v-slots={popoverSlot(item)}>
                                <div class="btn">
                                    <PlusCircleFilled class="btn-icon" />
                                </div>
                            </a-popover>
                        </div>
                    </div>
                </div>
            )
        }
        const renderEnd = () => {
            return (
                <div class="node-container">
                    <div id="END" class="node-box node-end">
                        <div class="line-end-arrow"></div>
                        流程结束
                    </div>
                </div>
            )
        }
        const getApproveDes = (item) => {
            let msg = ''
            if (item.approveType === '1') {
                msg += '指定成员  '
                if (item.optionScopeData.length > 1) {
                    if (item.approveMethod === '1') {
                        msg += '或签  '
                    } else if (item.approveMethod === '2') {
                        msg += '会签  '
                    } else if (item.approveMethod === '3') {
                        msg += '依次审批  '
                    }
                }
            }
            if (item.approveType === '2') {
                msg += '申请人本人  '
            }
            if (item.approveType === '3') {
                msg += '申请人自选  '
                if (item.optionScope === '1') {
                    msg += '不限范围  '
                } else if (item.optionScope === '2') {
                    msg += '指定范围  '
                }
                if (item.selectMethod === '1') {
                    msg += '单选  '
                } else if (item.selectMethod === '2') {
                    msg += '多选  '
                    if (item.approveMethod === '1') {
                        msg += '或签  '
                    } else if (item.approveMethod === '2') {
                        msg += '会签  '
                    } else if (item.approveMethod === '3') {
                        msg += '依次审批  '
                    }
                }
            }

            if (item.approveType === '4') {
                msg += '指定角色  '
                if (item.approveMethod === '1') {
                    msg += '或签  '
                } else if (item.approveMethod === '2') {
                    msg += '会签  '
                } else if (item.approveMethod === '3') {
                    msg += '依次审批  '
                }
            }
            return msg
        }
        const renderApprove = (item) => {
            return (
                <div class="node-container">
                    <div id="default_node_2" class="node-box node_approver">
                        {/*上移*/}
                        <span class="node-move-up-icon node-move-up-icon-disable"></span>
                        {/*结束箭头*/}
                        <div class="line-end-arrow"></div>
                        <div class="title">
                            <span class="node-title-name">{item.name}</span>
                            <span
                                class="node-title-operate"
                                style="flex-grow: 1"
                                onClick={() => context.emit('removeItem', item)}
                            >
                                <span class="node-title-delete">
                                    <CloseOutlined />
                                </span>
                            </span>
                        </div>
                        <div class="content" onClick={() => context.emit('approveClick', item)}>
                            <div class="content-text">
                                <div>{getApproveDes(item)}</div>
                            </div>
                            <RightOutlined style="color: #bfbfbf" />
                        </div>
                        {/*下移*/}
                        <span class="node-move-down-icon"></span>
                    </div>
                    <div class="add-node-btn-box">
                        <div class="add-node-btn">
                            <a-popover placement="right" v-slots={popoverSlot(item)}>
                                <div class="btn">
                                    <PlusCircleFilled class="btn-icon" />
                                </div>
                            </a-popover>
                        </div>
                    </div>
                </div>
            )
        }
        const getNotifyDes = (item) => {
            let msg = ''
            if (item.optionScopeData && item.optionScopeData.length > 0) {
                msg += '指定人员 '
            }
            if (item.allowCusSelect === '1') {
                msg += '申请人自选 '
            }
            if (item.notifyToMe === '1') {
                msg += '抄送给自己 '
            }
            return msg
        }
        const renderNotify = (item) => {
            return (
                <div class="node-container">
                    <div id="default_node_3" class="node-box node-notify">
                        <span class="node-move-up-icon"></span>
                        <div class="line-end-arrow"></div>
                        <div class="title">
                            <span class="node-title-name">{item.name}</span>
                            <span
                                class="node-title-operate"
                                style="flex-grow: 1"
                                onClick={() => context.emit('removeItem', item)}
                            >
                                <span class="node-title-delete">
                                    <CloseOutlined />
                                </span>
                            </span>
                        </div>
                        <div class="content" onClick={() => context.emit('notifyClick', item)}>
                            <div class="content-text">
                                <div class="content-text-row">{getNotifyDes(item)}</div>
                            </div>
                            <RightOutlined style="color: #bfbfbf" />
                        </div>
                        <span class="node-move-down-icon node-move-down-icon-disable"></span>
                    </div>
                    <div class="add-node-btn-box">
                        <div class="add-node-btn">
                            <a-popover placement="right" v-slots={popoverSlot(item)}>
                                <div class="btn">
                                    <PlusCircleFilled class="btn-icon" />
                                </div>
                            </a-popover>
                        </div>
                    </div>
                </div>
            )
        }
        const coverLine = (item, index) => {
            if (index === 0) {
                return (
                    <>
                        <div class="top-left-cover-line"></div>
                        <div class="bottom-left-cover-line"></div>
                    </>
                )
            } else if (index === item.children.length - 1) {
                return (
                    <>
                        <div class="top-right-cover-line"></div>
                        <div class="bottom-right-cover-line"></div>
                    </>
                )
            }
        }
        const renderRouterChildren = (item) => {
            return item.children.map((child, index) => {
                return (
                    <div class="col-box">
                        {coverLine(item, index)}
                        {useRenderFlow(child)}
                    </div>
                )
            })
        }
        const renderRouter = (item) => {
            return (
                <div class="node-container">
                    <div class="branch-wrap">
                        <div class="branch-wrap-box">
                            <div class="branch-box">
                                <div class="add-branch">添加条件</div>
                                {renderRouterChildren(item)}
                            </div>
                        </div>
                    </div>
                    <div class="add-node-btn-box">
                        <div class="add-node-btn">
                            <a-popover placement="right" v-slots={popoverSlot(item)}>
                                <div class="btn">
                                    <PlusCircleFilled class="btn-icon" />
                                </div>
                            </a-popover>
                        </div>
                    </div>
                </div>
            )
        }
        const renderRoute = (item) => {
            return (
                <div class="node-container">
                    <div class="node-condition">
                        <div class="node-box">
                            <div class="line-end-arrow"></div>
                            <div class="title">
                                <span class="node-title-name">条件1</span>{' '}
                                <span class="node-title-name-editable">
                                    <i class="ww_icon ww_approvalFlowIcon_Editable"></i>
                                </span>{' '}
                                <span class="node-title-operate" style="flex-grow: 1;">
                                    <span class="node-title-delete">
                                        <i class="ww_icon ww_approvalFlowIcon_Close"></i>
                                    </span>{' '}
                                    <span class="node-title-copy">
                                        <i class="ww_icon ww_approvalFlowIcon_CopyNode"></i>
                                    </span>
                                </span>{' '}
                                <span class="node-title-priority" style="flex-grow: 1;">
                                    优先级1
                                </span>
                            </div>
                            <div class="content" onClick={() => context.emit('routeClick', item)}>
                                <div class="content-text">
                                    <div>需同时满足以下条件：</div>
                                    <div class="content-text-grey">
                                        <span>申请人：刘强</span>
                                    </div>
                                    <div class="content-text-grey">
                                        <span>请假类型：事假</span>
                                    </div>
                                    <div class="content-text-grey">
                                        <span>请假时长：大于8小时</span>
                                    </div>
                                </div>
                                <i class="ww_commonImg ww_commonImg_PageNavArrowRightDisabled"></i>
                            </div>
                        </div>
                    </div>
                    <div class="add-node-btn-box">
                        <div class="add-node-btn">
                            <a-popover placement="right" v-slots={popoverSlot(item)}>
                                <div class="btn">
                                    <PlusCircleFilled class="btn-icon" />
                                </div>
                            </a-popover>
                        </div>
                    </div>
                </div>
            )
        }
        const useRenderFlow = (list: any[]) => {
            return list.map((item) => {
                /*开始*/
                if (item.type === 'START') {
                    return renderStart(item)
                }
                /*审批人*/
                if (item.type === 'APPROVE') {
                    return renderApprove(item)
                }
                /*抄送*/
                if (item.type === 'NOTIFY') {
                    return renderNotify(item)
                }
                /*结束*/
                if (item.type === 'END') {
                    return renderEnd()
                }
                /*条件分支*/
                if (item.type === 'ROUTER') {
                    return renderRouter(item)
                }
                /*具体分支条件*/
                if (item.type === 'ROUTE') {
                    return renderRoute(item)
                }
            })
        }

        return () => useRenderFlow(props.nodes)
    },
})
