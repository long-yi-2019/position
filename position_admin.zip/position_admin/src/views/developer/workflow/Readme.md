```javascript
const nodes = ref([
  {
    id: '1',
    type: 'START', //节点类型，开始
    authority: [
      //谁能申请（部门或人员）
      {
        code: '100',
        name: '全部',
      },
    ],
  },
  {
    id: '2',
    type: 'APPROVE',
    name: '审批人',
    approveType: '3', //审批类型
    optionScope: '1', //可选范围:1不限范围，2指定范围
    optionScopeData: [], //指定的用户信息｛id,name｝
    selectMethod: '2', //选人方式:1单选，2多选
    approveMethod: '3', //多人审批方式，1或签，2会签，3依次审批
  },
  {
    id: '3',
    type: 'ROUTER',
    children: [
      [
        {
          id: '4',
          type: 'ROUTE',
        },
        {
          id: '5',
          type: 'APPROVE',
        },
        {
          id: '6',
          type: 'NOTIFY',
          name: '抄送人',
          optionScopeData: [], //指定抄送人
          allowCusSelect: '1', //申请人自选
          notifyToMe: '0', //抄送给自己
        },
      ],
      [
        {
          id: '7',
          type: 'ROUTE',
        },
        {
          id: '8',
          type: 'APPROVE',
        },
      ],
    ],
  },
  {
    id: 'notify1',
    type: 'NOTIFY',
    name: '抄送人',
    optionScopeData: [], //指定抄送人
    allowCusSelect: '1', //申请人自选
    notifyToMe: '0', //抄送给自己
  },
  {
    id: 'end1',
    type: 'END',
  },
])
```