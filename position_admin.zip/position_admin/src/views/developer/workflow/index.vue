<!--流程设计-->
<template>
    <PageWrapper title="流程模板" sub-title="">
        <ASpace>
            <AButton type="primary" @click="addTemplate">
                <template #icon><PlusOutlined /></template>添加模板
            </AButton>
            <AButton type="primary">
                <template #icon><PlusOutlined /></template>添加分组
            </AButton>
        </ASpace>
        <ARow :gutter="16" style="margin-top: 15px">
            <ACol :span="8">
                <ACard title="Card title" :bordered="false">
                    <p>card content</p>
                </ACard>
            </ACol>
            <ACol :span="8">
                <ACard title="Card title" :bordered="false">
                    <p>card content</p>
                </ACard>
            </ACol>
            <ACol :span="8">
                <ACard title="Card title" :bordered="false">
                    <p>card content</p>
                </ACard>
            </ACol>
        </ARow>
        <WorkflowDesign ref="WorkflowDesignRef"></WorkflowDesign>
    </PageWrapper>
</template>
<script setup lang="ts" name="workflowIndex">
import { onMounted, ref } from 'vue'
import { PlusOutlined } from '@ant-design/icons-vue'
import WorkflowDesign from '@/views/developer/workflow/workflowDesign.vue'
const WorkflowDesignRef = ref()
const addTemplate = () => {
    WorkflowDesignRef.value.show()
}
onMounted(() => {})
</script>
<style scoped lang="less"></style>
