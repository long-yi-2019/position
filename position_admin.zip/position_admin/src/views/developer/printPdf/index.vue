<template>
    <PageWrapper title="在线打印（默认A3纸张大小）" sub-title="">
        <template #extra>
            <AForm
                class="padding"
                ref="myFormRef"
                name="myFormRef"
                :model="formState"
                layout="inline"
            >
                <AFormItem name="margin">
                    <ASelect v-model:value="formState.margin" :options="marginOption"></ASelect>
                </AFormItem>
                <AFormItem name="width">
                    <AInputNumber
                        v-model:value="formState.width"
                        :min="10"
                        :max="3000"
                        :formatter="(value) => `${value}mm`"
                        :parser="(value) => value.replace('mm', '')"
                    />
                </AFormItem>
                <AFormItem name="height">
                    <AInputNumber
                        v-model:value="formState.height"
                        :min="10"
                        :max="3000"
                        :formatter="(value) => `${value}mm`"
                        :parser="(value) => value.replace('mm', '')"
                    />
                </AFormItem>
                <AFormItem>
                    <AButton type="primary" @click="handleSubmit" :loading="confirmLoading">
                        导出
                    </AButton>
                </AFormItem>
            </AForm>
        </template>
        <div ref="printMain" class="container" :style="mainStyle">
            <div class="title text-center">
                标题标题标题标题标题标题标题标题标题标题标题标题标题标题标题标题标题标题标题标题标题标题标题标题标题标题标题标题标题标题标题标题标题标题标题标题标题标题标题标题标题标题标题标题标题标题标题标题标题标题标题标题标题标题标题标题标题标题标题标题标题
            </div>
        </div>
    </PageWrapper>
</template>

<script setup lang="ts" name="pringPdfIndex">
import html2Canvas from 'html2canvas'
import { changeDpiBlob } from '@/utils/changedpi.js'
import { computed, onMounted, ref, watch } from 'vue'
import { mm2PxByDpi } from '@/utils/dpi'
import { isEmpty } from '@/utils/Common'
import { cloneDeep } from 'lodash-es'
import { message } from 'ant-design-vue/es'
const printMain = ref<HTMLElement>()
const confirmLoading = ref(false)
const myFormRef = ref()
/*
 设置打印边距，单位mm
 */
const marginOption = ref([
    {
        value: 'normal', //普通
        label: '普通（上下：25.4mm，左右：31.8mm）',
        margin: [25.4, 31.8],
    },
    {
        value: 'mini', //窄
        label: '窄（上下：12.7mm，左右：12.7mm）',
        margin: [12.7, 12.7],
    },
    {
        value: 'miniPlus', //特别窄
        label: '特别窄（上下：8mm，左右：8mm）',
        margin: [8, 8],
    },
    {
        value: 'general', //适中
        label: '适中（上下：25.4mm，左右：19.1mm）',
        margin: [25.4, 19.1],
    },
    {
        value: 'large', //宽
        label: '宽（上下：25.4mm，左右：50.8mm）',
        margin: [25.4, 50.8],
    },
    {
        value: 'no', //无
        label: '无（上下：0mm，左右：0mm）',
        margin: [0, 0],
    },
])
/**
 * 打印默认参数
 * A3|(420,297)
 */
const defaultFormState = {
    width: 420,
    height: 297,
    margin: 'mini',
}
const formState = ref(cloneDeep(defaultFormState))
const dpi = 300 //默认图片dpi
const showWidth = 800 //默认宽度，页面基于这个宽度进行缩放显示
const offsetWidth = ref(0) //窗口初始化宽度
/**
 * 窗口显示缩放比例
 */
const scale = computed(() => {
    if (offsetWidth.value > 0) {
        return offsetWidth.value / showWidth
    } else {
        return 1
    }
})

/**
 * 页面默认动态样式
 */
const mainStyle = ref({
    width: '100%',
    height: '100%',
    padding: `0px,0px`,
    transform: `scale(1)`,
})
watch(
    () => [formState.value, offsetWidth.value],
    () => {
        const item = marginOption.value.filter((m) => m.value === formState.value.margin)[0]
        /**
         * 计算相对padding
         */
        const ptb =
            mm2PxByDpi(item.margin[0], dpi) / (mm2PxByDpi(formState.value.width, dpi) / showWidth)
        const plr =
            mm2PxByDpi(item.margin[1], dpi) / (mm2PxByDpi(formState.value.width, dpi) / showWidth)
        mainStyle.value = {
            width: offsetWidth.value > 0 ? showWidth + 'px' : '100%',
            height:
                offsetWidth.value > 0
                    ? showWidth * (formState.value.height / formState.value.width) + 'px'
                    : '100%',
            padding: `${ptb}px ${plr}px`,
            transform: `scale(${scale.value})`,
        }
    },
    {
        deep: true,
    },
)

const handleSubmit = () => {
    if (isEmpty(formState.value.width) || isEmpty(formState.value.height)) {
        message.error('请先设置打印宽高！')
        return
    }
    confirmLoading.value = true
    html2Canvas(printMain.value as HTMLElement, {
        allowTaint: false,
        useCORS: true, // 为解决跨域问题
        logging: false, // console中打印日志
        scale:
            mm2PxByDpi(formState.value.width, dpi) /
            (printMain.value?.offsetWidth || showWidth) /
            scale.value,
    }).then((canvas) => {
        canvas.toBlob((blob) => {
            changeDpiBlob(blob, dpi).then((blob) => {
                const href = window.URL.createObjectURL(new Blob([blob]))
                const link = document.createElement('a')
                link.href = href
                link.download = '测试图片.png'
                document.body.appendChild(link)
                link.click()
                document.body.removeChild(link)
                confirmLoading.value = false
            })
        }, 'image/png')
    })
}

onMounted(() => {
    /**
     * 初始化页面默认宽度
     */
    offsetWidth.value = printMain.value?.offsetWidth || showWidth
})
</script>

<style scoped>
.container {
    position: relative;
    overflow: hidden;
    background-color: #00cb8d;
    width: 100%;
    height: 100%;
    transform-origin: 0 0;
}

.title {
    font-size: 30px;
    font-weight: bold;
}
</style>
