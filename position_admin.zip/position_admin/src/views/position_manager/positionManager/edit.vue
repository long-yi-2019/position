<template>
    <YxModal
        ref="YxModalRef"
        :title="modalTitle"
        v-model:visible="visible"
        @ok="onSubmit"
        @cancel="onCancel"
        :submit-loading="submitLoading"
    >
        <AForm
            class="bg-white padding"
            ref="myFormRef"
            name="myFormRef"
            :model="formRef"
            :label-col="{ span: 4 }"
            :wrapper-col="{ span: 14 }"
        >
            <AFormItem label="岗位名称" name="positionName" extra="" :rules="[]">
                <AInput
                    v-model:value="formRef.positionName"
                    placeholder=""
                    show-count
                    :maxlength="50"
                ></AInput>
            </AFormItem>
            <AFormItem
                label="地图图标"
                name="mapIcon"
                ref="mapIcon"
                extra="最多上传1个且单个最大50M，图片建议像素xxx*xxxx"
                :rules="[]"
            >
                <YxUpload
                    v-model:value="formRef.mapIcon"
                    :action="action"
                    :rootUrl="rootUrl"
                    :headers="getTokenHeader"
                    :compress="0.5"
                    :max="1"
                    @change="() => $refs.mapIcon?.onFieldChange()"
                    :size="50"
                    accept=".jpg,.jpeg,.png,.doc,.docx,.xls,.xlsx,.pdf,.mp4"
                ></YxUpload>
            </AFormItem>
        </AForm>
    </YxModal>
</template>
<!--添加路由地址：/position_manager/positionManager/add，修改路由地址：/position_manager/positionManager/edit，组件地址：/position_manager/positionManager/edit-->
<script setup lang="ts">
import { FormInstance, message } from 'ant-design-vue'
import { ref } from 'vue'
import { save, edit, get } from '@/api/position_manager/positionManager'
import { cloneDeep } from 'lodash-es'
import { leftCover } from '@/utils/ObjectUtils'
/**
 * 基础数据定义
 */
const visible = ref(false)
const submitLoading = ref(false)
const modalTitle = ref('添加岗位管理')

const myFormRef = ref<FormInstance>()

const defaultForm = {
    id: null, //主键ID
    positionName: '', //岗位名称
    mapIcon: [], //地图图标
}
const formRef = ref<any>({ ...defaultForm })
import { getTokenHeader } from '@/utils/tokenUtil'
const action = import.meta.env.VITE_API_URL_UPLOAD
const rootUrl = import.meta.env.VITE_API_URL_STATIC

/**
 * 显示弹窗
 */
const show = (params?: any) => {
    params = params || {}
    visible.value = true
    /**
     * 初始参数
     */
    formRef.value = Object.assign({}, { ...defaultForm })
    leftCover(formRef.value, params || {})

    if (params.id) {
        modalTitle.value = '编辑岗位管理'
        get({ id: params.id }).then((res: any) => {
            const data = res.data
            leftCover(formRef.value, data)
        })
    }
}
defineExpose({ show })

/**
 * 接收方法
 */
const emits = defineEmits(['ok'])
/**
 * 提交方法
 */
const onSubmit = () => {
    myFormRef.value?.validate().then(() => {
        submitLoading.value = true
        const params = cloneDeep(formRef.value)
        for (let k in params) {
            if (typeof params[k] === 'object') {
                if (params[k]) {
                    params[k] = JSON.stringify(params[k])
                }
            }
        }
        if (params.id) {
            edit(params).then((res: any) => {
                if (res.code === 1) {
                    emits('ok')
                    message.success('提交成功')
                    onCancel()
                }
                submitLoading.value = false
            })
        } else {
            save(params).then((res: any) => {
                if (res.code === 1) {
                    emits('ok')
                    message.success('提交成功')
                    onCancel()
                }
                submitLoading.value = false
            })
        }
    })
}
/**
 * 关闭弹窗
 */
const onCancel = () => {
    myFormRef.value?.resetFields()
    visible.value = false
}
</script>

<style scoped lang="less"></style>
