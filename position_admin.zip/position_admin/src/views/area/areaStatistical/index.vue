<template>
    <PageWrapper title="统计区域" sub-title="">
        <MyTablePage
            ref="MyTablePageRef"
            :search-item="searchItem"
            :url="dataUrl"
            :columns="columns"
            :action="action"
            :ellipsis="1"
            show-index
            pagination
            selection="checkbox"
        >
            <template #tools>
                <AButton v-permission="'areaStatisticalAdd'" type="primary" @click="handelAdd">
                    <template #icon>
                        <PlusOutlined />
                    </template>
                    添加
                </AButton>
                <AButton v-permission="'areaStatisticalDelete'" type="danger" @click="deletes()">
                    <template #icon>
                        <DeleteOutlined />
                    </template>
                    批量删除
                </AButton>
                <AButton
                    v-permission="'areaStatisticalExport'"
                    type="success"
                    @click="MyTablePageRef.handleExport('统计区域')"
                >
                    <template #icon>
                        <DownloadOutlined />
                    </template>
                    导出
                </AButton>
            </template>
        </MyTablePage>
        <Edit ref="EditRef" @ok="MyTablePageRef.search()"></Edit>
    </PageWrapper>
</template>
<!--路由地址：/area/areaStatistical/index ,组件名称：areaStatisticalIndex	-->
<script setup lang="ts" name="areaStatisticalIndex">
import { onMounted, ref } from 'vue'
import { DeleteOutlined, PlusOutlined, DownloadOutlined } from '@ant-design/icons-vue'
import { message, Modal } from 'ant-design-vue'
import { cloneDeep } from 'lodash-es'
import { del } from '@/api/area/areaStatistical'
import Edit from './edit.vue'
const EditRef = ref()

const MyTablePageRef = ref()
const dataUrl = `${import.meta.env.VITE_API_URL_SYSTEM}/v1/area/statistical/getList`

/*列配置 api https://itvita.gitee.io/liuyunxi-antd-extend/#/YxTable*/
const columns = ref<any[]>([
    {
        title: '区域名称',
        dataIndex: 'areaName',
        hidden: false,
        sorter: true,
        width: 200,
    },
    {
        title: '区域ID',
        dataIndex: 'areaId',
        hidden: false,
        sorter: true,
        width: 200,
    },
    {
        title: '负责人',
        dataIndex: 'responsePerson',
        hidden: false,
        sorter: true,
        width: 200,
    },
    {
        title: '联系方式',
        dataIndex: 'phoneNumber',
        hidden: false,
        sorter: true,
        width: 200,
    },
    {
        title: '关联对象',
        dataIndex: 'relationPerson',
        hidden: false,
        sorter: true,
        width: 200,
    },
    {
        title: '坐标数据',
        dataIndex: 'mapData',
        hidden: true,
        sorter: true,
        width: 200,
    },
])
/*搜索条配置 api https://itvita.gitee.io/liuyunxi-antd-extend/#/YxSearch*/
const searchItem = ref<any[]>([
    {
        type: 'text',
        key: 'areaName',
        label: '区域名称',
        value: '',
        placeholder: '',
    },
])
/**
 * 批量删除方法
 * @param ids id数组
 */
const deletes = (ids?: string[]) => {
    if (ids === undefined) {
        const { selectedRowKeys } = MyTablePageRef.value.getSelection()
        ids = cloneDeep(selectedRowKeys)
    }
    if (!ids || ids?.length < 1) {
        Modal.warning({
            title: '请先选择删除项',
        })
        return
    }
    Modal.confirm({
        title: '确定删除？',
        content: '删除后将无法恢复',
        okType: 'danger',
        onOk() {
            del(ids).then((res: any) => {
                if (res.code === 1) {
                    message.success('删除成功')
                    MyTablePageRef.value.search()
                }
            })
        },
    })
}
/*table 操作列配置*/
const action = ref({
    width: 200,
    fixed: 'right',
    buttons: [
        {
            title: '详情',
            icon: 'iconfont icon-caidan',
            event: (row: any) => {
                MyTablePageRef.value.showDetail(row)
            },
        },
        {
            title: '编辑',
            icon: 'iconfont icon-bianji',
            permission: 'areaStatisticalEdit',
            event: (row: any) => {
                EditRef.value.show({ id: row.id })
            },
        },
        {
            title: '删除',
            color: '#f12424', // primary,success,warn,danger,info
            icon: 'iconfont icon-shanchu',
            permission: 'areaStatisticalDelete',
            event: (row: any) => {
                deletes([row.id])
            },
        },
    ],
})

/**
 * 添加
 */
const handelAdd = () => {
    EditRef.value.show()
}

/**
 * 挂载，页面初始化后执行
 */
onMounted(() => {
    MyTablePageRef.value.search()
})
</script>

<style scoped lang="less"></style>
