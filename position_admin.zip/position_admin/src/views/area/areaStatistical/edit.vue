<template>
    <YxModal
        ref="YxModalRef"
        :title="modalTitle"
        v-model:visible="visible"
        @ok="onSubmit"
        @cancel="onCancel"
        :submit-loading="submitLoading"
    >
        <AForm
            class="bg-white padding"
            ref="myFormRef"
            name="myFormRef"
            :model="formRef"
            :label-col="{ span: 4 }"
            :wrapper-col="{ span: 14 }"
        >
            <AFormItem
                label="区域名称"
                name="areaName"
                extra=""
                :rules="[{ required: true, message: '区域名称不能为空', trigger: 'blur' }]"
            >
                <AInput
                    v-model:value="formRef.areaName"
                    placeholder=""
                    show-count
                    :maxlength="50"
                ></AInput>
            </AFormItem>
            <AFormItem
                label="区域ID"
                name="areaId"
                extra=""
                :rules="[{ required: true, message: '区域ID不能为空', trigger: 'blur' }]"
            >
                <AInput
                    v-model:value="formRef.areaId"
                    placeholder=""
                    show-count
                    :maxlength="50"
                ></AInput>
            </AFormItem>
            <AFormItem
                label="负责人"
                name="responsePerson"
                extra=""
                :rules="[{ required: true, message: '负责人不能为空', trigger: 'blur' }]"
            >
                <AInput
                    v-model:value="formRef.responsePerson"
                    placeholder=""
                    show-count
                    :maxlength="50"
                ></AInput>
            </AFormItem>
            <AFormItem
                label="联系方式"
                name="phoneNumber"
                extra=""
                :rules="[{ required: true, message: '联系方式不能为空', trigger: 'blur' }]"
            >
                <AInput
                    v-model:value="formRef.phoneNumber"
                    placeholder=""
                    show-count
                    :maxlength="50"
                ></AInput>
            </AFormItem>
            <AFormItem
                label="关联对象"
                name="relationPerson"
                extra=""
                :rules="[{ required: true, message: '关联对象不能为空', trigger: 'blur' }]"
            >
                <!--tree-default-expand-all-->
                <ATreeSelect
                    v-model:value="formRef.relationPerson"
                    v-model:searchValue="relationPersonSearchValue"
                    show-search
                    style="width: 100%"
                    treeNodeFilterProp="title"
                    :dropdown-style="{ maxHeight: '400px', overflow: 'auto' }"
                    placeholder=""
                    allow-clear
                    :tree-data="relationPersonOptions"
                    :fieldNames="{
                        children: 'children',
                        label: 'title',
                        key: 'id',
                        value: 'id',
                    }"
                >
                    <template #title="{ title }">
                        <template
                            v-for="(fragment, i) in (title || '')
                                .toString()
                                .split(
                                    new RegExp(
                                        `(?<=${relationPersonSearchValue})|(?=${relationPersonSearchValue})`,
                                        'i',
                                    ),
                                )"
                        >
                            <span
                                v-if="
                                    fragment.toLowerCase() ===
                                    relationPersonSearchValue.toLowerCase()
                                "
                                :key="i"
                                style="color: #08c"
                            >
                                {{ fragment }}
                            </span>
                            <template v-else>{{ fragment }}</template>
                        </template>
                    </template>
                </ATreeSelect>
            </AFormItem>
        </AForm>
    </YxModal>
</template>
<!--添加路由地址：/area/areaStatistical/add，修改路由地址：/area/areaStatistical/edit，组件地址：/area/areaStatistical/edit-->
<script setup lang="ts">
import { FormInstance, message } from 'ant-design-vue'
import { ref } from 'vue'
import { save, edit, get } from '@/api/area/areaStatistical'
import { cloneDeep } from 'lodash-es'
import { leftCover } from '@/utils/ObjectUtils'
/**
 * 基础数据定义
 */
const visible = ref(false)
const submitLoading = ref(false)
const modalTitle = ref('添加统计区域')

const myFormRef = ref<FormInstance>()

const defaultForm = {
    id: null, //主键ID
    areaName: '', //区域名称
    areaId: '', //区域ID
    responsePerson: '', //负责人
    phoneNumber: '', //联系方式
    relationPerson: '', //关联对象
}
const formRef = ref<any>({ ...defaultForm })

/**
 * 关联对象选项
 */
/**
 * 树形下拉搜索值
 */
const relationPersonSearchValue = ref('')

/**
 * 显示弹窗
 */
const show = (params?: any) => {
    params = params || {}
    visible.value = true
    /**
     * 初始参数
     */
    formRef.value = Object.assign({}, { ...defaultForm })
    leftCover(formRef.value, params || {})

    if (params.id) {
        modalTitle.value = '编辑统计区域'
        get({ id: params.id }).then((res: any) => {
            const data = res.data
            leftCover(formRef.value, data)
        })
    }
}
defineExpose({ show })

/**
 * 接收方法
 */
const emits = defineEmits(['ok'])
/**
 * 提交方法
 */
const onSubmit = () => {
    myFormRef.value?.validate().then(() => {
        submitLoading.value = true
        const params = cloneDeep(formRef.value)
        for (let k in params) {
            if (typeof params[k] === 'object') {
                if (params[k]) {
                    params[k] = JSON.stringify(params[k])
                }
            }
        }
        if (params.id) {
            edit(params).then((res: any) => {
                if (res.code === 1) {
                    emits('ok')
                    message.success('提交成功')
                    onCancel()
                }
                submitLoading.value = false
            })
        } else {
            save(params).then((res: any) => {
                if (res.code === 1) {
                    emits('ok')
                    message.success('提交成功')
                    onCancel()
                }
                submitLoading.value = false
            })
        }
    })
}
/**
 * 关闭弹窗
 */
const onCancel = () => {
    myFormRef.value?.resetFields()
    visible.value = false
}
</script>

<style scoped lang="less"></style>
