<template>
    <YxModal
        ref="YxModalRef"
        :title="modalTitle"
        v-model:visible="visible"
        @ok="onSubmit"
        @cancel="onCancel"
        :submit-loading="submitLoading"
        style="height: 100%"
    >
        <AForm
            class="bg-white padding"
            ref="myFormRef"
            name="myFormRef"
            :model="formRef"
            :label-col="{ span: 4 }"
            :wrapper-col="{ span: 14 }"
        >
            <AFormItem
                label="风险区名称"
                name="riskArea"
                extra=""
                :rules="[{ required: true, message: '请输入风险区名称', trigger: 'blur' }]"
            >
                <AInput
                    v-model:value="formRef.riskArea"
                    placeholder=""
                    show-count
                    :maxlength="50"
                ></AInput>
            </AFormItem>
            <AFormItem
                label="风险等级"
                name="riskLevel"
                extra=""
                :rules="[{ required: true, message: '请选择风险等级', trigger: 'blur' }]"
            >
                <ASelect
                    v-model:value="formRef.riskLevel"
                    show-search
                    placeholder=""
                    :options="riskLevelOptions"
                    :filter-option="filterOption"
                ></ASelect>
            </AFormItem>
            <AFormItem
                label="区域ID"
                name="areaId"
                extra=""
                :rules="[{ required: true, message: '请输入区域ID', trigger: 'blur' }]"
            >
                <AInput
                    v-model:value="formRef.areaId"
                    placeholder=""
                    show-count
                    :maxlength="50"
                ></AInput>
            </AFormItem>
            <AFormItem
                label="负责人"
                name="personInCharge"
                extra=""
                :rules="[{ required: true, message: '请输入负责人', trigger: 'blur' }]"
            >
                <AInput
                    v-model:value="formRef.personInCharge"
                    placeholder=""
                    show-count
                    :maxlength="50"
                ></AInput>
            </AFormItem>
            <AFormItem
                label="联系方式"
                name="personChargeNumber"
                extra=""
                :rules="[{ required: true, message: '请输入联系方式', trigger: 'blur' }]"
            >
                <AInput
                    v-model:value="formRef.personChargeNumber"
                    placeholder=""
                    show-count
                    :maxlength="50"
                ></AInput>
            </AFormItem>
            <AFormItem
                label="适用于同栋全部楼层"
                name="useAllFloor"
                extra=""
                :rules="[{ required: true, message: '请选择适用于同栋全部楼层', trigger: 'blur' }]"
            >
                <ARadioGroup
                    placeholder=""
                    v-model:value="formRef.useAllFloor"
                    :options="useAllFloorOptions"
                />
            </AFormItem>
            <!--          这里还需要做一下地图坐标点的回传-->
            <AFormItem label="地图位置" name="mapPosition" extra="">
                <OpenLayersMap v-model:value="formRef.coordinates"> </OpenLayersMap>
            </AFormItem>
        </AForm>
    </YxModal>
</template>
<!--添加路由地址：/risk_area/riskAreaManager/add，修改路由地址：/risk_area/riskAreaManager/edit，组件地址：/risk_area/riskAreaManager/edit-->
<script setup lang="ts">
import { FormInstance, message } from 'ant-design-vue'
import { ref } from 'vue'
import { save, edit, get } from '@/api/risk_area/riskAreaManager'
import { cloneDeep } from 'lodash-es'
import { leftCover } from '@/utils/ObjectUtils'
import OpenLayersMap from '@/components/openlayer.vue'

/**
 * 基础数据定义
 */
const visible = ref(false)
const submitLoading = ref(false)
const modalTitle = ref('添加风险区域管理')

const myFormRef = ref<FormInstance>()

const defaultForm = {
    id: null, //主键ID
    riskArea: '', //风险区名称
    riskLevel: '', //风险等级
    areaId: '', //区域ID
    personInCharge: '', //负责人
    personChargeNumber: '', //联系方式
    useAllFloor: '', //适用于同栋全部楼层
    coordinates: [],
}
const formRef = ref<any>({ ...defaultForm })

/**
 * 风险等级选项
 */
const riskLevelOptions = [
    { label: '重大风险', value: 'high' },
    { label: '较大风险', value: 'middle' },
    { label: '一般风险', value: 'normal' },
    { label: '低风险', value: 'low' },
]
/**
 * 下拉搜索
 * @param input
 * @param option
 */
const filterOption = (input: string, option: any) => {
    return option.label.toLowerCase().indexOf(input.toLowerCase()) >= 0
}

/**
 * 适用于同栋全部楼层选项
 */
const useAllFloorOptions = [
    { label: '是', value: '1' },
    { label: '否', value: '0' },
]
/**
 * 显示弹窗
 */
const show = (params?: any) => {
    params = params || {}
    visible.value = true
    /**
     * 初始参数
     */
    formRef.value = Object.assign({}, { ...defaultForm })
    leftCover(formRef.value, params || {})

    if (params.id) {
        modalTitle.value = '编辑风险区域管理'
        get({ id: params.id }).then((res: any) => {
            const data = res.data
            leftCover(formRef.value, data)
        })
    }
}
defineExpose({ show })

/**
 * 接收方法
 */
const emits = defineEmits(['ok'])
/**
 * 提交方法
 */
const onSubmit = () => {
    myFormRef.value?.validate().then(() => {
        console.log(formRef.value)
        submitLoading.value = true
        const params = cloneDeep(formRef.value)
        for (let k in params) {
            if (typeof params[k] === 'object') {
                if (params[k]) {
                    params[k] = JSON.stringify(params[k])
                }
            }
        }
        if (params.id) {
            edit(params).then((res: any) => {
                if (res.code === 1) {
                    emits('ok')
                    message.success('提交成功')
                    onCancel()
                }
                submitLoading.value = false
            })
        } else {
            save(params).then((res: any) => {
                if (res.code === 1) {
                    emits('ok')
                    message.success('提交成功')
                    onCancel()
                }
                submitLoading.value = false
            })
        }
    })
}
/**
 * 关闭弹窗
 */
const onCancel = () => {
    myFormRef.value?.resetFields()
    visible.value = false
}
</script>

<style scoped lang="less"></style>
