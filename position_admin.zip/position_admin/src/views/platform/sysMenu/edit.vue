<template>
    <YxModal
        ref="YxModalRef"
        :title="modalTitle"
        v-model:visible="visible"
        @ok="onSubmit"
        @cancel="onCancel"
        :submit-loading="submitLoading"
    >
        <AForm
            class="padding"
            ref="myFormRef"
            name="myFormRef"
            :model="formRef"
            :label-col="{ span: 4 }"
            :wrapper-col="{ span: 14 }"
        >
            <AFormItem label="上级菜单" name="parentId" :rules="[]">
                <ATreeSelect
                    v-model:value="formRef.parentId"
                    v-model:searchValue="parentIdSearchValue"
                    :disabled="isNotEmpty(formRef.id)"
                    show-search
                    style="width: 100%"
                    treeNodeFilterProp="title"
                    :dropdown-style="{ maxHeight: '400px', overflow: 'auto' }"
                    placeholder=""
                    allow-clear
                    tree-default-expand-all
                    :tree-data="parentIdOptions"
                    :fieldNames="{
                        children: 'children',
                        label: 'title',
                        key: 'id',
                        value: 'id',
                    }"
                >
                    <template #title="{ title }">
                        <template
                            v-for="(fragment, i) in (title || '')
                                .toString()
                                .split(
                                    new RegExp(
                                        `(?<=${parentIdSearchValue})|(?=${parentIdSearchValue})`,
                                        'i',
                                    ),
                                )"
                        >
                            <span
                                v-if="fragment.toLowerCase() === parentIdSearchValue.toLowerCase()"
                                :key="i"
                                style="color: #08c"
                            >
                                {{ fragment }}
                            </span>
                            <template v-else>{{ fragment }}</template>
                        </template>
                    </template>
                </ATreeSelect>
            </AFormItem>

            <AFormItem
                label="菜单类型"
                name="menuType"
                :rules="[{ required: true, message: '请选择菜单类型' }]"
            >
                <ARadioGroup v-model:value="formRef.menuType" :options="menuTypeOptions" />
            </AFormItem>

            <AFormItem
                label="菜单名称"
                name="title"
                :rules="[{ required: true, message: '请输入菜单名称' }]"
            >
                <AInput v-model:value="formRef.title"></AInput>
            </AFormItem>

            <AFormItem
                v-if="formRef.menuType !== '1'"
                :label="formRef.menuType === '2' ? '组件名称' : '权限标识'"
                extra="操作表名+业务名（Index,Add,Edit,Delete,Export,Import...）驼峰命名"
                name="authIdent"
                :rules="[
                    {
                        required: true,
                        message: '请输入' + formRef.menuType === '2' ? '组件名称' : '权限标识',
                    },
                ]"
            >
                <AInput v-model:value="formRef.authIdent"></AInput>
            </AFormItem>

            <AFormItem
                v-if="formRef.menuType === '2'"
                label="路由地址"
                name="routeAddress"
                :rules="[{ required: formRef.menuType === '2', message: '请输入路由地址' }]"
            >
                <AInput v-model:value="formRef.routeAddress"></AInput>
            </AFormItem>

            <AFormItem label="组件路径" v-if="formRef.menuType === '2'" extra="默认等同路由地址">
                <AInput v-model:value="formRef.componentView"></AInput>
            </AFormItem>

            <!--        <AFormItem label="路由参数" v-if="formRef.menuType === '2'">-->
            <!--            <ATextarea v-model:value="formRef.routeParam" placeholder="{xxx:xx,...}" :rows="3" />-->
            <!--        </AFormItem>-->

            <AFormItem label="菜单图标" v-if="formRef.menuType !== '3'">
                <IconSelector v-model:value="formRef.icons"></IconSelector>
            </AFormItem>

            <AFormItem
                label="顺序号"
                name="seq"
                :rules="[{ required: true, message: '请输入顺序号' }]"
            >
                <AInputNumber v-model:value="formRef.seq" :min="1" :max="99999999" />
            </AFormItem>

            <!--            <AFormItem-->
            <!--                v-if="formRef.menuType === '2'"-->
            <!--                label="是否缓存"-->
            <!--                name="keepAlive"-->
            <!--                :rules="[{ required: true, message: '请选择是否缓存' }]"-->
            <!--            >-->
            <!--                <ARadioGroup v-model:value="formRef.keepAlive" :options="keepAliveOptions" />-->
            <!--            </AFormItem>-->

            <AFormItem
                v-if="formRef.menuType === '2'"
                label="显示状态"
                name="showState"
                :rules="[{ required: true, message: '请选择显示状态' }]"
            >
                <ARadioGroup v-model:value="formRef.showState" :options="showStateOptions" />
            </AFormItem>

            <AFormItem
                v-if="formRef.menuType !== '3'"
                label="菜单状态"
                name="state"
                :rules="[{ required: true, message: '请选择菜单状态' }]"
            >
                <ARadioGroup v-model:value="formRef.state" :options="stateOptions" />
            </AFormItem>
        </AForm>
    </YxModal>
</template>

<script setup lang="ts">
import { message } from 'ant-design-vue'
import IconSelector from '@/components/Icon/IconSelector.vue'
import { ref } from 'vue'
import { save, edit, get } from '@/api/platform/sysMenu'
import { leftCover } from '@/utils/ObjectUtils'

/**
 * 基础数据定义
 */
const visible = ref(false)
const submitLoading = ref(false)
const modalTitle = ref('添加菜单')

const myFormRef = ref<any>()
// const myFormRef = ref<FormInstance>()
const defaultForm = {
    id: null, //主键ID
    parentId: '0', //父ID
    parentName: '跟菜单', //父名称
    title: null, //菜单名称
    menuType: '1', //菜单类型;1目录，2菜单，3按钮
    routeAddress: null, //路由地址
    routeParam: null, //路由参数
    componentView: null, //组件地址
    authIdent: null, //身份识别码
    icons: null, //图标
    keepAlive: '0', //是否缓存
    showState: '1', //显示状态
    state: '1', //菜单状态
    seq: '30', //顺序号
}
const formRef = ref<any>({ ...defaultForm })

const menuTypeOptions = ref([
    { label: '目录', value: '1' },
    { label: '菜单', value: '2' },
    { label: '按钮', value: '3' },
])
const showStateOptions = ref([
    { label: '显示', value: '1' },
    { label: '隐藏', value: '0' },
])
const stateOptions = ref([
    { label: '启用', value: '1' },
    { label: '禁用', value: '0' },
])
// const keepAliveOptions = ref([
//     { label: '开启缓存', value: '1' },
//     { label: '关闭缓存', value: '0' },
// ])

/**
 * 上级ID选项
 */
import { getList } from '@/api/common'
import { isNotEmpty } from '@/utils/ValidateUtils'
const parentIdOptions = ref([])
/**
 * 树形下拉搜索值
 */
const parentIdSearchValue = ref('')
/**
 * 显示弹窗
 */
const show = (params?: any) => {
    params = params || {}
    visible.value = true
    /**
     * 初始参数
     */
    formRef.value = Object.assign({}, { ...defaultForm })
    leftCover(formRef.value, params || {})

    if (params.id) {
        modalTitle.value = '编辑菜单'
        get({ id: params.id }).then((res) => {
            leftCover(formRef.value, res.data)
            formRef.value.menuType += ''
            formRef.value.keepAlive += ''
            formRef.value.showState += ''
            formRef.value.state += ''
        })
    }

    /**查询上级ID数据*/
    getList(`${import.meta.env.VITE_API_URL_SYSTEM}/v1/sys/menu/getTree`, {}).then((res) => {
        if (res.code === 1) {
            parentIdOptions.value = res.data
        }
    })
}
defineExpose({ show })

/**
 * 接收方法
 */
const emits = defineEmits(['ok'])
const onSubmit = () => {
    myFormRef.value.validate().then(() => {
        submitLoading.value = true
        if (formRef.value.id) {
            edit(formRef.value).then((res) => {
                if (res.code === 1) {
                    emits('ok')
                    message.success('提交成功')
                    onCancel()
                }
                submitLoading.value = false
            })
        } else {
            save(formRef.value).then((res) => {
                if (res.code === 1) {
                    emits('ok')
                    message.success('提交成功')
                    onCancel()
                }
                submitLoading.value = false
            })
        }
    })
}
/**
 * 关闭弹窗
 */
const onCancel = () => {
    myFormRef.value?.resetFields()
    visible.value = false
}
</script>

<style scoped lang="less"></style>
