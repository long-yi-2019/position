<template>
    <PageWrapper title="菜单管理" sub-title="通过配置生成代码，有效节省撸码时间">
        <MyTreeTablePage
            ref="MyTreeTablePageRef"
            :search-item="searchItem"
            :url="dataUrl"
            :columns="columns"
            :action="action"
            :ellipsis="1"
            pagination
            :tree="treeConfig"
        >
            <template #tools>
                <AButton type="primary" @click="goAdd()">
                    <template #icon>
                        <PlusOutlined />
                    </template>
                    添加
                </AButton>
            </template>
        </MyTreeTablePage>
        <Edit ref="EditRef" @ok="MyTreeTablePageRef.init()"></Edit>
    </PageWrapper>
</template>

<script setup lang="ts" name="sysMenuIndex">
import { PlusOutlined } from '@ant-design/icons-vue'
import { onMounted, reactive, ref } from 'vue'
import { del, move } from '@/api/platform/sysMenu'
import { message, Modal } from 'ant-design-vue'
import Edit from './edit.vue'
const EditRef = ref()
const MyTreeTablePageRef = ref()
const dataUrl = `${import.meta.env.VITE_API_URL_SYSTEM}/v1/sys/menu/getList`
const selectNode = ref({
    id: '0',
    name: '跟目录',
})

/**
 * 添加
 * @param treeNode
 */
const handelAdd = (treeNode?: any) => {
    if (treeNode) {
        selectNode.value = treeNode
    }
    EditRef.value.show({
        parentId: selectNode.value.id,
        parentName: selectNode.value.name,
    })
}

/**
 * 编辑
 * @param id 选中ID
 */
const handelEdit = ({ id }: { id: string }) => {
    EditRef.value.show({ id: id })
}

const actionDelete = (params: { id: string }) => {
    Modal.confirm({
        title: '确定删除？',
        content: '删除后将无法恢复',
        okType: 'danger',
        onOk() {
            del([params.id]).then((res) => {
                if (res.code === 1) {
                    message.success('删除成功').then()
                    MyTreeTablePageRef.value.search()
                    MyTreeTablePageRef.value.initTree()
                }
            })
        },
    })
}
/**
 * 树形配置
 */
const treeConfig = reactive({
    url: `${import.meta.env.VITE_API_URL_SYSTEM}/v1/sys/menu/getZtree`,
    drag: true,
    add: true,
    edit: true,
    remove: true,
    handelClick: (treeNodes: any) => {
        selectNode.value = treeNodes
        MyTreeTablePageRef.value.search()
    },
    handelAdd: handelAdd,
    handelRemove: (treeNodes: any) => {
        actionDelete({ id: treeNodes.id })
    },
    handelEdit: (treeNodes: any) => {
        handelEdit({ id: treeNodes.id })
    },
    handelDrop: (treeNodes: any[], targetNode: any, moveType: string) => {
        console.log(moveType)
        if (moveType) {
            move({ moveType: moveType, dragId: treeNodes[0].id, targetId: targetNode.id }).then()
        }
    },
})

const columns = ref([
    {
        title: '顺序号',
        dataIndex: 'seq',
        align: 'center',
    },
    {
        title: '菜单名称',
        dataIndex: 'title',
    },
    {
        title: '识别码',
        dataIndex: 'authIdent',
    },
    {
        title: '类型',
        dataIndex: 'menuType',
        align: 'center',
        formatter: {
            type: 'tag',
            format: (row: any): any => {
                if (row.menuType === 1) {
                    return {
                        value: `目录`,
                        color: 'blue', // css 颜色代码 blue,green,red,#xxx...
                    }
                } else if (row.menuType === 2) {
                    return {
                        value: `菜单`,
                        color: 'green', // css 颜色代码 blue,green,red,#xxx...
                    }
                } else if (row.menuType === 3) {
                    return {
                        value: `按钮`,
                        color: 'orange', // css 颜色代码 blue,green,red,#xxx...
                    }
                }
            },
        },
    },
    {
        title: '路由地址',
        dataIndex: 'routeAddress',
        align: 'left',
    },
    {
        title: '路由参数',
        dataIndex: 'routeParam',
        hidden: true,
    },
    {
        title: '组件地址',
        dataIndex: 'componentView',
        hidden: true,
    },
    {
        title: '图标',
        hidden: false,
        dataIndex: 'icons',
    },
    {
        title: '显示状态',
        dataIndex: 'showState',
        formatter: {
            type: 'text',
            format: (row: any): any => {
                if (row.showState === 1) {
                    return {
                        value: `显示`,
                        color: 'blue', // css 颜色代码 blue,green,red,#xxx...
                    }
                } else {
                    return {
                        value: `隐藏`,
                        color: 'gray', // css 颜色代码 blue,green,red,#xxx...
                    }
                }
            },
        },
    },
    {
        title: '菜单状态',
        dataIndex: 'state',
        formatter: {
            type: 'text',
            format: (row: any): any => {
                if (row.state === 1) {
                    return {
                        value: `启用`,
                        color: 'blue', // css 颜色代码 blue,green,red,#xxx...
                    }
                } else {
                    return {
                        value: `禁用`,
                        color: 'red', // css 颜色代码 blue,green,red,#xxx...
                    }
                }
            },
        },
    },
    {
        title: '是否缓存',
        dataIndex: 'keepAlive',
        hidden: true,
        formatter: {
            type: 'text',
            format: (row: any): any => {
                if (row.keepAlive === 1) {
                    return {
                        value: `缓存`,
                        color: 'blue', // css 颜色代码 blue,green,red,#xxx...
                    }
                } else {
                    return {
                        value: `不缓存 `,
                        color: 'gray', // css 颜色代码 blue,green,red,#xxx...
                    }
                }
            },
        },
    },
])
const action = ref({
    width: 200,
    fixed: 'right',
    buttons: [
        {
            title: '详情',
            icon: 'iconfont icon-caidan',
            event: (row: any) => {
                MyTreeTablePageRef.value.showDetail(row)
            },
        },
        {
            title: '编辑',
            icon: 'iconfont icon-bianji',
            event: (row: any) => {
                handelEdit({ id: row.id })
            },
        },
        {
            title: '删除',
            color: '#f12424', // primary,success,warn,danger,info
            icon: 'iconfont icon-shanchu',
            event: (row: any) => {
                actionDelete({ id: row.id })
            },
        },
    ],
})
const searchItem = ref([
    {
        type: 'text',
        key: 'title',
        label: '菜单名称',
        value: '',
        placeholder: '',
    },
])

const goAdd = () => {
    handelAdd(selectNode.value)
}

onMounted(() => {
    MyTreeTablePageRef.value.init({})
})
</script>

<style scoped lang="less"></style>
