<template>
    <PageWrapper title="租户信息表" sub-title="">
        <MyTablePage
            ref="MyTablePageRef"
            :search-item="searchItem"
            :url="dataUrl"
            :columns="columns"
            :action="action"
            :ellipsis="1"
            show-index
            pagination
            selection="checkbox"
        >
            <template #tools>
                <AButton v-permission="'sysTenantAdd'" type="primary" @click="handelAdd">
                    <template #icon>
                        <PlusOutlined />
                    </template>
                    添加
                </AButton>
                <AButton v-permission="'sysTenantDelete'" type="danger" @click="deletes()">
                    <template #icon>
                        <DeleteOutlined />
                    </template>
                    批量删除
                </AButton>
                <AButton
                    v-permission="'sysTenantExport'"
                    type="success"
                    @click="MyTablePageRef.handleExport('租户信息表')"
                >
                    <template #icon>
                        <DownloadOutlined />
                    </template>
                    导出
                </AButton>
            </template>
        </MyTablePage>
        <Edit ref="EditRef" @ok="MyTablePageRef.search()"></Edit>
    </PageWrapper>
</template>
<!--路由地址：/system/sysTenant/index ,组件名称：sysTenantIndex	-->
<script setup lang="ts" name="sysTenantIndex">
import { onMounted, ref } from 'vue'
import { DeleteOutlined, PlusOutlined, DownloadOutlined } from '@ant-design/icons-vue'
import { message, Modal } from 'ant-design-vue'
import { cloneDeep } from 'lodash-es'
import { del, edit } from '@/api/platform/sysTenant'
import Edit from './edit.vue'

const EditRef = ref()

const MyTablePageRef = ref()
const dataUrl = `${import.meta.env.VITE_API_URL_SYSTEM}/v1/sys/tenant/getList`

/*列配置 api https://itvita.gitee.io/liuyunxi-antd-extend/#/YxTable*/
const columns = ref<any[]>([
    {
        title: '学校编码',
        dataIndex: 'tenantCode',
        hidden: false,
    },
    {
        title: '学校名称',
        dataIndex: 'name',
        hidden: false,
    },
    {
        title: '联系人',
        dataIndex: 'contactPerson',
        hidden: false,
    },
    {
        title: '联系手机',
        align: 'center',
        dataIndex: 'contactNumber',
        hidden: false,
    },
    {
        title: '套餐',
        dataIndex: 'packageList',
        hidden: false,
        formatter: {
            type: 'text',
            format: (row: any) => {
                const list = row.packageList || []
                let packageNames = list.map((v: any) => v.name)
                return {
                    value: packageNames.join(','),
                }
            },
        },
    },
    {
        title: '超级管理员',
        dataIndex: 'userInfo',
        width: 200,
        hidden: true,
        formatter: {
            type: 'text',
            format: (row: any) => {
                if (row.userInfo) {
                    return {
                        value: [row.userInfo.accountName, row.userInfo.loginPass].join('/'),
                    }
                } else {
                    return ''
                }
            },
        },
    },
    {
        title: '介绍',
        dataIndex: 'remark',
        hidden: true,
    },
    {
        title: '过期时间',
        align: 'center',
        dataIndex: 'expirationTime',
        hidden: false,
    },
    {
        title: '状态',
        dataIndex: 'state',
        align: 'center',
        hidden: false,
        formatter: {
            type: 'tag',
            format: (row: any) => {
                if (row.state === '1') {
                    return {
                        value: '启用',
                        color: '#1890ff',
                    }
                } else {
                    return {
                        value: '禁用',
                        color: '#fa541c',
                    }
                }
            },
        },
    },
])
/*搜索条配置 api https://itvita.gitee.io/liuyunxi-antd-extend/#/YxSearch*/
const searchItem = ref<any[]>([
    {
        type: 'text',
        key: 'tenantCode',
        label: '学校编码',
        value: '',
        placeholder: '',
    },
    {
        type: 'text',
        key: 'name',
        label: '学校名称',
        value: '',
        placeholder: '',
    },
    {
        type: 'select',
        key: 'state',
        label: '状态',
        value: '',
        placeholder: '',

        options: [
            { label: '启用', value: '1' },
            { label: '禁用', value: '0' },
        ],
    },
])
/**
 * 批量删除方法
 * @param ids id数组
 */
const deletes = (ids?: string[]) => {
    if (ids === undefined) {
        const { selectedRowKeys } = MyTablePageRef.value.getSelection()
        ids = cloneDeep(selectedRowKeys)
    }
    if (!ids || ids?.length < 1) {
        Modal.warning({
            title: '请先选择删除项',
        })
        return
    }
    Modal.confirm({
        title: '确定删除？',
        content: '删除后将无法恢复',
        okType: 'danger',
        onOk() {
            del(ids).then((res: any) => {
                if (res.code === 1) {
                    message.success('删除成功')
                    MyTablePageRef.value.search()
                }
            })
        },
    })
}
/*table 操作列配置*/
const action = ref({
    width: 220,
    fixed: 'right',
    buttons: [
        {
            title: '详情',
            icon: 'iconfont icon-caidan',
            event: (row: any) => {
                MyTablePageRef.value.showDetail(row)
            },
        },
        {
            title: '编辑',
            icon: 'iconfont icon-bianji',
            permission: 'sysTenantEdit',
            event: (row: any) => {
                EditRef.value.show({ id: row.id })
            },
        },
        {
            title: '删除',
            color: '#f12424', // primary,success,warn,danger,info
            icon: 'iconfont icon-shanchu',
            permission: 'sysTenantDelete',
            event: (row: any) => {
                deletes([row.id])
            },
        },

        {
            title: '启用',
            color: 'primary', // primary,success,warn,danger,info
            icon: 'iconfont icon-qiyong',
            hide: (row: any) => row.state === '1',
            event: (row: any) => {
                edit({ id: row.id, state: '1' }).then((res: any) => {
                    if (res.code === 1) {
                        message.success('启用成功')
                        MyTablePageRef.value.search()
                    }
                })
            },
        },
        {
            title: '禁用',
            color: 'warn', // primary,success,warn,danger,info
            icon: 'iconfont icon-tingyong',
            hide: (row: any) => row.state !== '1',
            event: (row: any) => {
                edit({ id: row.id, state: '0' }).then((res: any) => {
                    if (res.code === 1) {
                        message.success('禁用成功')
                        MyTablePageRef.value.search()
                    }
                })
            },
        },
    ],
})

/**
 * 添加
 */
const handelAdd = () => {
    EditRef.value.show()
}

/**
 * 挂载，页面初始化后执行
 */
onMounted(() => {
    MyTablePageRef.value.search()
})
</script>

<style scoped lang="less"></style>
