<template>
    <YxModal
        ref="YxModalRef"
        :title="modalTitle"
        v-model:visible="visible"
        @ok="onSubmit"
        @cancel="onCancel"
        :submit-loading="submitLoading"
    >
        <AForm
            class="padding"
            ref="myFormRef"
            name="myFormRef"
            :model="formRef"
            :label-col="{ span: 4 }"
            :wrapper-col="{ span: 14 }"
        >
            <AFormItem label="学校名称" name="name" :rules="[{ max: 90, required: true }]">
                <AInput v-model:value="formRef.name" placeholder="" :maxlength="90"></AInput>
            </AFormItem>
            <AFormItem label="学校编码" name="tenantCode" :rules="[{ max: 20, required: true }]">
                <AInput v-model:value="formRef.tenantCode" placeholder="" :maxlength="20"></AInput>
            </AFormItem>
            <AFormItem
                label="联系人姓名"
                name="contactPerson"
                :rules="[{ max: 20, required: true }]"
            >
                <AInput
                    v-model:value="formRef.contactPerson"
                    placeholder=""
                    :maxlength="20"
                ></AInput>
            </AFormItem>
            <AFormItem
                label="联系人手机号"
                name="contactNumber"
                :rules="[
                    {
                        message: '请输入正确手机号',
                        pattern: '^1[3|4|5|6|7|8|9]\\d{9}$',
                        required: true,
                    },
                ]"
            >
                <AInput
                    v-model:value="formRef.contactNumber"
                    placeholder=""
                    :maxlength="11"
                ></AInput>
            </AFormItem>
            <AFormItem label="租户简介" name="remark" :rules="[{ max: 500 }]">
                <ATextarea
                    v-model:value="formRef.remark"
                    placeholder=""
                    :rows="3"
                    :maxlength="500"
                />
            </AFormItem>
            <AFormItem label="过期时间" name="expirationTime" :rules="[{ required: true }]">
                <YxDatePicker v-model:value="formRef.expirationTime" placeholder="" />
            </AFormItem>
            <AFormItem
                label="套餐"
                name="packageIds"
                :rules="[{ message: '请选择套餐', required: true }]"
            >
                <div style="color: red" v-if="packageOptions.length < 1">请先维护套餐</div>
                <ACheckboxGroup
                    v-else
                    v-model:value="formRef.packageIds"
                    :options="packageOptions"
                />
            </AFormItem>
            <AFormItem label="状态" name="state" :rules="[{ required: true }]">
                <ASelect
                    v-model:value="formRef.state"
                    show-search
                    placeholder=""
                    :options="stateOptions"
                    :filter-option="filterOption"
                ></ASelect>
            </AFormItem>
        </AForm>
    </YxModal>
</template>
<!--添加路由地址：/system/sysTenant/add，修改路由地址：/system/sysTenant/edit，组件地址：/system/sysTenant/edit-->
<script setup lang="ts">
import { FormInstance, message } from 'ant-design-vue'
import { ref } from 'vue'
import { save, edit, get } from '@/api/platform/sysTenant'
import { cloneDeep } from 'lodash-es'
import { leftCover } from '@/utils/ObjectUtils'
import { getList } from '@/api/common'
import dayjs from 'dayjs'

/**
 * 基础数据定义
 */
const visible = ref(false)
const submitLoading = ref(false)
const modalTitle = ref('添加租户信息表')

const myFormRef = ref<FormInstance>()

const defaultForm = {
    id: null, //主键ID
    tenantCode: null, //学校编码
    name: '', //名称
    contactPerson: '', //联系人
    contactNumber: '', //联系手机
    remark: '', //介绍
    expirationTime: '', //过期时间
    state: '1', //状态
    parentId: '0',
    packageIds: [], //套餐
}
const formRef = ref<any>(defaultForm)
const packageOptions = ref<any[]>([])
/**
 * 状态选项
 */
const stateOptions = ref([
    { label: '启用', value: '1' },
    { label: '禁用', value: '0' },
])
/**
 * 下拉搜索
 * @param input
 * @param option
 */
const filterOption = (input: string, option: any) => {
    return option.label.toLowerCase().indexOf(input.toLowerCase()) >= 0
}

/**
 * 显示弹窗
 */
const show = (params?: any) => {
    params = params || {}
    visible.value = true
    /**
     * 初始参数
     */
    formRef.value = Object.assign({}, defaultForm)
    leftCover(formRef.value, params)
    formRef.value.expirationTime = dayjs().add(1, 'y').format('YYYY-MM-DD')
    if (params.id) {
        modalTitle.value = '编辑租户信息表'
        get({ id: params.id }).then((res: any) => {
            const data = res.data
            leftCover(formRef.value, data)
            formRef.value.expirationTime = formRef.value.expirationTime.substring(0, 10)
        })
    }

    /**查询套餐选项*/
    getList(import.meta.env.VITE_API_URL_SYSTEM + '/v1/sys/package/getList', {
        pageNumber: -1,
        pageSize: -1,
    }).then((res) => {
        if (res.code === 1) {
            const options = [] as any[]
            res.data.rows.forEach((d: any) => {
                options.push({
                    label: d.name,
                    value: d.id,
                })
            })
            packageOptions.value = options
        }
    })
}
defineExpose({ show })

/**
 * 接收方法
 */
const emits = defineEmits(['ok'])
/**
 * 提交方法
 */
const onSubmit = () => {
    myFormRef.value?.validate().then(() => {
        submitLoading.value = true
        const params = cloneDeep(formRef.value)
        params.expirationTime += ' 23:59:59'
        if (params.id) {
            edit(params).then((res: any) => {
                if (res.code === 1) {
                    emits('ok')
                    message.success('提交成功')
                    onCancel()
                }
                submitLoading.value = false
            })
        } else {
            save(params).then((res: any) => {
                if (res.code === 1) {
                    emits('ok')
                    message.success('提交成功')
                    onCancel()
                }
                submitLoading.value = false
            })
        }
    })
}
/**
 * 关闭弹窗
 */
const onCancel = () => {
    myFormRef.value?.resetFields()
    visible.value = false
}
</script>

<style scoped lang="less"></style>
