<!--系统监控-->
<template>
    <PageWrapper title="系统监控">
        <template #subTitle>
            <ASelect v-model:value="serverRoot" :options="options" @change="handleChange"></ASelect>
        </template>
        <template #extra>
            <AButton key="1" type="primary" @click="onLoad">刷新</AButton>
        </template>

        <ARow :gutter="5">
            <ACol :span="6">
                <ACard
                    title="Cpu利用率"
                    :headStyle="{ textAlign: 'center' }"
                    :bodyStyle="{ textAlign: 'center' }"
                >
                    <AProgress
                        type="circle"
                        :percent="info.cpuInfo.toTal"
                        :stroke-color="getStrokeColor(info.cpuInfo.toTal)"
                        :format="(percent) => `${percent}%`"
                    />
                </ACard>
            </ACol>
            <ACol :span="6">
                <ACard
                    title="内存利用率"
                    :headStyle="{ textAlign: 'center' }"
                    :bodyStyle="{ textAlign: 'center' }"
                >
                    <AProgress
                        type="circle"
                        :stroke-color="getStrokeColor(info.memoryInfo.usage * 1)"
                        :percent="info.memoryInfo.usage"
                        :format="(percent) => `${percent}%`"
                    />
                </ACard>
            </ACol>
            <ACol :span="6">
                <ACard
                    title="JVM内存利用率"
                    :headStyle="{ textAlign: 'center' }"
                    :bodyStyle="{ textAlign: 'center' }"
                >
                    <AProgress
                        type="circle"
                        :stroke-color="getStrokeColor(info.jvmInfo.usage * 1)"
                        :percent="info.jvmInfo.usage"
                        :format="(percent) => `${percent}%`"
                    />
                </ACard>
            </ACol>
            <ACol :span="6">
                <ACard
                    title="磁盘利用率"
                    :headStyle="{ textAlign: 'center' }"
                    :bodyStyle="{ textAlign: 'center' }"
                >
                    <AProgress
                        type="circle"
                        :stroke-color="getStrokeColor(fileSystemUsage * 1)"
                        :percent="fileSystemUsage"
                        :format="(percent) => `${percent}%`"
                    />
                </ACard>
            </ACol>
        </ARow>
        <ACard title="Cpu信息" class="margin-top-xs">
            <ADescriptions bordered class="margin-left">
                <ADescriptionsItem label="CPU型号">{{ info.cpuInfo.cpuName }} </ADescriptionsItem>
                <ADescriptionsItem label="cpu核心数">{{ info.cpuInfo.cpuNum }} </ADescriptionsItem>
                <ADescriptionsItem label="CPU系统利用率"
                    >{{ info.cpuInfo.sys }}%
                </ADescriptionsItem>
                <ADescriptionsItem label="CPU用户利用率"
                    >{{ info.cpuInfo.used }}%
                </ADescriptionsItem>
                <ADescriptionsItem label="CPU当前等待率"
                    >{{ info.cpuInfo.wait }}%
                </ADescriptionsItem>
                <ADescriptionsItem label="CPU当前空闲率"
                    >{{ info.cpuInfo.free }}%
                </ADescriptionsItem>
                <ADescriptionsItem label="CPU总利用率"
                    >{{ info.cpuInfo.toTal }}%
                </ADescriptionsItem>
            </ADescriptions>
        </ACard>

        <ACard title="内存信息" class="margin-top-xs">
            <ADescriptions bordered class="margin-left">
                <ADescriptionsItem label="内存总量">{{ info.memoryInfo.toTal }} </ADescriptionsItem>
                <ADescriptionsItem label="已用内存">{{ info.memoryInfo.used }} </ADescriptionsItem>
                <ADescriptionsItem label="剩余内存">{{ info.memoryInfo.free }}</ADescriptionsItem>
                <ADescriptionsItem label="当前内存利用率"
                    >{{ info.memoryInfo.usage }}%
                </ADescriptionsItem>
            </ADescriptions>
        </ACard>
        <ACard title="JVM信息" class="margin-top-xs">
            <ADescriptions bordered class="margin-left">
                <ADescriptionsItem label="JDK名称">{{ info.jvmInfo.name }} </ADescriptionsItem>
                <ADescriptionsItem label="JDK安装路径">{{ info.jvmInfo.home }} </ADescriptionsItem>
                <ADescriptionsItem label="JDK版本信息"
                    >{{ info.jvmInfo.version }}
                </ADescriptionsItem>
                <ADescriptionsItem label="JVM的启动时间"
                    >{{ info.jvmInfo.startTime }}
                </ADescriptionsItem>
                <ADescriptionsItem label="JVM的运行时间"
                    >{{ info.jvmInfo.runTime }}
                </ADescriptionsItem>
                <ADescriptionsItem label="JVM最大可用内存总数"
                    >{{ info.jvmInfo.max }}
                </ADescriptionsItem>
                <ADescriptionsItem label="当前JVM占用的内存总数"
                    >{{ info.jvmInfo.toTal }}
                </ADescriptionsItem>
                <ADescriptionsItem label="当前JVM已经利用的部分"
                    >{{ info.jvmInfo.used }}
                </ADescriptionsItem>
                <ADescriptionsItem label="JVM空闲内存">{{ info.jvmInfo.free }} </ADescriptionsItem>
                <ADescriptionsItem label="当前JVM利用率"
                    >{{ info.jvmInfo.usage }}%
                </ADescriptionsItem>
            </ADescriptions>
        </ACard>
        <ACard title="系统信息" class="margin-top-xs">
            <ADescriptions bordered class="margin-left">
                <ADescriptionsItem label="系统名称"
                    >{{ info.operatingSystemInfo.hostName }}
                </ADescriptionsItem>
                <ADescriptionsItem label="操作系统制造商"
                    >{{ info.operatingSystemInfo.manufacturer }}
                </ADescriptionsItem>

                <ADescriptionsItem label="操作系统系列"
                    >{{ info.operatingSystemInfo.family }}
                </ADescriptionsItem>
                <ADescriptionsItem label="操作系统架构"
                    >{{ info.operatingSystemInfo.arch }}
                </ADescriptionsItem>
            </ADescriptions>
        </ACard>
        <ACard title="磁盘信息" class="margin-top-xs">
            <ADescriptions
                bordered
                class="margin-left"
                v-for="(item, index) in info.fileSystemInfo"
                :key="index"
            >
                <ADescriptionsItem label="磁盘名称">{{ item.name }} </ADescriptionsItem>
                <ADescriptionsItem label="盘符">{{ item.dirName }} </ADescriptionsItem>
                <ADescriptionsItem label="磁盘类型">{{ item.sysType }} </ADescriptionsItem>
                <ADescriptionsItem label="总大小">{{ item.toTal }} </ADescriptionsItem>
                <ADescriptionsItem label="空闲大小">{{ item.free }} </ADescriptionsItem>
                <ADescriptionsItem label="利用大小">{{ item.used }} </ADescriptionsItem>
                <ADescriptionsItem label="利用率">{{ item.usage }} </ADescriptionsItem>
            </ADescriptions>
        </ACard>
    </PageWrapper>
</template>
<script setup lang="ts" name="index">
import { computed, onMounted, ref } from 'vue'
import { get } from '@/api/common'
const options = [{ label: '系统服务', value: import.meta.env.VITE_API_URL_SYSTEM }]
const serverRoot = ref(options[0].value)
const handleChange = () => {
    onLoad()
}
const fileSystemUsage = ref(0)
const info = ref({
    cpuInfo: {
        cpuNum: 0,
        toTal: 0,
        sys: 0,
        used: 0,
        wait: 0,
        free: 0,
        cpuName: '',
    },
    fileSystemInfo: [],
    jvmInfo: {
        free: 0,
        home: '',
        max: 0,
        name: '',
        runTime: '',
        startTime: '',
        toTal: 0,
        usage: 0,
        used: 0,
        version: '',
    },
    memoryInfo: {
        toTal: 0,
        used: 0,
        free: 0,
        usage: 0,
    },
    operatingSystemInfo: {
        arch: '',
        family: '',
        hostName: '',
        manufacturer: '',
    },
})

const getStrokeColor = computed(() => {
    return (total: number) => {
        if (total > 90) {
            return '#f5222d'
        } else if (total > 70) {
            return '#fa8c16'
        } else if (total > 50) {
            return '#1890ff'
        } else {
            return '#52c41a'
        }
    }
})
const onLoad = () => {
    get(serverRoot.value + '/v1/monitor/sys', {}).then((res) => {
        if (res.code === 1) {
            info.value = res.data
            let usage = 0
            info.value.fileSystemInfo.forEach((f: any) => {
                usage += f.usage * 1
            })
            fileSystemUsage.value = usage / info.value.fileSystemInfo.length
        }
    })
}
onMounted(() => {
    onLoad()
})
</script>
<style scoped lang="less"></style>
