<template>
    <YxModal
        ref="YxModalRef"
        :title="modalTitle"
        v-model:visible="visible"
        @ok="onSubmit"
        @cancel="onCancel"
        :submit-loading="submitLoading"
    >
        <AForm
            class="padding"
            ref="myFormRef"
            name="myFormRef"
            :model="formRef"
            :label-col="{ span: 4 }"
            :wrapper-col="{ span: 14 }"
        >
            <AFormItem label="父级ID" name="parentId" :rules="[{ required: true }]">
                <!--tree-default-expand-all-->
                <ATreeSelect
                    v-model:value="formRef.parentId"
                    v-model:searchValue="parentIdSearchValue"
                    show-search
                    style="width: 100%"
                    treeNodeFilterProp="title"
                    :dropdown-style="{ maxHeight: '400px', overflow: 'auto' }"
                    placeholder=""
                    allow-clear
                    :tree-data="parentIdOptions"
                    :fieldNames="{
                        children: 'children',
                        label: 'title',
                        key: 'id',
                        value: 'id',
                    }"
                >
                    <template #title="{ title }">
                        <template
                            v-for="(fragment, i) in (title || '')
                                .toString()
                                .split(
                                    new RegExp(
                                        `(?<=${parentIdSearchValue})|(?=${parentIdSearchValue})`,
                                        'i',
                                    ),
                                )"
                        >
                            <span
                                v-if="fragment.toLowerCase() === parentIdSearchValue.toLowerCase()"
                                :key="i"
                                style="color: #08c"
                            >
                                {{ fragment }}
                            </span>
                            <template v-else>{{ fragment }}</template>
                        </template>
                    </template>
                </ATreeSelect>
            </AFormItem>
            <AFormItem label="名称" name="name" :rules="[{ max: 20, required: true }]">
                <AInput v-model:value="formRef.name" placeholder=""></AInput>
            </AFormItem>
            <AFormItem label="国家编码" name="adCode" :rules="[{ max: 12, required: true }]">
                <AInput v-model:value="formRef.adCode" placeholder=""></AInput>
            </AFormItem>
            <AFormItem label="层级" name="level" :rules="[{ required: true }]">
                <ASelect
                    v-model:value="formRef.level"
                    show-search
                    placeholder=""
                    :options="levelOptions"
                    :filter-option="filterOption"
                ></ASelect>
            </AFormItem>
        </AForm>
    </YxModal>
</template>
<!--添加路由地址：/system/sysArea/add，修改路由地址：/system/sysArea/edit，组件地址：/system/sysArea/edit-->
<script setup lang="ts">
import { FormInstance, message } from 'ant-design-vue'
import { ref } from 'vue'
import { save, edit, get } from '@/api/platform/sysArea'
import { leftCover } from '@/utils/ObjectUtils'

/**
 * 基础数据定义
 */
const visible = ref(false)
const submitLoading = ref(false)
const modalTitle = ref('添加行政区划')

const myFormRef = ref<FormInstance>()
const defaultForm = {
    id: null, //主键ID
    parentId: '', //父级ID
    name: '', //名称
    adCode: '', //国家编码
    level: '', //层级
}
const formRef = ref<any>({
    ...defaultForm,
})

/**
 * 父级ID选项
 */
import { getList } from '@/api/common'
const parentIdOptions = ref([])
/**
 * 树形下拉搜索值
 */
const parentIdSearchValue = ref('')

/**
 * 层级选项
 */
const levelOptions = ref([
    { label: '省', value: 'province' },
    { label: '市', value: 'city' },
    { label: '区/县', value: 'district' },
])
/**
 * 下拉搜索
 * @param input
 * @param option
 */
const filterOption = (input: string, option: any) => {
    return option.label.toLowerCase().indexOf(input.toLowerCase()) >= 0
}

/**
 * 显示弹窗
 */
const show = (params?: any) => {
    params = params || {}
    visible.value = true
    /**
     * 初始参数
     */
    formRef.value = Object.assign({}, { ...defaultForm })
    leftCover(formRef.value, params || {})

    if (params.id) {
        modalTitle.value = '编辑行政区划'
        get({ id: params.id }).then((res: any) => {
            const data = res.data
            leftCover(formRef.value, data)
        })
    }

    /**查询父级ID数据*/
    getList(`${import.meta.env.VITE_API_URL_SYSTEM}/v1/sys/area/getTree`).then((res) => {
        if (res.code === 1) {
            parentIdOptions.value = res.data
        }
    })
}
defineExpose({ show })

/**
 * 接收方法
 */
const emits = defineEmits(['ok'])
/**
 * 提交方法
 */
const onSubmit = () => {
    myFormRef.value?.validate().then(() => {
        submitLoading.value = true
        if (formRef.value.id) {
            edit(formRef.value).then((res: any) => {
                if (res.code === 1) {
                    emits('ok')
                    message.success('提交成功')
                    onCancel()
                }
                submitLoading.value = false
            })
        } else {
            save(formRef.value).then((res: any) => {
                if (res.code === 1) {
                    emits('ok')
                    message.success('提交成功')
                    onCancel()
                }
                submitLoading.value = false
            })
        }
    })
}
/**
 * 关闭弹窗
 */
const onCancel = () => {
    myFormRef.value?.resetFields()
    visible.value = false
}
</script>

<style scoped lang="less"></style>
