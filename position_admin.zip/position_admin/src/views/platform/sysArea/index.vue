<template>
    <PageWrapper title="行政区划" sub-title="">
        <MyTreeTablePage
            ref="MyTreeTablePageRef"
            :search-item="searchItem"
            :url="dataUrl"
            :columns="columns"
            :action="action"
            :ellipsis="1"
            pagination
            show-index
            :tree="treeConfig"
        >
            <template #tools>
                <AButton v-permission="'sysAreaAdd'" type="primary" @click="handelAdd()">
                    <template #icon>
                        <PlusOutlined />
                    </template>
                    添加
                </AButton>
            </template>
        </MyTreeTablePage>
        <Edit ref="EditRef" @ok="MyTreeTablePageRef.init()"></Edit>
    </PageWrapper>
</template>
<!--路由地址：/system/sysArea/index ,组件名称：sysAreaIndex	-->
<script setup lang="ts" name="sysAreaIndex">
import { PlusOutlined } from '@ant-design/icons-vue'
import { onMounted, reactive, ref } from 'vue'
import { message, Modal } from 'ant-design-vue'
import { del } from '@/api/platform/sysArea'

import Edit from './edit.vue'
const EditRef = ref()

const MyTreeTablePageRef = ref()
const dataUrl = `${import.meta.env.VITE_API_URL_SYSTEM}/v1/sys/area/getList`
const selectNode = ref({
    id: '0',
    name: '跟目录',
})

/*列配置 api https://itvita.gitee.io/liuyunxi-antd-extend/#/YxTable*/
const columns = ref([
    {
        title: '名称',
        dataIndex: 'name',
        hidden: false,
        align: 'left',
        fixed: 'none',
    },
    {
        title: '全称',
        dataIndex: 'fullName',
        hidden: false,
        align: 'left',
        fixed: 'none',
    },
    {
        title: '国家编码',
        dataIndex: 'adCode',
        hidden: false,
        align: 'left',
        fixed: 'none',
    },
    {
        title: '系统编码',
        dataIndex: 'areaCode',
        hidden: false,
        align: 'left',
        fixed: 'none',
    },
    {
        title: '层级',
        dataIndex: 'level',
        hidden: false,
        align: 'left',
        fixed: 'none',
        formatter: {
            type: 'text',
            format: (row: any) => {
                return {
                    value:
                        row.level === 'province'
                            ? '省级'
                            : row.level === 'city'
                            ? '市级'
                            : row.level === 'district'
                            ? '区级'
                            : '',
                }
            },
        },
    },
])

/*搜索条配置 api https://itvita.gitee.io/liuyunxi-antd-extend/#/YxSearch*/
const searchItem = ref([
    {
        type: 'text',
        key: 'name',
        label: '名称',
        value: '',
        placeholder: '',
    },
])

/**
 * 添加
 * @param treeNodes 当前选中节点
 */
const handelAdd = (treeNode?: any) => {
    if (treeNode) {
        selectNode.value = treeNode
    }
    EditRef.value.show({ parentId: selectNode.value.id })
}

/**
 * 编辑
 * @param id 选中ID
 */
const handelEdit = ({ id }: { id: string }) => {
    EditRef.value.show({ id: id })
}

/**
 * 删除，选中的ID数组
 * @param ids
 */
const handelDelete = (ids?: string[]) => {
    Modal.confirm({
        title: '确定删除？',
        content: '删除后将无法恢复',
        okType: 'danger',
        onOk() {
            del(ids).then((res: any) => {
                if (res.code === 1) {
                    message.success('删除成功').then(() => {})
                    MyTreeTablePageRef.value.init()
                }
            })
        },
    })
}

/*操作列配置*/
const action = ref({
    width: 200,
    fixed: 'right',
    buttons: [
        {
            title: '详情',
            icon: 'iconfont icon-caidan',
            event: (row: any) => {
                MyTreeTablePageRef.value.showDetail(row)
            },
        },
        {
            title: '编辑',
            icon: 'iconfont icon-bianji',
            permission: 'sysAreaEdit',
            event: (row: any) => {
                handelEdit({ id: row.id })
            },
        },
        {
            title: '删除',
            color: '#f12424', // primary,success,warn,danger,info
            icon: 'iconfont icon-shanchu',
            permission: 'sysAreaDelete',
            event: (row: any) => {
                handelDelete([row.id])
            },
        },
    ],
})

/*树形配置*/
const treeConfig = reactive({
    url: `${import.meta.env.VITE_API_URL_SYSTEM}/v1/sys/area/getZtree`,
    drag: false,
    add: true,
    edit: true,
    remove: true,
    handelClick: (treeNodes: any) => {
        selectNode.value = treeNodes
        MyTreeTablePageRef.value.search()
    },
    handelAdd: handelAdd,
    handelRemove: (treeNodes: any) => {
        handelDelete([treeNodes.id])
    },
    handelEdit: (treeNodes: any) => {
        handelEdit({ id: treeNodes.id })
    },
})

/**
 * 挂载，页面初始化后执行
 */
onMounted(() => {
    MyTreeTablePageRef.value.init()
})
</script>

<style scoped lang="less"></style>
