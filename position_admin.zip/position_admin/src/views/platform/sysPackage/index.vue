<template>
    <PageWrapper title="套餐管理" sub-title="">
        <MyTablePage
            ref="MyTablePageRef"
            :search-item="searchItem"
            :url="dataUrl"
            :columns="columns"
            :action="action"
            :ellipsis="1"
            show-index
            pagination
            selection="checkbox"
        >
            <template #tools>
                <AButton v-permission="'sysPackageAdd'" type="primary" @click="handelAdd">
                    <template #icon>
                        <PlusOutlined />
                    </template>
                    添加
                </AButton>
                <AButton v-permission="'sysPackageDelete'" type="danger" @click="deletes()">
                    <template #icon>
                        <DeleteOutlined />
                    </template>
                    批量删除
                </AButton>
            </template>
        </MyTablePage>
        <Auth ref="AuthRef"></Auth>
        <Edit ref="EditRef" @ok="MyTablePageRef.search()"></Edit>
    </PageWrapper>
</template>
<!--路由地址：/system/sysPackage/index ,组件名称：sysPackageIndex	-->
<script setup lang="ts" name="sysPackageIndex">
import { onMounted, ref } from 'vue'
import { DeleteOutlined, PlusOutlined } from '@ant-design/icons-vue'
import { message, Modal } from 'ant-design-vue'
import { cloneDeep } from 'lodash-es'
import { del } from '@/api/platform/sysPackage'
import Edit from './edit.vue'
const EditRef = ref()
import Auth from './auth.vue'
const AuthRef = ref()
const MyTablePageRef = ref()
const dataUrl = `${import.meta.env.VITE_API_URL_SYSTEM}/v1/sys/package/getList`

/*列配置 api https://itvita.gitee.io/liuyunxi-antd-extend/#/YxTable*/
const columns = ref<any[]>([
    {
        title: '套餐名称',
        width: 200,
        dataIndex: 'name',
        hidden: false,
    },
    {
        title: '价格',
        width: 100,
        dataIndex: 'price',
        hidden: false,
        formatter: {
            type: 'text',
            format: (row: any) => {
                return {
                    value: (row.price / 100).toFixed(2),
                }
            },
        },
    },
    {
        title: '备注',
        width: 300,
        dataIndex: 'remark',
        hidden: false,
    },
    {
        title: '状态',
        width: 80,
        dataIndex: 'state',
        hidden: false,
        formatter: {
            type: 'tag',
            format: (row: any) => {
                if (row.state === '1') {
                    return {
                        value: '启用',
                        color: '#1890ff',
                    }
                } else {
                    return {
                        value: '禁用',
                        color: '#fa541c',
                    }
                }
            },
        },
    },
])
/*搜索条配置 api https://itvita.gitee.io/liuyunxi-antd-extend/#/YxSearch*/
const searchItem = ref<any[]>([
    {
        type: 'text',
        key: 'name',
        label: '套餐名称',
        value: '',
        placeholder: '',
    },
])
/**
 * 批量删除方法
 * @param ids id数组
 */
const deletes = (ids?: string[]) => {
    if (ids === undefined) {
        const { selectedRowKeys } = MyTablePageRef.value.getSelection()
        ids = cloneDeep(selectedRowKeys)
    }
    if (!ids || ids?.length < 1) {
        Modal.warning({
            title: '请先选择删除项',
        })
        return
    }
    Modal.confirm({
        title: '确定删除？',
        content: '删除后将无法恢复',
        okType: 'danger',
        onOk() {
            del(ids).then((res: any) => {
                if (res.code === 1) {
                    message.success('删除成功')
                    MyTablePageRef.value.search()
                }
            })
        },
    })
}
/*table 操作列配置*/
const action = ref({
    width: 220,
    fixed: 'right',
    buttons: [
        {
            title: '详情',
            icon: 'iconfont icon-caidan',
            event: (row: any) => {
                MyTablePageRef.value.showDetail(row)
            },
        },
        {
            title: '编辑',
            icon: 'iconfont icon-bianji',
            permission: 'sysPackageEdit',
            event: (row: any) => {
                EditRef.value.show({ id: row.id })
            },
        },
        {
            title: '删除',
            color: '#f12424', // primary,success,warn,danger,info
            icon: 'iconfont icon-shanchu',
            permission: 'sysPackageDelete',
            event: (row: any) => {
                deletes([row.id])
            },
        },
        {
            title: '权限',
            color: 'success', // primary,success,warn,danger,info
            icon: 'iconfont icon-quanxian',
            permission: 'sysPackageAuth',
            event: (row: any) => {
                AuthRef.value.show({ id: row.id })
            },
        },
    ],
})

/**
 * 添加
 */
const handelAdd = () => {
    EditRef.value.show()
}

/**
 * 挂载，页面初始化后执行
 */
onMounted(() => {
    MyTablePageRef.value.search()
})
</script>

<style scoped lang="less"></style>
