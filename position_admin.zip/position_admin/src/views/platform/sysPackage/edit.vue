<template>
    <YxModal
        ref="YxModalRef"
        :title="modalTitle"
        v-model:visible="visible"
        @ok="onSubmit"
        @cancel="onCancel"
        :submit-loading="submitLoading"
    >
        <AForm
            class="padding"
            ref="myFormRef"
            name="myFormRef"
            :model="formRef"
            :label-col="{ span: 4 }"
            :wrapper-col="{ span: 14 }"
        >
            <AFormItem label="套餐名称" name="name" :rules="[{ max: 90, required: true }]">
                <AInput v-model:value="formRef.name" placeholder=""></AInput>
            </AFormItem>

            <AFormItem
                label="价格"
                name="price"
                :rules="[
                    {
                        required: true,
                    },
                ]"
            >
                <AInputNumber
                    :min="0"
                    :max="99999999"
                    v-model:value="formRef.price"
                    placeholder=""
                ></AInputNumber>
            </AFormItem>

            <AFormItem label="备注" name="remark" :rules="[]">
                <ATextarea v-model:value="formRef.remark" placeholder="" :rows="3" />
            </AFormItem>

            <AFormItem label="状态" name="state" :rules="[{ required: true }]">
                <ASelect
                    v-model:value="formRef.state"
                    show-search
                    placeholder=""
                    :options="stateOptions"
                    :filter-option="filterOption"
                ></ASelect>
            </AFormItem>
        </AForm>
    </YxModal>
</template>
<!--添加路由地址：/system/sysPackage/add，修改路由地址：/system/sysPackage/edit，组件地址：/system/sysPackage/edit-->
<script setup lang="ts">
import { FormInstance, message } from 'ant-design-vue'
import { ref } from 'vue'
import { save, edit, get } from '@/api/platform/sysPackage'
import { cloneDeep } from 'lodash-es'
import { leftCover } from '@/utils/ObjectUtils'

/**
 * 基础数据定义
 */
const visible = ref(false)
const submitLoading = ref(false)
const modalTitle = ref('添加套餐管理')

const myFormRef = ref<FormInstance>()
const defaultForm = {
    id: null, //主键ID
    name: '', //套餐名称
    price: 0, //价格;精确到分
    remark: '', //备注
    state: '1', //状态;1启用0禁用
}
const formRef = ref<any>({ ...defaultForm })

/**
 * 状态;1启用0禁用选项
 */
const stateOptions = ref([
    { label: '启用', value: '1' },
    { label: '禁用', value: '0' },
])
/**
 * 下拉搜索
 * @param input
 * @param option
 */
const filterOption = (input: string, option: any) => {
    return option.label.toLowerCase().indexOf(input.toLowerCase()) >= 0
}

/**
 * 显示弹窗
 */
const show = (params?: any) => {
    params = params || {}
    visible.value = true
    /**
     * 初始参数
     */
    formRef.value = Object.assign({}, { ...defaultForm })
    leftCover(formRef.value, params || {})

    if (params.id) {
        modalTitle.value = '编辑套餐管理'
        get({ id: params.id }).then((res: any) => {
            const data = res.data
            data.price = data.price / 100
            leftCover(formRef.value, data)
        })
    }
}
defineExpose({ show })

/**
 * 接收方法
 */
const emits = defineEmits(['ok'])
/**
 * 提交方法
 */
const onSubmit = () => {
    myFormRef.value?.validate().then(() => {
        submitLoading.value = true
        const params = cloneDeep(formRef.value)
        params.price = params.price * 100
        if (params.id) {
            edit(params).then((res: any) => {
                if (res.code === 1) {
                    emits('ok')
                    message.success('提交成功')
                    onCancel()
                }
                submitLoading.value = false
            })
        } else {
            save(params).then((res: any) => {
                if (res.code === 1) {
                    emits('ok')
                    message.success('提交成功')
                    onCancel()
                }
                submitLoading.value = false
            })
        }
    })
}
/**
 * 关闭弹窗
 */
const onCancel = () => {
    myFormRef.value?.resetFields()
    visible.value = false
}
</script>

<style scoped lang="less"></style>
