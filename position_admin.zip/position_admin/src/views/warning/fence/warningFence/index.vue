<template>
    <PageWrapper title="电子围栏" sub-title="">
        <MyTablePage
            ref="MyTablePageRef"
            :search-item="searchItem"
            :url="dataUrl"
            :columns="columns"
            :action="action"
            :ellipsis="1"
            show-index
            pagination
            selection="checkbox"
        >
            <template #tools>
                <AButton v-permission="'warningFenceAdd'" type="primary" @click="handelAdd">
                    <template #icon>
                        <PlusOutlined />
                    </template>
                    添加
                </AButton>
                <AButton v-permission="'warningFenceDelete'" type="danger" @click="deletes()">
                    <template #icon>
                        <DeleteOutlined />
                    </template>
                    批量删除
                </AButton>
                <AButton
                    v-permission="'warningFenceExport'"
                    type="success"
                    @click="MyTablePageRef.handleExport('电子围栏')"
                >
                    <template #icon>
                        <DownloadOutlined />
                    </template>
                    导出
                </AButton>
            </template>
        </MyTablePage>
        <Edit ref="EditRef" @ok="MyTablePageRef.search()"></Edit>
    </PageWrapper>
</template>
<!--路由地址：/warning/fence/warningFence/index ,组件名称：warningFenceIndex	-->
<script setup lang="ts" name="warningFenceIndex">
import { onMounted, ref } from 'vue'
import { DeleteOutlined, PlusOutlined, DownloadOutlined } from '@ant-design/icons-vue'
import { message, Modal } from 'ant-design-vue'
import { cloneDeep } from 'lodash-es'
import { del } from '@/api/warning/fence/warningFence'
import Edit from './edit.vue'
const EditRef = ref()

const MyTablePageRef = ref()
const dataUrl = `${import.meta.env.VITE_API_URL_SYSTEM}/v1/warning/fence/getList`
/*列配置 api https://itvita.gitee.io/liuyunxi-antd-extend/#/YxTable*/
const columns = ref<any[]>([
    {
        title: '区域名称',
        dataIndex: 'areaName',
        hidden: false,
        sorter: true,
        width: 200,
    },
    {
        title: '区域ID',
        dataIndex: 'areaId',
        hidden: true,
        sorter: true,
        width: 200,
    },
    {
        title: '启用时间',
        dataIndex: 'startTime',
        hidden: false,
        sorter: true,
        width: 200,
    },
    {
        title: '停用时间',
        dataIndex: 'stopTime',
        hidden: false,
        sorter: true,
        width: 200,
    },
    {
        title: '区域类型',
        dataIndex: 'areaType',
        hidden: false,
        sorter: true,
        width: 200,
    },
    {
        title: '关联对象',
        dataIndex: 'relationPerson',
        hidden: true,
        sorter: true,
        width: 200,
    },
    {
        title: '坐标数据',
        dataIndex: 'mapData',
        hidden: true,
        sorter: true,
        width: 200,
    },
    {
        title: '是否启用',
        dataIndex: 'isUse',
        hidden: false,
        sorter: true,
        width: 200,
    },
])
/*搜索条配置 api https://itvita.gitee.io/liuyunxi-antd-extend/#/YxSearch*/
const searchItem = ref<any[]>([])
/**
 * 批量删除方法
 * @param ids id数组
 */
const deletes = (ids?: string[]) => {
    if (ids === undefined) {
        const { selectedRowKeys } = MyTablePageRef.value.getSelection()
        ids = cloneDeep(selectedRowKeys)
    }
    if (!ids || ids?.length < 1) {
        Modal.warning({
            title: '请先选择删除项',
        })
        return
    }
    Modal.confirm({
        title: '确定删除？',
        content: '删除后将无法恢复',
        okType: 'danger',
        onOk() {
            del(ids).then((res: any) => {
                if (res.code === 1) {
                    message.success('删除成功')
                    MyTablePageRef.value.search()
                }
            })
        },
    })
}
/*table 操作列配置*/
const action = ref({
    width: 200,
    fixed: 'right',
    buttons: [
        {
            title: '详情',
            icon: 'iconfont icon-caidan',
            event: (row: any) => {
                MyTablePageRef.value.showDetail(row)
            },
        },
        {
            title: '编辑',
            icon: 'iconfont icon-bianji',
            permission: 'warningFenceEdit',
            event: (row: any) => {
                EditRef.value.show({ id: row.id })
            },
        },
        {
            title: '删除',
            color: '#f12424', // primary,success,warn,danger,info
            icon: 'iconfont icon-shanchu',
            permission: 'warningFenceDelete',
            event: (row: any) => {
                deletes([row.id])
            },
        },
    ],
})

/**
 * 添加
 */
const handelAdd = () => {
    EditRef.value.show()
}

/**
 * 挂载，页面初始化后执行
 */
onMounted(() => {
    MyTablePageRef.value.search()
})
</script>

<style scoped lang="less"></style>
