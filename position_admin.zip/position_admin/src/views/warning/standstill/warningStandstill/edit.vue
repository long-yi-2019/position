<template>
    <YxModal
        ref="YxModalRef"
        :title="modalTitle"
        v-model:visible="visible"
        @ok="onSubmit"
        @cancel="onCancel"
        :submit-loading="submitLoading"
    >
        <AForm
            class="bg-white padding"
            ref="myFormRef"
            name="myFormRef"
            :model="formRef"
            :label-col="{ span: 4 }"
            :wrapper-col="{ span: 14 }"
        >
            <AFormItem label="区域名称" name="areaName" extra="" :rules="[]">
                <AInput
                    v-model:value="formRef.areaName"
                    placeholder=""
                    show-count
                    :maxlength="50"
                ></AInput>
            </AFormItem>
            <AFormItem label="区域ID" name="areaId" extra="" :rules="[]">
                <AInput
                    v-model:value="formRef.areaId"
                    placeholder=""
                    show-count
                    :maxlength="50"
                ></AInput>
            </AFormItem>
            <AFormItem label="启用时间" name="startTime" extra="" :rules="[]">
                <YxDatePicker v-model:value="formRef.startTime" placeholder=""></YxDatePicker>
            </AFormItem>
            <AFormItem label="停用时间" name="stopTime" extra="" :rules="[]">
                <YxDatePicker v-model:value="formRef.stopTime" placeholder=""></YxDatePicker>
            </AFormItem>
            <AFormItem label="是否启用" name="isUse" extra="" :rules="[]">
                <ARadioGroup placeholder="" v-model:value="formRef.isUse" :options="isUseOptions" />
            </AFormItem>
            <AFormItem label="关联对象" name="relationPerson" extra="" :rules="[]">
                <!--tree-default-expand-all-->
                <ATreeSelect
                    v-model:value="formRef.relationPerson"
                    v-model:searchValue="relationPersonSearchValue"
                    show-search
                    style="width: 100%"
                    treeNodeFilterProp="title"
                    :dropdown-style="{ maxHeight: '400px', overflow: 'auto' }"
                    placeholder=""
                    allow-clear
                    :tree-data="relationPersonOptions"
                    :fieldNames="{
                        children: 'children',
                        label: 'title',
                        key: 'id',
                        value: 'id',
                    }"
                >
                    <template #title="{ title }">
                        <template
                            v-for="(fragment, i) in (title || '')
                                .toString()
                                .split(
                                    new RegExp(
                                        `(?<=${relationPersonSearchValue})|(?=${relationPersonSearchValue})`,
                                        'i',
                                    ),
                                )"
                        >
                            <span
                                v-if="
                                    fragment.toLowerCase() ===
                                    relationPersonSearchValue.toLowerCase()
                                "
                                :key="i"
                                style="color: #08c"
                            >
                                {{ fragment }}
                            </span>
                            <template v-else>{{ fragment }}</template>
                        </template>
                    </template>
                </ATreeSelect>
            </AFormItem>
            <AFormItem label="时间限制" name="timeLimit" extra="" :rules="[]">
                <AInputNumber
                    v-model:value="formRef.timeLimit"
                    placeholder=""
                    :min="0"
                    :max="999999999"
                />
            </AFormItem>
        </AForm>
    </YxModal>
</template>
<!--添加路由地址：/warning/standstill/warningStandstill/add，修改路由地址：/warning/standstill/warningStandstill/edit，组件地址：/warning/standstill/warningStandstill/edit-->
<script setup lang="ts">
import { FormInstance, message } from 'ant-design-vue'
import { ref } from 'vue'
import { save, edit, get } from '@/api/warning/standstill/warningStandstill'
import { cloneDeep } from 'lodash-es'
import { leftCover } from '@/utils/ObjectUtils'
/**
 * 基础数据定义
 */
const visible = ref(false)
const submitLoading = ref(false)
const modalTitle = ref('添加静止超时')

const myFormRef = ref<FormInstance>()

const defaultForm = {
    id: null, //主键ID
    areaName: '', //区域名称
    areaId: '', //区域ID
    startTime: '', //启用时间
    stopTime: '', //停用时间
    isUse: '', //是否启用
    relationPerson: '', //关联对象
    timeLimit: '', //时间限制
}
const formRef = ref<any>({ ...defaultForm })

/**
 * 是否启用选项
 */

const isUseOptions = [
    { label: '启用', value: '1' },
    { label: '停用', value: '0' },
]
/**
 * 关联对象选项
 */
/**
 * 树形下拉搜索值
 */
const relationPersonSearchValue = ref('')

/**
 * 显示弹窗
 */
const show = (params?: any) => {
    params = params || {}
    visible.value = true
    /**
     * 初始参数
     */
    formRef.value = Object.assign({}, { ...defaultForm })
    leftCover(formRef.value, params || {})

    if (params.id) {
        modalTitle.value = '编辑静止超时'
        get({ id: params.id }).then((res: any) => {
            const data = res.data
            leftCover(formRef.value, data)
        })
    }
}
defineExpose({ show })

/**
 * 接收方法
 */
const emits = defineEmits(['ok'])
/**
 * 提交方法
 */
const onSubmit = () => {
    myFormRef.value?.validate().then(() => {
        submitLoading.value = true
        const params = cloneDeep(formRef.value)
        for (let k in params) {
            if (typeof params[k] === 'object') {
                if (params[k]) {
                    params[k] = JSON.stringify(params[k])
                }
            }
        }
        if (params.id) {
            edit(params).then((res: any) => {
                if (res.code === 1) {
                    emits('ok')
                    message.success('提交成功')
                    onCancel()
                }
                submitLoading.value = false
            })
        } else {
            save(params).then((res: any) => {
                if (res.code === 1) {
                    emits('ok')
                    message.success('提交成功')
                    onCancel()
                }
                submitLoading.value = false
            })
        }
    })
}
/**
 * 关闭弹窗
 */
const onCancel = () => {
    myFormRef.value?.resetFields()
    visible.value = false
}
</script>

<style scoped lang="less"></style>
