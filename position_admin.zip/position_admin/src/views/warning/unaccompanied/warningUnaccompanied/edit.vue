<template>
    <YxModal
        ref="YxModalRef"
        :title="modalTitle"
        v-model:visible="visible"
        @ok="onSubmit"
        @cancel="onCancel"
        :submit-loading="submitLoading"
    >
        <AForm
            class="bg-white padding"
            ref="myFormRef"
            name="myFormRef"
            :model="formRef"
            :label-col="{ span: 4 }"
            :wrapper-col="{ span: 14 }"
        >
            <AFormItem label="区域名称" name="areaName" extra="" :rules="[]">
                <AInput
                    v-model:value="formRef.areaName"
                    placeholder=""
                    show-count
                    :maxlength="50"
                ></AInput>
            </AFormItem>
            <AFormItem label="启用时间" name="startTime" extra="" :rules="[]">
                <YxDatePicker v-model:value="formRef.startTime" placeholder=""></YxDatePicker>
            </AFormItem>
            <AFormItem label="停用时间" name="stopTime" extra="" :rules="[]">
                <YxDatePicker v-model:value="formRef.stopTime" placeholder=""></YxDatePicker>
            </AFormItem>
            <AFormItem
                label="监管人员
"
                name="monitorPerson"
                extra=""
                :rules="[]"
            >
                <!--tree-default-expand-all-->
                <ATreeSelect
                    v-model:value="formRef.monitorPerson"
                    v-model:searchValue="monitorPersonSearchValue"
                    show-search
                    style="width: 100%"
                    treeNodeFilterProp="title"
                    :dropdown-style="{ maxHeight: '400px', overflow: 'auto' }"
                    placeholder=""
                    allow-clear
                    :tree-data="monitorPersonOptions"
                    :fieldNames="{
                        children: 'children',
                        label: 'title',
                        key: 'id',
                        value: 'id',
                    }"
                >
                    <template #title="{ title }">
                        <template
                            v-for="(fragment, i) in (title || '')
                                .toString()
                                .split(
                                    new RegExp(
                                        `(?<=${monitorPersonSearchValue})|(?=${monitorPersonSearchValue})`,
                                        'i',
                                    ),
                                )"
                        >
                            <span
                                v-if="
                                    fragment.toLowerCase() ===
                                    monitorPersonSearchValue.toLowerCase()
                                "
                                :key="i"
                                style="color: #08c"
                            >
                                {{ fragment }}
                            </span>
                            <template v-else>{{ fragment }}</template>
                        </template>
                    </template>
                </ATreeSelect>
            </AFormItem>
            <AFormItem label="是否启用" name="isUse" extra="" :rules="[]">
                <ARadioGroup placeholder="" v-model:value="formRef.isUse" :options="isUseOptions" />
            </AFormItem>
            <AFormItem label="被监管人员" name="beMonitorPerson" extra="" :rules="[]">
                <!--tree-default-expand-all-->
                <ATreeSelect
                    v-model:value="formRef.beMonitorPerson"
                    v-model:searchValue="beMonitorPersonSearchValue"
                    show-search
                    style="width: 100%"
                    treeNodeFilterProp="title"
                    :dropdown-style="{ maxHeight: '400px', overflow: 'auto' }"
                    placeholder=""
                    allow-clear
                    :tree-data="beMonitorPersonOptions"
                    :fieldNames="{
                        children: 'children',
                        label: 'title',
                        key: 'id',
                        value: 'id',
                    }"
                >
                    <template #title="{ title }">
                        <template
                            v-for="(fragment, i) in (title || '')
                                .toString()
                                .split(
                                    new RegExp(
                                        `(?<=${beMonitorPersonSearchValue})|(?=${beMonitorPersonSearchValue})`,
                                        'i',
                                    ),
                                )"
                        >
                            <span
                                v-if="
                                    fragment.toLowerCase() ===
                                    beMonitorPersonSearchValue.toLowerCase()
                                "
                                :key="i"
                                style="color: #08c"
                            >
                                {{ fragment }}
                            </span>
                            <template v-else>{{ fragment }}</template>
                        </template>
                    </template>
                </ATreeSelect>
            </AFormItem>
            <AFormItem label="监管下限" name="warningLeast" extra="" :rules="[]">
                <AInputNumber
                    v-model:value="formRef.warningLeast"
                    placeholder=""
                    :min="0"
                    :max="999999999"
                />
            </AFormItem>
            <AFormItem label="免报时长" name="noWarningTime" extra="" :rules="[]">
                <AInputNumber
                    v-model:value="formRef.noWarningTime"
                    placeholder=""
                    :min="0"
                    :max="999999999"
                />
            </AFormItem>
        </AForm>
    </YxModal>
</template>
<!--添加路由地址：/warning/unaccompanied/warningUnaccompanied/add，修改路由地址：/warning/unaccompanied/warningUnaccompanied/edit，组件地址：/warning/unaccompanied/warningUnaccompanied/edit-->
<script setup lang="ts">
import { FormInstance, message } from 'ant-design-vue'
import { ref } from 'vue'
import { save, edit, get } from '@/api/warning/unaccompanied/warningUnaccompanied'
import { cloneDeep } from 'lodash-es'
import { leftCover } from '@/utils/ObjectUtils'
/**
 * 基础数据定义
 */
const visible = ref(false)
const submitLoading = ref(false)
const modalTitle = ref('添加无陪同警告')

const myFormRef = ref<FormInstance>()

const defaultForm = {
    id: null, //主键ID
    areaName: '', //区域名称
    startTime: '', //启用时间
    stopTime: '', //停用时间
    monitorPerson: '', //监管人员

    isUse: '', //是否启用
    beMonitorPerson: '', //被监管人员
    warningLeast: '', //监管下限
    noWarningTime: '', //免报时长
}
const formRef = ref<any>({ ...defaultForm })

/**
             * 监管人员
选项
             */
/**
 * 树形下拉搜索值
 */
const monitorPersonSearchValue = ref('')

/**
 * 是否启用选项
 */

const isUseOptions = [
    { label: '启用', value: '1' },
    { label: '停用', value: '0' },
]
/**
 * 被监管人员选项
 */
/**
 * 树形下拉搜索值
 */
const beMonitorPersonSearchValue = ref('')

/**
 * 显示弹窗
 */
const show = (params?: any) => {
    params = params || {}
    visible.value = true
    /**
     * 初始参数
     */
    formRef.value = Object.assign({}, { ...defaultForm })
    leftCover(formRef.value, params || {})

    if (params.id) {
        modalTitle.value = '编辑无陪同警告'
        get({ id: params.id }).then((res: any) => {
            const data = res.data
            leftCover(formRef.value, data)
        })
    }
}
defineExpose({ show })

/**
 * 接收方法
 */
const emits = defineEmits(['ok'])
/**
 * 提交方法
 */
const onSubmit = () => {
    myFormRef.value?.validate().then(() => {
        submitLoading.value = true
        const params = cloneDeep(formRef.value)
        for (let k in params) {
            if (typeof params[k] === 'object') {
                if (params[k]) {
                    params[k] = JSON.stringify(params[k])
                }
            }
        }
        if (params.id) {
            edit(params).then((res: any) => {
                if (res.code === 1) {
                    emits('ok')
                    message.success('提交成功')
                    onCancel()
                }
                submitLoading.value = false
            })
        } else {
            save(params).then((res: any) => {
                if (res.code === 1) {
                    emits('ok')
                    message.success('提交成功')
                    onCancel()
                }
                submitLoading.value = false
            })
        }
    })
}
/**
 * 关闭弹窗
 */
const onCancel = () => {
    myFormRef.value?.resetFields()
    visible.value = false
}
</script>

<style scoped lang="less"></style>
