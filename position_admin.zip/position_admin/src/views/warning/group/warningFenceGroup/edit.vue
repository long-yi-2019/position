<template>
    <YxModal
        ref="YxModalRef"
        :title="modalTitle"
        v-model:visible="visible"
        @ok="onSubmit"
        @cancel="onCancel"
        :submit-loading="submitLoading"
    >
        <AForm
            class="bg-white padding"
            ref="myFormRef"
            name="myFormRef"
            :model="formRef"
            :label-col="{ span: 4 }"
            :wrapper-col="{ span: 14 }"
        >
            <AFormItem label="任务名称" name="taskName" extra="" :rules="[]">
                <AInput
                    v-model:value="formRef.taskName"
                    placeholder=""
                    show-count
                    :maxlength="50"
                ></AInput>
            </AFormItem>
            <AFormItem label="启用时间" name="startTime" extra="" :rules="[]">
                <YxDatePicker v-model:value="formRef.startTime" placeholder=""></YxDatePicker>
            </AFormItem>
            <AFormItem label="停用时间" name="stopTime" extra="" :rules="[]">
                <YxDatePicker v-model:value="formRef.stopTime" placeholder=""></YxDatePicker>
            </AFormItem>
            <AFormItem label="区域类型" name="areaType" extra="" :rules="[]">
                <ASelect
                    v-model:value="formRef.areaType"
                    show-search
                    placeholder=""
                    :options="areaTypeOptions"
                    :filter-option="filterOption"
                ></ASelect>
            </AFormItem>
            <AFormItem label="电子围栏" name="warningFence" extra="" :rules="[]">
                <!--tree-default-expand-all-->
                <ATreeSelect
                    v-model:value="formRef.warningFence"
                    v-model:searchValue="warningFenceSearchValue"
                    show-search
                    style="width: 100%"
                    treeNodeFilterProp="title"
                    :dropdown-style="{ maxHeight: '400px', overflow: 'auto' }"
                    placeholder=""
                    allow-clear
                    :tree-data="warningFenceOptions"
                    :fieldNames="{
                        children: 'children',
                        label: 'title',
                        key: 'id',
                        value: 'id',
                    }"
                >
                    <template #title="{ title }">
                        <template
                            v-for="(fragment, i) in (title || '')
                                .toString()
                                .split(
                                    new RegExp(
                                        `(?<=${warningFenceSearchValue})|(?=${warningFenceSearchValue})`,
                                        'i',
                                    ),
                                )"
                        >
                            <span
                                v-if="
                                    fragment.toLowerCase() === warningFenceSearchValue.toLowerCase()
                                "
                                :key="i"
                                style="color: #08c"
                            >
                                {{ fragment }}
                            </span>
                            <template v-else>{{ fragment }}</template>
                        </template>
                    </template>
                </ATreeSelect>
            </AFormItem>
            <AFormItem label="告警对象" name="warningObject" extra="" :rules="[]">
                <!--tree-default-expand-all-->
                <ATreeSelect
                    v-model:value="formRef.warningObject"
                    v-model:searchValue="warningObjectSearchValue"
                    show-search
                    style="width: 100%"
                    treeNodeFilterProp="title"
                    :dropdown-style="{ maxHeight: '400px', overflow: 'auto' }"
                    placeholder=""
                    allow-clear
                    :tree-data="warningObjectOptions"
                    :fieldNames="{
                        children: 'children',
                        label: 'title',
                        key: 'id',
                        value: 'id',
                    }"
                >
                    <template #title="{ title }">
                        <template
                            v-for="(fragment, i) in (title || '')
                                .toString()
                                .split(
                                    new RegExp(
                                        `(?<=${warningObjectSearchValue})|(?=${warningObjectSearchValue})`,
                                        'i',
                                    ),
                                )"
                        >
                            <span
                                v-if="
                                    fragment.toLowerCase() ===
                                    warningObjectSearchValue.toLowerCase()
                                "
                                :key="i"
                                style="color: #08c"
                            >
                                {{ fragment }}
                            </span>
                            <template v-else>{{ fragment }}</template>
                        </template>
                    </template>
                </ATreeSelect>
            </AFormItem>
            <AFormItem label="是否启用" name="isUse" extra="" :rules="[]">
                <ARadioGroup placeholder="" v-model:value="formRef.isUse" :options="isUseOptions" />
            </AFormItem>
        </AForm>
    </YxModal>
</template>
<!--添加路由地址：/warning/group/warningFenceGroup/add，修改路由地址：/warning/group/warningFenceGroup/edit，组件地址：/warning/group/warningFenceGroup/edit-->
<script setup lang="ts">
import { FormInstance, message } from 'ant-design-vue'
import { ref } from 'vue'
import { save, edit, get } from '@/api/warning/group/warningFenceGroup'
import { cloneDeep } from 'lodash-es'
import { leftCover } from '@/utils/ObjectUtils'
/**
 * 基础数据定义
 */
const visible = ref(false)
const submitLoading = ref(false)
const modalTitle = ref('添加围栏联组任务')

const myFormRef = ref<FormInstance>()

const defaultForm = {
    id: null, //主键ID
    taskName: '', //任务名称
    startTime: '', //启用时间
    stopTime: '', //停用时间
    areaType: '', //区域类型
    warningFence: '', //电子围栏
    warningObject: '', //告警对象
    isUse: '', //是否启用
}
const formRef = ref<any>({ ...defaultForm })

/**
 * 区域类型选项
 */
/**
 * 下拉搜索
 * @param input
 * @param option
 */
const filterOption = (input: string, option: any) => {
    return option.label.toLowerCase().indexOf(input.toLowerCase()) >= 0
}

/**
 * 电子围栏选项
 */
/**
 * 树形下拉搜索值
 */
const warningFenceSearchValue = ref('')

/**
 * 告警对象选项
 */
/**
 * 树形下拉搜索值
 */
const warningObjectSearchValue = ref('')

/**
 * 是否启用选项
 */
const isUseOptions = [
    { label: '启用', value: '1' },
    { label: '停用', value: '0' },
]
/**
 * 显示弹窗
 */
const show = (params?: any) => {
    params = params || {}
    visible.value = true
    /**
     * 初始参数
     */
    formRef.value = Object.assign({}, { ...defaultForm })
    leftCover(formRef.value, params || {})

    if (params.id) {
        modalTitle.value = '编辑围栏联组任务'
        get({ id: params.id }).then((res: any) => {
            const data = res.data
            leftCover(formRef.value, data)
        })
    }
}
defineExpose({ show })

/**
 * 接收方法
 */
const emits = defineEmits(['ok'])
/**
 * 提交方法
 */
const onSubmit = () => {
    myFormRef.value?.validate().then(() => {
        submitLoading.value = true
        const params = cloneDeep(formRef.value)
        for (let k in params) {
            if (typeof params[k] === 'object') {
                if (params[k]) {
                    params[k] = JSON.stringify(params[k])
                }
            }
        }
        if (params.id) {
            edit(params).then((res: any) => {
                if (res.code === 1) {
                    emits('ok')
                    message.success('提交成功')
                    onCancel()
                }
                submitLoading.value = false
            })
        } else {
            save(params).then((res: any) => {
                if (res.code === 1) {
                    emits('ok')
                    message.success('提交成功')
                    onCancel()
                }
                submitLoading.value = false
            })
        }
    })
}
/**
 * 关闭弹窗
 */
const onCancel = () => {
    myFormRef.value?.resetFields()
    visible.value = false
}
</script>

<style scoped lang="less"></style>
