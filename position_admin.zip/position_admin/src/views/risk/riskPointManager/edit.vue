<template>
    <YxModal
        ref="YxModalRef"
        :title="modalTitle"
        v-model:visible="visible"
        @ok="onSubmit"
        @cancel="onCancel"
        :submit-loading="submitLoading"
    >
        <AForm
            class="bg-white padding"
            ref="myFormRef"
            name="myFormRef"
            :model="formRef"
            :label-col="{ span: 4 }"
            :wrapper-col="{ span: 14 }"
        >
            <AFormItem
                label="风险点名称"
                name="riskPointId"
                extra=""
                :rules="[{ required: true, message: '请输入风险点名称', trigger: 'blur' }]"
            >
                <AInput
                    v-model:value="formRef.riskPointId"
                    placeholder="请输入"
                    show-count
                    :maxlength="50"
                ></AInput>
            </AFormItem>
            <AFormItem
                label="所在风险区域"
                name="riskArea"
                extra=""
                :rules="[{ required: true, message: '请选择所在风险区域', trigger: 'blur' }]"
            >
                <ASelect
                    v-model:value="formRef.riskArea"
                    show-search
                    placeholder=""
                    :options="riskAreaOptions"
                    :filter-option="filterOption"
                ></ASelect>
            </AFormItem>
            <AFormItem
                label="风险点类型"
                name="riskPointType"
                extra=""
                :rules="[{ required: true, message: '请选择风险点类型', trigger: 'blur' }]"
            >
                <ASelect
                    v-model:value="formRef.riskPointType"
                    show-search
                    placeholder=""
                    :options="riskPointTypeOptions"
                    :filter-option="filterOption"
                ></ASelect>
            </AFormItem>
            <AFormItem
                label="识别时间"
                name="identifyTime"
                extra=""
                :rules="[{ required: true, message: '请选择识别时间', trigger: 'blur' }]"
            >
                <YxDatePicker
                    v-model:value="formRef.identifyTime"
                    placeholder=""
                    show-time="yyyy-MM-dd HH:mm:ss"
                ></YxDatePicker>
            </AFormItem>
        </AForm>
    </YxModal>
</template>
<!--添加路由地址：/risk/riskPointManager/add，修改路由地址：/risk/riskPointManager/edit，组件地址：/risk/riskPointManager/edit-->
<script setup lang="ts">
import { FormInstance, message } from 'ant-design-vue'
import { ref } from 'vue'
import { save, edit, get } from '@/api/risk/riskPointManager'
import { cloneDeep } from 'lodash-es'
import { leftCover } from '@/utils/ObjectUtils'
import { getList } from '@/api/common'
/**
 * 基础数据定义
 */
const visible = ref(false)
const submitLoading = ref(false)
const modalTitle = ref('添加风险点管理')

const myFormRef = ref<FormInstance>()

const defaultForm = {
    id: null, //主键ID
    riskPointId: '', //风险点名称
    riskArea: '', //所在风险区域
    riskPointType: '', //风险点类型
    identifyTime: '', //识别时间
}
const formRef = ref<any>({ ...defaultForm })

/**
 * 所在风险区域选项
 */
const riskAreaOptions = ref([])
/**
 * 下拉搜索
 * @param input
 * @param option
 */
const filterOption = (input: string, option: any) => {
    return option.label.toLowerCase().indexOf(input.toLowerCase()) >= 0
}

/**
 * 风险点类型选项
 */
const riskPointTypeOptions = [
    { label: '设施设备', value: '设施设备' },
    { label: '作业活动', value: '作业活动' },
]
// const handleLevelTimeChange = (value: string) => {
//     console.log('原始值:', value) // 打印原始值
//     const momentValue = moment(value)
//     console.log('Moment对象:', momentValue) // 打印Moment对象
//     const formattedDateTime = momentValue.utcOffset(8).format('YYYY-MM-DD HH:mm:ss')
//     console.log('格式化后的值:', formattedDateTime) // 打印格式化后的值
//     formRef.value.levelTime = formattedDateTime
// }

/**
 * 显示弹窗
 */
const show = (params?: any) => {
    params = params || {}
    visible.value = true
    /**
     * 初始参数
     */
    formRef.value = Object.assign({}, { ...defaultForm })
    leftCover(formRef.value, params || {})

    if (params.id) {
        modalTitle.value = '编辑风险点管理'
        get({ id: params.id }).then((res: any) => {
            const data = res.data
            leftCover(formRef.value, data)
        })
    }
    getList(`${import.meta.env.VITE_API_URL_SYSTEM}/v1/risk/area/manager/getAllRiskArea`).then(
        (res) => {
            if (res.code === 1) {
                riskAreaOptions.value = res.data.map((item) => ({
                    label: item, // 使用 res.data 中的内容作为标签和值
                    value: item,
                }))
                console.log(res.data)
            }
        },
    )
}
defineExpose({ show })

/**
 * 接收方法
 */
const emits = defineEmits(['ok'])
/**
 * 提交方法
 */
const onSubmit = () => {
    myFormRef.value?.validate().then(() => {
        submitLoading.value = true
        const params = cloneDeep(formRef.value)
        for (let k in params) {
            if (typeof params[k] === 'object') {
                if (params[k]) {
                    params[k] = JSON.stringify(params[k])
                }
            }
        }
        if (params.id) {
            edit(params).then((res: any) => {
                if (res.code === 1) {
                    emits('ok')
                    message.success('提交成功')
                    onCancel()
                }
                submitLoading.value = false
            })
        } else {
            save(params).then((res: any) => {
                if (res.code === 1) {
                    emits('ok')
                    message.success('提交成功')
                    onCancel()
                }
                submitLoading.value = false
            })
        }
    })
}
/**
 * 关闭弹窗
 */
const onCancel = () => {
    myFormRef.value?.resetFields()
    visible.value = false
}
</script>

<style scoped lang="less"></style>
