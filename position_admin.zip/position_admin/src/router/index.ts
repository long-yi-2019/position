import { createRouter, createWebHistory } from 'vue-router'
import { defaultRouterList } from './defaultRouter'

export const allRoutes = [...defaultRouterList]

const router = createRouter({
    history: createWebHistory(import.meta.env.VITE_BASE_URL),
    routes: allRoutes,
    scrollBehavior() {
        return {
            el: '#app',
            top: 0,
            behavior: 'smooth',
        }
    },
})

export default router
