import { RouteRecordRaw } from 'vue-router'
import BlankLayout from '@/layouts/BlankLayout.vue'
// const BaseLayoutCompMap = import.meta.glob(`@/layouts/BaseLayout.vue`)

// 存放开发环境路由
const devRouter: Array<RouteRecordRaw> = [
    {
        name: 'developer',
        path: '/developer',
        component: BlankLayout,
        redirect: '/developer/doc/index',
        meta: { title: '开发环境功能', keepAlive: false, icon: 'icon-kaifa' },
        children: [
            // {
            //     name: 'menuIndex',
            //     path: '/platform/sysMenu/index',
            //     component: () => import('@/views/platform/sysMenu/index.vue'),
            //     meta: { title: '菜单管理', keepAlive: false, icon: 'icon-menu' },
            // },
            {
                name: 'testIndex',
                path: '/developer/doc/index',
                component: () => import('@/views/developer/doc/index.vue'),
                meta: { title: '系统接口', keepAlive: false, icon: 'icon-menu' },
            },
            {
                name: 'toolsGenerate',
                path: '/developer/generate/index',
                component: () => import('@/views/developer/generate/index.vue'),
                meta: { title: '代码生成器', keepAlive: false, icon: 'icon-menu' },
            },
            // {
            //     name: 'workflowIndex',
            //     path: '/developer/workflow/index',
            //     component: () => import('@/views/developer/workflow/index.vue'),
            //     meta: { title: '流程模板', keepAlive: false, icon: 'icon-menu' },
            // },
            // {
            //     name: 'dynamicFormsIndex',
            //     path: '/developer/dynamicForms/index',
            //     component: () => import('@/views/developer/dynamicForms/index.vue'),
            //     meta: { title: '表单模板', keepAlive: false, icon: 'icon-menu' },
            // },
            {
                name: 'ESignatureIndex',
                path: '/developer/ESignature/index',
                component: () => import('@/views/developer/ESignature/index.vue'),
                meta: { title: '在线签名', keepAlive: false, icon: 'icon-menu' },
            },
            {
                name: 'printPdf',
                path: '/developer/printPdf/index',
                component: () => import('@/views/developer/printPdf/index.vue'),
                meta: { title: '在线打印pdf', keepAlive: false, icon: 'icon-menu' },
            },
            // {
            //     name: 'riskConfig',
            //     path: '/server/riskEvaluationConf/index',
            //     component: () => import('@/views//server/riskEvaluationConf/index.vue'),
            //     meta: { title: '风险配置', keepAlive: false, icon: 'icon-menu' },
            // },
        ],
    },
]

// 存放固定的路由
const defaultRouterList: Array<RouteRecordRaw> = [
    {
        name: 'login',
        path: '/login',
        component: () => import('@/views/login/index.vue'),
        meta: { title: '登录', keepAlive: false, icon: 'icon-menu', hidden: true },
    },
    {
        name: 'welcome',
        path: '/welcome',
        component: () => import('@/views/login/welcome.vue'),
        meta: { title: '欢迎登录', keepAlive: false, icon: 'icon-menu', hidden: true },
    },
    {
        name: 'logout',
        path: '/logout',
        component: () => import('@/views/login/logout.vue'),
        meta: { title: '登出', keepAlive: false, icon: 'icon-menu', hidden: true },
    },
    {
        name: 'userCenter',
        path: '/system/user/center',
        component: () => import('@/layouts/BaseLayout.vue'),
        redirect: '/system/user/info',
        meta: { title: '个人中心', keepAlive: false, icon: 'icon-menu', hidden: true },
        children: [
            {
                path: '/system/user/workbench',
                name: 'workbench',
                component: () => import('@/views/system/sysUser/workbench.vue'),
                meta: { title: '工作台', keepAlive: false, icon: 'icon-menu', hidden: true },
            },
            {
                name: 'userInfo',
                path: '/system/user/info',
                component: () => import('@/views/system/sysUser/info.vue'),
                meta: { title: '个人资料', keepAlive: false, icon: 'icon-menu', hidden: true },
            },
            {
                name: 'userUpdPass',
                path: '/system/user/updPass',
                component: () => import('@/views/system/sysUser/updPass.vue'),
                meta: { title: '修改密码', keepAlive: false, icon: 'icon-menu', hidden: true },
            },
            {
                name: 'userNotice',
                path: '/system/user/notice',
                component: () => import('@/views/system/sysNotice/myNotice.vue'),
                meta: { title: '我的消息', keepAlive: false, icon: 'icon-menu', hidden: true },
            },
        ],
    },
]
export { devRouter, defaultRouterList }
