<template>
    <RouterView></RouterView>
</template>

<script setup lang="ts"></script>

<style scoped lang="less"></style>
