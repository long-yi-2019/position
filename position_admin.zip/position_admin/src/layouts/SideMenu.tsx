import { defineComponent, h, Fragment } from 'vue'

const React = { createElement: h, Fragment }
import { getNoticeStore } from '@/store'
export default defineComponent({
    props: {
        menus: {
            type: Array,
            default: () => [],
        },
    },
    setup(props) {
        const noticeStore = getNoticeStore()

        const slots = (item: any, type: number) => {
            const icon = () => {
                if (item.meta.icon && item.meta.icon.indexOf('icon-') === 0) {
                    return <i class={'iconfont ' + item.meta.icon}></i>
                } else {
                    // @ts-ignore
                    return <YxSvgIcon name={item.meta.icon} size="16px"></YxSvgIcon>
                }
            }
            // title={item.meta.title + '(' + approveStore.unApproveNum + ')'}

            const title = () => {
                return badgeTitle(item)
            }
            if (type === 1) {
                return {
                    icon: icon,
                }
            }
            if (type === 2) {
                return {
                    icon: icon,
                    title: title,
                }
            }
        }

        const badgeTitle = (item: any) => {
            /*这里需要明确知道目录id
             * e94a2682-1282-471e-a689-cc5541c930c3 业务审批目录
             * 待审批  待审批路由
             * */
            if (item.meta.title === '通知公告' || item.meta.title === '我的消息') {
                return (
                    <div>
                        {item.meta.title} <a-badge count={noticeStore.unReadNum} />
                    </div>
                )
            } else {
                return <div>{item.meta.title}</div>
            }
        }
        const useRenderNav = (list: any[]) => {
            return list.map((item) => {
                if (!item.children || !item.children.length) {
                    const href = item.path.match(/(http|https):\/\/([\w.]+\/?)\S*/)
                    if (href) {
                        return (
                            <a-menu-item key={item.name} v-slots={slots(item, 1)}>
                                <a href={item.path} target="_blank">
                                    {item.meta.title}
                                </a>
                            </a-menu-item>
                        )
                    }
                    return (
                        /*路由*/
                        <a-menu-item key={item.name} v-slots={slots(item, 1)}>
                            <router-link to={item.path}> {badgeTitle(item)}</router-link>
                        </a-menu-item>
                    )
                }
                return (
                    <a-sub-menu key={item.name} v-slots={slots(item, 2)}>
                        {item.children && useRenderNav(item.children)}
                    </a-sub-menu>
                )
            })
        }

        return () => useRenderNav(props.menus)
    },
})
