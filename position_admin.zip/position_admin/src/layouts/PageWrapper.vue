<template>
    <div class="yx-page-wrapper" id="yx-page-wrapper">
        <APageHeader class="yx-page-header" :title="props.title" @back="goBack" v-if="!props.hide">
            <template #subTitle>
                <slot name="subTitle">{{ props.subTitle }}</slot>
            </template>

            <template #extra>
                <slot name="extra"></slot>
            </template>

            <template #breadcrumb>
                <ABreadcrumb :routes="breadcrumbs">
                    <template #itemRender="{ route }">
                        <!--                        v-if="routes.indexOf(route) === routes.length - 1"-->
                        <!--                        <span>{{ route.name }}</span>-->
                        <RouterLink :to="route.path">{{ route.name }}</RouterLink>
                    </template>
                </ABreadcrumb>
            </template>
        </APageHeader>
        <div class="main_body">
            <div class="yx-page-wrapper-body-container">
                <slot></slot>
            </div>
        </div>
    </div>
</template>

<script setup lang="ts">
import { computed } from 'vue'
import { cloneDeep } from 'lodash-es'
import { useRoute, useRouter } from 'vue-router'

const router = useRouter()
const route = useRoute()

interface Props {
    title: string
    subTitle?: string
    hide?: boolean
}

const props = withDefaults(defineProps<Props>(), {
    title: '',
    subTitle: '',
    hide: false,
})

const goBack = () => {
    router.back()
}

const breadcrumbs = computed(() => {
    const list = cloneDeep((route.meta.breadcrumb as any[]) || ([] as any[])) as any
    if (list.length < 1) {
        return []
    }
    list.push({
        name: route.meta.title,
        path: route.path,
    })
    return list
})
</script>

<style scoped lang="less">
@import '@/theme/theme.less';

.yx-page-wrapper {
    width: 100%;
    height: 100%;
    position: relative;
}

.yx-page-header {
    background-color: @component-background;
}

.main_body {
    height: 100%;
    padding: 16px;
}

.yx-page-wrapper-body-container {
    padding: 20px;
    height: calc(100% - 50px);
    background-color: @component-background;
    border-radius: 8px;
    overflow: auto;
}
</style>
