<!--标签页-->
<template>
    <div class="card-container" oncontextmenu="return false">
        <ATabs
            :activeKey="activeKey"
            hide-add
            type="editable-card"
            @edit="onEdit"
            @tabClick="handleTabClick"
        >
            <ATabPane oncontextmenu="return false" v-for="item in tabsList" :key="item.path">
                <template #tab>
                    <ADropdown :trigger="['contextmenu']">
                        <span style="line-height: 41px; padding: 10px 0 10px 16px">
                            <i class="iconfont margin-right-xss" :class="item.meta?.icon"></i>
                            {{ item.meta?.title }}
                        </span>
                        <template #overlay>
                            <AMenu
                                oncontextmenu="return false"
                                @click="
                                    ({ key }) => {
                                        handleTabMenuClick(key, item)
                                    }
                                "
                            >
                                <AMenuItem key="close">关闭标签</AMenuItem>
                                <AMenuItem key="closeOther">关闭其他标签</AMenuItem>
                                <AMenuItem key="closeLeft">关闭左侧标签</AMenuItem>
                                <AMenuItem key="closeRight">关闭右侧标签</AMenuItem>
                                <AMenuDivider></AMenuDivider>
                                <AMenuItem key="openNewWindow">新窗口打开</AMenuItem>
                            </AMenu>
                        </template>
                    </ADropdown>
                </template>
            </ATabPane>
        </ATabs>
    </div>
</template>
<script setup lang="ts" name="Tabs">
import { computed, onMounted } from 'vue'
import { getPermissionStore } from '@/store'
const permissionStore = getPermissionStore()
import { useRouter } from 'vue-router'
import { message } from 'ant-design-vue'
const router = useRouter()
const tabsList = computed(() => {
    return permissionStore.tabsList
})

const activeKey = computed(() => {
    return permissionStore.tabsActive
})

const handleTabClick = (activeKey) => {
    permissionStore.tabsChange(activeKey)
    router.push(activeKey)
}

const handleRemove = (targetKey) => {
    let activePath = ''
    if (targetKey === activeKey.value) {
        if (tabsList.value.length === 1) {
            message.warn('至少需要保留一个页签')
            return
        }
        /*删除并选中前面一个*/
        const targetKeyIndex = tabsList.value.findIndex((t) => t.path === targetKey)
        if (targetKeyIndex > 0) {
            activePath = tabsList.value[targetKeyIndex - 1].path
        } else {
            activePath = tabsList.value[targetKeyIndex + 1].path
        }
    }
    permissionStore.tabsRemove(targetKey, activePath)
    if (activePath) {
        router.push(activePath)
    }
}

const onEdit = (targetKey, action) => {
    /*删除*/
    if (action === 'remove') {
        handleRemove(targetKey)
    }
}
const handleTabMenuClick = (key, item) => {
    // 关闭标签页
    if (key === 'close') {
        handleRemove(item.path)
    }
    //关闭其他标签页
    else if (key === 'closeOther') {
        if (item.path !== activeKey.value) {
            router.push(item.path)
        }
        permissionStore.tabsCloseOther(item.path)
    }
    //关闭右侧标签页
    else if (key === 'closeLeft') {
        const newPath = permissionStore.tabsCloseLeft(item.path)
        if (newPath) {
            router.push(newPath)
        }
    }
    //关闭右侧标签页
    else if (key === 'closeRight') {
        const newPath = permissionStore.tabsCloseRight(item.path)
        if (newPath) {
            router.push(newPath)
        }
    }
    //新窗口打开
    else if (key === 'openNewWindow') {
        let routeUrl = router.resolve(item)
        window.open(routeUrl.href, '_blank')
    }
}

onMounted(() => {})
</script>
<style lang="less">
@import '@/theme/theme.less';
.card-container {
    .ant-tabs-nav {
        margin: 0;
    }
    .ant-tabs-tab {
        &:hover {
            background: @primary-1 !important;
        }
    }
}
.card-container > .ant-tabs-card .ant-tabs-content > .ant-tabs-tabpane {
    padding: 1px;
    background: @primary-2;
}
.card-container p {
    margin: 0;
}
.card-container > .ant-tabs-card > .ant-tabs-nav::before {
    display: none;
}
.card-container > .ant-tabs-card .ant-tabs-tab {
    background: transparent;
    border-color: transparent;
    padding: 0 16px 0 0;
}
.card-container > .ant-tabs-card .ant-tabs-tab-active {
    background: @primary-2;
    border-color: @border-color-split;
    border-top: unset;
    border-bottom: unset;
}
</style>
