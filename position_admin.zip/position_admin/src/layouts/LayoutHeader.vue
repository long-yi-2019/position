<template>
    <ALayoutHeader class="layout__header">
        <div class="layout__header__left">
            <!--            <div-->
            <!--                class="logo"-->
            <!--                :style="{-->
            <!--                    backgroundImage: 'url(' + logoPath + ')',-->
            <!--                }"-->
            <!--            />-->
            <img class="logo" alt="" :src="logoPath" />
            <!--            <div class="title">-->
            <!--                <span class="margin-left-xs">{{ viteSiteName }}</span>-->
            <!--            </div>-->
        </div>
        <div class="layout__header__right">
            <!--            <DataScreen />-->
            <!--            <ADivider type="vertical" />-->
            <!--            <UserNotice />-->
            <!--            <ADivider type="vertical" />-->
            <UserInfo />
        </div>
    </ALayoutHeader>
</template>

<script lang="ts" setup>
import UserInfo from '@/components/LayoutHeaderRight/UserInfo.vue'
// import DataScreen from '@/components/LayoutHeaderRight/DataScreen.vue'
// import UserNotice from '@/components/LayoutHeaderRight/UserNotice.vue'
import { getPermissionStore } from '@/store'
import { onMounted } from 'vue'
const permissionStore = getPermissionStore()
const logoPath = import.meta.env.VITE_BASE_URL + import.meta.env.VITE_SITE_LOGIN_LOGO

// const viteSiteName = import.meta.env.VITE_SITE_NAME

onMounted(() => {
    /*左侧显示全部菜单*/
    permissionStore.restMenuRouters(permissionStore.loadAllMenu())
})
</script>

<style lang="less" scoped>
@import '@/theme/theme.less';

.layout__header {
    background: @layout-header-background;
    color: @layout-header-color;
    padding: 0;
    display: flex;
    align-items: center;
    justify-content: space-between;
    height: 55px;
    border-bottom: @border-width-base @border-style-base @layout-border-color;

    .layout__header__left {
        display: flex;
        flex-shrink: 0;
        align-items: center;
        .logo {
            display: block;
            height: 42px;
            margin-left: 22px;
            background-size: 100% 100%;
        }
    }

    .layout__header__right {
        padding-right: 20px;
        display: flex;
        align-items: center;
    }
    .title {
        font-size: 20px;
        font-weight: 600;
    }
}
</style>
