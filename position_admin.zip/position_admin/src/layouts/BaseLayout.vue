<template>
    <ALayout id="components-layout-side" style="min-height: 100vh">
        <LayoutHeader></LayoutHeader>
        <ALayout>
            <ALayoutSider
                v-model:collapsed="menuState.collapsed"
                :trigger="null"
                collapsible
                width="230"
                class="yx-layout-sider"
            >
                <!--                <div class="menu-title">{{ moduleTitle || '全部模块' }}</div>-->
                <AMenu
                    style="user-select: none"
                    v-model:selectedKeys="selectedKeys"
                    :open-keys="openKeys"
                    @openChange="onOpenChange"
                    class="left-menu"
                    mode="inline"
                >
                    <SideMenu :menus="menus"></SideMenu>
                </AMenu>
                <div
                    class="layout-menu__control"
                    @click="() => (menuState.collapsed = !menuState.collapsed)"
                >
                    <MenuUnfoldOutlined v-if="menuState.collapsed" class="trigger" />
                    <MenuFoldOutlined v-else class="trigger" />
                </div>
            </ALayoutSider>
            <ALayoutContent>
                <Tabs></Tabs>
                <div class="layout__content" id="page_main">
                    <!--                  leave-active-class="animate__animated animate__bounceOut"-->
                    <RouterView v-slot="{ Component }">
                        <Transition
                            name="fade"
                            enter-active-class="animate__animated  animate__zoomIn animate__faster"
                        >
                            <Component :is="Component" />
                        </Transition>
                    </RouterView>

                    <!--                    <RouterView>-->
                    <!--                        &lt;!&ndash; leave-active-class="animate__animated animate__bounceOut"&ndash;&gt;-->
                    <!--                        <Transition-->
                    <!--                            name="fade"-->
                    <!--                            enter-active-class="animate__animated  animate__zoomIn animate__faster"-->
                    <!--                        >-->
                    <!--                            &lt;!&ndash;                            <KeepAlive :include="aliveViews" :max="10">&ndash;&gt;-->
                    <!--                            &lt;!&ndash;                                <Component :is="Component" :key="route.name" />&ndash;&gt;-->
                    <!--                            &lt;!&ndash;                            </KeepAlive>&ndash;&gt;-->
                    <!--                        </Transition>-->
                    <!--                    </RouterView>-->
                </div>
                <ALayoutFooter style="text-align: center; padding: 0">
                    <a href="javascript:void(0)">
                        <!--                        ©2023 纳格安全 版权所有&nbsp;&nbsp;-->
                        格安智能物联(深圳)有限公司提供技术支持
                    </a>
                </ALayoutFooter>
            </ALayoutContent>
        </ALayout>
    </ALayout>
</template>
<script lang="ts" setup>
import { MenuFoldOutlined, MenuUnfoldOutlined } from '@ant-design/icons-vue'
import { computed, nextTick, onMounted, reactive, ref, watch } from 'vue'
import LayoutHeader from '@/layouts/LayoutHeader.vue'

import Tabs from '@/layouts/Tabs.vue'
import SideMenu from './SideMenu'
import { useRoute } from 'vue-router'
const route = useRoute()
import { getPermissionStore, getNoticeStore } from '@/store'
const permissionStore = getPermissionStore()
const noticeStore = getNoticeStore()

const menuState = reactive({
    collapsed: ref<boolean>(false),
})
/*左侧菜单选中key*/
const selectedKeys = ref<string[]>([route.name as string])
/*左侧菜单打开key*/
const openKeys = ref<string[]>([])
/**
 * 左侧菜单
 */
const menus = computed(() => {
    return getMenuList(permissionStore.menuRouters)
})

// const moduleTitle = computed(() => {
//     return permissionStore.activeModule.title || ''
// })

const hideChild = (arr: any[]): any[] => {
    if (!arr) {
        return []
    }
    return arr.map((item) => {
        if (item.children?.length === 1) {
            return {
                name: item.children[0].name,
                path: item.children[0].path,
                children: hideChild(item.children[0].children),
                meta: item.meta,
            }
        } else {
            return {
                ...item,
                children: hideChild(item.children),
            }
        }
    })
}
/**
 * 获取左侧菜单
 * @param newMenuRouters
 */
const getMenuList = (newMenuRouters: any[]): any[] => {
    if (!newMenuRouters) {
        return []
    }
    const list = newMenuRouters
        .map((item) => {
            return {
                name: item.name,
                path: item.path,
                children: getMenuList(item.children),
                meta: item.meta,
                redirect: item.redirect,
            }
        })
        .filter((v) => v.meta?.hidden !== true)

    return hideChild(list)
}
/**
 * 获取每个节点的父name数组
 */
const findParents = computed(() => {
    const obj = {}
    const setParent = (arr, parents) => {
        arr.forEach((m) => {
            const pIds = JSON.parse(JSON.stringify(parents))
            pIds.push(m.name)
            obj[m.name] = pIds
            if (m.children && m.children.length > 0) {
                setParent(m.children, pIds)
            }
        })
    }
    setParent(menus.value, [])
    return obj
})

/**
 * 保持只展开一个节点
 * @param openKey
 */
const onOpenChange = (openKey: string[]) => {
    const latestOpenKey = openKey.find((key) => openKeys.value.indexOf(key) === -1)
    if (latestOpenKey) {
        //  新展开了一个菜单
        openKeys.value = findParents.value[latestOpenKey]
    }
}

watch(
    () => permissionStore.tabsActive,
    () => {
        nextTick(() => {
            /*默认选中项*/
            const activeItem = permissionStore.tabsList.filter(
                (t) => t.path === permissionStore.tabsActive,
            )
            if (activeItem.length > 0) {
                selectedKeys.value = [activeItem[0].name as string]
                /**
                 * 默认展开项 -- 需要通过menuRouter匹配
                 */
                openKeys.value = []
                activeItem[0]?.meta?.breadcrumb?.forEach((m) => {
                    openKeys.value.push(m.key as string)
                })
            }
        })
    },
)

onMounted(() => {
    /**
     * 默认展开项 -- 需要通过menuRouter匹配
     */
    openKeys.value = []
    route.meta.breadcrumb?.forEach((m) => {
        openKeys.value.push(m.key as string)
    })
    // 未读通知数量
    noticeStore.getUnreadNum()

    /*模拟异步数据改变*/
    // setTimeout(() => {
    //     approveStore.unApproveNum = 8
    // }, 3000)
})
</script>
<style lang="less" scoped>
@import '@/theme/theme.less';

#components-layout-side {
    .logo {
        height: 32px;
        line-height: 32px;
        margin-left: 22px;
        color: #ffffff;
        font-size: 14px;
    }
}

#components-layout-side .trigger {
    font-size: 18px;
    padding: 0 24px;
    cursor: pointer;
    transition: color 0.3s;
}

.layout__sider__menu {
    height: calc(100vh - 64px);
    overflow-y: auto;

    &::-webkit-scrollbar {
        width: 15px;
        height: 15px;
        background-color: transparent;
        border-radius: 9px;
    }

    &::-webkit-scrollbar-thumb {
        background-color: #344158;
        border-radius: 0;
        background-clip: content-box;
        border: 4px solid transparent;
    }

    //&::-webkit-scrollbar-track { /*滚动条里面轨道*/
    //  /*-webkit-box-shadow: inset 0 0 5px blue;*/
    //  /*border-radius: 0;*/
    //  /*background: #ececec;*/
    //}
}

.layout-menu__control {
    position: absolute;
    bottom: 0;
    width: 100%;
    padding: 10px;
    cursor: pointer;
    border-top: @border-width-base @border-style-base @layout-border-color;
    //background-color: @component-background;
    &:hover {
        color: @primary-color-hover;
    }
}

.layout__content {
    position: relative;
    height: calc(100vh - 130px);
    overflow: hidden;
}

.yx-layout-sider {
    background: @layout-menu-background;
    border-right: @border-width-base @border-style-base @layout-border-color;
    color: @layout-header-color;
}
.menu-title {
    font-size: 16px;
    font-weight: 600;
    color: @text-color-inverse;
    padding: @padding-xs @padding-lg;
}
.left-menu {
    height: calc(100vh - 103px);
    padding-bottom: 40px;
    overflow-y: auto;
    &::-webkit-scrollbar {
        width: 0;
    }
}
</style>
