<template>
    <AConfigProvider :locale="zhCN">
        <RouterView></RouterView>
    </AConfigProvider>
</template>

<script setup lang="ts">
import zhCN from 'ant-design-vue/es/locale/zh_CN'
import 'dayjs/locale/zh-cn'
import { onMounted } from 'vue'

onMounted(() => {})
</script>

<style lang="less">
@import 'ant-design-vue/dist/antd.less';
@import '@/assets/css/style.less';
@import '@/assets/css/icon/iconfont.css';
</style>
