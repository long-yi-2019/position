import http from '@/utils/http'

/**
 * 保存SystemForRiskManager
 */
export function save(data: any) {
    return http.post({
        url: import.meta.env.VITE_API_URL_SYSTEM + '/v1/sys/role/tmp/save',
        data,
    })
}

/**
 * 修改SystemForRiskManager
 */
export function edit(data: any) {
    return http.post({
        url: import.meta.env.VITE_API_URL_SYSTEM + '/v1/sys/role/tmp/edit',
        data,
    })
}
/**
 * 删除SystemForRiskManager
 */
export function del(data: any) {
    return http.post({
        url: import.meta.env.VITE_API_URL_SYSTEM + '/v1/sys/role/tmp/delete',
        data,
    })
}
/**
 * 根据ID查询SystemForRiskManager
 */
export function get(data: any) {
    return http.get({
        url: import.meta.env.VITE_API_URL_SYSTEM + '/v1/sys/role/tmp/get',
        data,
    })
}
