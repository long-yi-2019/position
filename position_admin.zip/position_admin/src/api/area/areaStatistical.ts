import http from '@/utils/http'

/**
 * 保存统计区域
 */
export function save(data: any) {
    return http.post({
        url: import.meta.env.VITE_API_URL_SYSTEM + '/v1/area/statistical/save',
        data,
    })
}

/**
 * 修改统计区域
 */
export function edit(data: any) {
    return http.post({
        url: import.meta.env.VITE_API_URL_SYSTEM + '/v1/area/statistical/edit',
        data,
    })
}
/**
 * 删除统计区域
 */
export function del(data: any) {
    return http.post({
        url: import.meta.env.VITE_API_URL_SYSTEM + '/v1/area/statistical/delete',
        data,
    })
}
/**
 * 根据ID查询统计区域
 */
export function get(data: any) {
    return http.get({
        url: import.meta.env.VITE_API_URL_SYSTEM + '/v1/area/statistical/get',
        data,
    })
}
