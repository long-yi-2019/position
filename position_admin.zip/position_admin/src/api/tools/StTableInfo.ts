import http from '@/utils/Http'

/**
 * 查询所有表
 */
export function getAllTable() {
    return http.get({
        url: import.meta.env.VITE_API_URL_GEN + '/v1/st/table/info/getAllTable',
    })
}

/**
 * 查询所有已选表
 */
export function getGenTable() {
    return http.get({
        url: import.meta.env.VITE_API_URL_GEN + '/v1/st/table/info/getGenTable',
    })
}

/**
 * 保存
 */
export function save(data: any) {
    return http.post({
        url: import.meta.env.VITE_API_URL_GEN + '/v1/st/table/info/save',
        data,
    })
}

/**
 * 保存
 */
export function update(data: any) {
    return http.post({
        url: import.meta.env.VITE_API_URL_GEN + '/v1/st/table/info/update',
        data,
    })
}

/**
 * 保存
 */
export function get(data: any) {
    return http.get({
        url: import.meta.env.VITE_API_URL_GEN + '/v1/st/table/info/get',
        data,
    })
}

/**
 * 删除
 */
export function del(data: any) {
    return http.post({
        url: import.meta.env.VITE_API_URL_GEN + '/v1/st/table/info/delete',
        data,
    })
}

/**
 * 代码生成
 */
export function create(data: any) {
    return http.get({
        url: import.meta.env.VITE_API_URL_GEN + '/v1/st/table/info/create',
        data,
    })
}
