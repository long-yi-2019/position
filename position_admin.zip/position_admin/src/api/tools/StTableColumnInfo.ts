import http from '@/utils/Http'

/**
 * 修改
 */
export function update(data: any) {
    return http.post({
        url: import.meta.env.VITE_API_URL_GEN + '/v1/st/table/column/info/update',
        data,
    })
}

/**
 * 同步
 */
export function columnSync(data: any) {
    return http.get({
        url: import.meta.env.VITE_API_URL_GEN + '/v1/st/table/column/info/sync',
        data,
    })
}

/**
 * 排序
 */
export function sort(data: any) {
    return http.post({
        url: import.meta.env.VITE_API_URL_GEN + '/v1/st/table/column/info/sort',
        data,
    })
}
