import http from '@/utils/Http'

/**
 * 查询系统监控信息
 */
export function get(data: any) {
    return http.get({
        url: import.meta.env.VITE_API_URL_SYSTEM + '/v1/monitor/sys',
        data,
    })
}
