import http from '@/utils/Http'

/**
 * 保存行政区划
 */
export function save(data: any) {
    return http.post({
        url: import.meta.env.VITE_API_URL_SYSTEM + '/v1/sys/area/save',
        data,
    })
}

/**
 * 修改行政区划
 */
export function edit(data: any) {
    return http.post({
        url: import.meta.env.VITE_API_URL_SYSTEM + '/v1/sys/area/edit',
        data,
    })
}
/**
 * 删除行政区划
 */
export function del(data: any) {
    return http.post({
        url: import.meta.env.VITE_API_URL_SYSTEM + '/v1/sys/area/delete',
        data,
    })
}
/**
 * 根据ID查询行政区划
 */
export function get(data: any) {
    return http.get({
        url: import.meta.env.VITE_API_URL_SYSTEM + '/v1/sys/area/get',
        data,
    })
}
