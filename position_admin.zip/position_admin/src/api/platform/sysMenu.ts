import http from '@/utils/Http'

/**
 * 保存
 */
export function save(data: any) {
    return http.post({
        url: import.meta.env.VITE_API_URL_SYSTEM + '/v1/sys/menu/save',
        data,
    })
}

/**
 * 编辑
 */
export function edit(data: any) {
    return http.post({
        url: import.meta.env.VITE_API_URL_SYSTEM + '/v1/sys/menu/edit',
        data,
    })
}
/**
 * 删除
 */
export function del(data: any) {
    return http.post({
        url: import.meta.env.VITE_API_URL_SYSTEM + '/v1/sys/menu/delete',
        data,
    })
}
/**
 * 根据ID查询
 */
export function get(data: any) {
    return http.get({
        url: import.meta.env.VITE_API_URL_SYSTEM + '/v1/sys/menu/get',
        data,
    })
}
/**
 * 拖拽排序
 */
export function move(data: any) {
    return http.post({
        url: import.meta.env.VITE_API_URL_SYSTEM + '/v1/sys/menu/move',
        data,
    })
}
/**
 * 根据ID查询树形数据
 */
export function getTree(data: any) {
    return http.get({
        url: import.meta.env.VITE_API_URL_SYSTEM + '/v1/sys/menu/getTree',
        data,
    })
}

export function getTreeByTenantId(data: any) {
    return http.get({
        url: import.meta.env.VITE_API_URL_SYSTEM + '/v1/sys/menu/getTreeByTenantId',
        data,
    })
}
