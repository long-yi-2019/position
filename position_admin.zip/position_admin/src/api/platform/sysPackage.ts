import http from '@/utils/Http'

/**
 * 保存套餐管理
 */
export function save(data: any) {
    return http.post({
        url: import.meta.env.VITE_API_URL_SYSTEM + '/v1/sys/package/save',
        data,
    })
}

/**
 * 修改套餐管理
 */
export function edit(data: any) {
    return http.post({
        url: import.meta.env.VITE_API_URL_SYSTEM + '/v1/sys/package/edit',
        data,
    })
}
/**
 * 删除套餐管理
 */
export function del(data: any) {
    return http.post({
        url: import.meta.env.VITE_API_URL_SYSTEM + '/v1/sys/package/delete',
        data,
    })
}
/**
 * 根据ID查询套餐管理
 */
export function get(data: any) {
    return http.get({
        url: import.meta.env.VITE_API_URL_SYSTEM + '/v1/sys/package/get',
        data,
    })
}
/**
 * 保存套餐权限
 */
export function savePackageAuth(data: any) {
    return http.post({
        url: import.meta.env.VITE_API_URL_SYSTEM + '/v1/sys/package/savePackageAuth',
        data,
    })
}

/**
 * 查询套餐权限
 */
export function getPackageAuth(data: any) {
    return http.get({
        url: import.meta.env.VITE_API_URL_SYSTEM + '/v1/sys/package/getPackageAuth',
        data,
    })
}
