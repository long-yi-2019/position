import http from '@/utils/Http'

/**
 * 保存帮助文档
 */
export function save(data: any) {
    return http.post({
        url: import.meta.env.VITE_API_URL_SYSTEM + '/v1/sys/helper/save',
        data,
    })
}

/**
 * 修改帮助文档
 */
export function edit(data: any) {
    return http.post({
        url: import.meta.env.VITE_API_URL_SYSTEM + '/v1/sys/helper/edit',
        data,
    })
}
/**
 * 删除帮助文档
 */
export function del(data: any) {
    return http.post({
        url: import.meta.env.VITE_API_URL_SYSTEM + '/v1/sys/helper/delete',
        data,
    })
}
/**
 * 根据ID查询帮助文档
 */
export function get(data: any) {
    return http.get({
        url: import.meta.env.VITE_API_URL_SYSTEM + '/v1/sys/helper/get',
        data,
    })
}
/**
 * 查询帮助文档列表
 */
export function getList(data: any) {
    return http.get({
        url: import.meta.env.VITE_API_URL_SYSTEM + '/v1/sys/helper/getList',
        data,
    })
}
