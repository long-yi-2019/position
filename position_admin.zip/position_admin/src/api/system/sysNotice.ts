import http from '@/utils/http'

/**
 * 保存通知公告
 */
export function save(data: any) {
    return http.post({
        url: import.meta.env.VITE_API_URL_SYSTEM + '/v1/sys/notice/save',
        data,
    })
}

/**
 * 修改通知公告
 */
export function edit(data: any) {
    return http.post({
        url: import.meta.env.VITE_API_URL_SYSTEM + '/v1/sys/notice/edit',
        data,
    })
}
/**
 * 删除通知公告
 */
export function del(data: any) {
    return http.post({
        url: import.meta.env.VITE_API_URL_SYSTEM + '/v1/sys/notice/delete',
        data,
    })
}
/**
 * 根据ID查询通知公告
 */
export function get(data: any) {
    return http.get({
        url: import.meta.env.VITE_API_URL_SYSTEM + '/v1/sys/notice/get',
        data,
    })
}
/**
 * 根据ID查询通知公告阅读列表
 */
export function getRead(data: any) {
    return http.get({
        url: import.meta.env.VITE_API_URL_SYSTEM + '/v1/sys/notice/getRead',
        data,
    })
}
