import http from '@/utils/Http'

/**
 * 保存角色管理
 */
export function save(data: any) {
    return http.post({
        url: import.meta.env.VITE_API_URL_SYSTEM + '/v1/sys/role/save',
        data,
    })
}

/**
 * 修改角色管理
 */
export function edit(data: any) {
    return http.post({
        url: import.meta.env.VITE_API_URL_SYSTEM + '/v1/sys/role/edit',
        data,
    })
}

/**
 * 保存角色数据权限
 */
export function editDataAuth(data: any) {
    return http.post({
        url: import.meta.env.VITE_API_URL_SYSTEM + '/v1/sys/role/editDataAuth',
        data,
    })
}

/**
 * 删除角色管理
 */
export function del(data: any) {
    return http.post({
        url: import.meta.env.VITE_API_URL_SYSTEM + '/v1/sys/role/delete',
        data,
    })
}
/**
 * 根据ID查询角色管理
 */
export function get(data: any) {
    return http.get({
        url: import.meta.env.VITE_API_URL_SYSTEM + '/v1/sys/role/get',
        data,
    })
}

/**
 * 根据ID查询角色带数据权限CodeList
 */
export function getRoleAuthList(data: any) {
    return http.get({
        url: import.meta.env.VITE_API_URL_SYSTEM + '/v1/sys/role/getRoleAuthList',
        data,
    })
}

/**
 * 保存角色权限
 */
export function saveAuth(data: any) {
    return http.post({
        url: import.meta.env.VITE_API_URL_SYSTEM + '/v1/sys/auth/saveAuth',
        data,
    })
}

/**
 * 根据角色ID查询权限
 */
export function getAuth(data: any) {
    return http.get({
        url: import.meta.env.VITE_API_URL_SYSTEM + '/v1/sys/auth/getAuth',
        data,
    })
}

/**
 * 保存角色权限
 */
export function editRoleUser(data: any) {
    return http.post({
        url: import.meta.env.VITE_API_URL_SYSTEM + '/v1/sys/role/editRoleUser',
        data,
    })
}

/**
 * 取消角色权限
 */
export function cancelRoleUser(data: any) {
    return http.post({
        url: import.meta.env.VITE_API_URL_SYSTEM + '/v1/sys/role/cancelRoleUser',
        data,
    })
}
