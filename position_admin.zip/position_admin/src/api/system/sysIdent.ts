import http from '@/utils/Http'

/**
 * 保存图标库
 */
export function save(data: any) {
    return http.post({
        url: import.meta.env.VITE_API_URL_SYSTEM + '/v1/sys/ident/save',
        data,
    })
}

/**
 * 修改图标库
 */
export function edit(data: any) {
    return http.post({
        url: import.meta.env.VITE_API_URL_SYSTEM + '/v1/sys/ident/edit',
        data,
    })
}
/**
 * 删除图标库
 */
export function del(data: any) {
    return http.post({
        url: import.meta.env.VITE_API_URL_SYSTEM + '/v1/sys/ident/delete',
        data,
    })
}
/**
 * 根据ID查询图标库
 */
export function get(data: any) {
    return http.get({
        url: import.meta.env.VITE_API_URL_SYSTEM + '/v1/sys/ident/get',
        data,
    })
}
