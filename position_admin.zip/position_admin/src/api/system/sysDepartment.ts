import http from '@/utils/Http'

/**
 * 保存部门
 */
export function save(data: any) {
    return http.post({
        url: import.meta.env.VITE_API_URL_SYSTEM + '/v1/sys/department/save',
        data,
    })
}

/**
 * 修改部门
 */
export function edit(data: any) {
    return http.post({
        url: import.meta.env.VITE_API_URL_SYSTEM + '/v1/sys/department/edit',
        data,
    })
}
/**
 * 删除部门
 */
export function del(data: any) {
    return http.post({
        url: import.meta.env.VITE_API_URL_SYSTEM + '/v1/sys/department/delete',
        data,
    })
}
/**
 * 根据ID查询部门
 */
export function get(data: any) {
    return http.get({
        url: import.meta.env.VITE_API_URL_SYSTEM + '/v1/sys/department/get',
        data,
    })
}

/**
 * 根据ID查询部门
 */
export function getTree(data: any) {
    return http.get({
        url: import.meta.env.VITE_API_URL_SYSTEM + '/v1/sys/department/getTree',
        data,
    })
}
/**
 * 初始化（郑大）
 */
export function sync(data: any) {
    return http.get({
        url: import.meta.env.VITE_API_URL_SYSTEM + '/v1/sys/department/sync',
        data,
    })
}
