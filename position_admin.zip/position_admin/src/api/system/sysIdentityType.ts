import http from '@/utils/http'

/**
 * 保存身份标签
 */
export function save(data: any) {
    return http.post({
        url: import.meta.env.VITE_API_URL_SYSTEM + '/v1/sys/identity/type/save',
        data,
    })
}

/**
 * 修改身份标签
 */
export function edit(data: any) {
    return http.post({
        url: import.meta.env.VITE_API_URL_SYSTEM + '/v1/sys/identity/type/edit',
        data,
    })
}
/**
 * 删除身份标签
 */
export function del(data: any) {
    return http.post({
        url: import.meta.env.VITE_API_URL_SYSTEM + '/v1/sys/identity/type/delete',
        data,
    })
}
/**
 * 根据ID查询身份标签
 */
export function get(data: any) {
    return http.get({
        url: import.meta.env.VITE_API_URL_SYSTEM + '/v1/sys/identity/type/get',
        data,
    })
}
