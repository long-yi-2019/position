import http from '@/utils/http'

/**
 * 保存通知公告接收人
 */
export function save(data: any) {
    return http.post({
        url: import.meta.env.VITE_API_URL_SYSTEM + '/v1/sys/notice/user/save',
        data,
    })
}

/**
 * 修改通知公告接收人
 */
export function edit(data: any) {
    return http.post({
        url: import.meta.env.VITE_API_URL_SYSTEM + '/v1/sys/notice/user/edit',
        data,
    })
}
/**
 * 删除通知公告接收人
 */
export function del(data: any) {
    return http.post({
        url: import.meta.env.VITE_API_URL_SYSTEM + '/v1/sys/notice/user/delete',
        data,
    })
}
/**
 * 根据ID查询通知公告接收人
 */
export function get(data: any) {
    return http.get({
        url: import.meta.env.VITE_API_URL_SYSTEM + '/v1/sys/notice/user/get',
        data,
    })
}

/**
 * 查询我的未读公告数量
 */
export function getMyUnRead(data: any) {
    return http.get({
        url: import.meta.env.VITE_API_URL_SYSTEM + '/v1/sys/notice/user/getMyUnRead',
        data,
    })
}
