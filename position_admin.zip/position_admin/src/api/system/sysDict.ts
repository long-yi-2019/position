import http from '@/utils/Http'
/**
 * 保存数据字典值表
 */
export function save(data: any) {
    return http.post({
        url: import.meta.env.VITE_API_URL_SYSTEM + '/v1/sys/dict/save',
        data,
    })
}

/**
 * 修改数据字典值表
 */
export function edit(data: any) {
    return http.post({
        url: import.meta.env.VITE_API_URL_SYSTEM + '/v1/sys/dict/edit',
        data,
    })
}
/**
 * 删除数据字典值表
 */
export function del(data: any) {
    return http.post({
        url: import.meta.env.VITE_API_URL_SYSTEM + '/v1/sys/dict/delete',
        data,
    })
}
/**
 * 根据ID查询数据字典值表
 */
export function get(data: any) {
    return http.get({
        url: import.meta.env.VITE_API_URL_SYSTEM + '/v1/sys/dict/get',
        data,
    })
}
