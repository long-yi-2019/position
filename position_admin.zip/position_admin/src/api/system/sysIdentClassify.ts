import http from '@/utils/Http'

/**
 * 保存图标库分类
 */
export function save(data: any) {
    return http.post({
        url: import.meta.env.VITE_API_URL_SYSTEM + '/v1/sys/ident/classify/save',
        data,
    })
}

/**
 * 修改图标库分类
 */
export function edit(data: any) {
    return http.post({
        url: import.meta.env.VITE_API_URL_SYSTEM + '/v1/sys/ident/classify/edit',
        data,
    })
}
/**
 * 删除图标库分类
 */
export function del(data: any) {
    return http.post({
        url: import.meta.env.VITE_API_URL_SYSTEM + '/v1/sys/ident/classify/delete',
        data,
    })
}
/**
 * 根据ID查询图标库分类
 */
export function get(data: any) {
    return http.get({
        url: import.meta.env.VITE_API_URL_SYSTEM + '/v1/sys/ident/classify/get',
        data,
    })
}
