import http from '@/utils/Http'

/**
 * 保存系统操作日志
 */
export function save(data: any) {
    return http.post({
        url: import.meta.env.VITE_API_URL_SYSTEM + '/v1/sys/log/oper/save',
        data,
    })
}

/**
 * 修改系统操作日志
 */
export function edit(data: any) {
    return http.post({
        url: import.meta.env.VITE_API_URL_SYSTEM + '/v1/sys/log/oper/edit',
        data,
    })
}
/**
 * 删除系统操作日志
 */
export function del(data: any) {
    return http.post({
        url: import.meta.env.VITE_API_URL_SYSTEM + '/v1/sys/log/oper/delete',
        data,
    })
}
/**
 * 清空系统操作日志
 */
export function clear() {
    return http.post({
        url: import.meta.env.VITE_API_URL_SYSTEM + '/v1/sys/log/oper/clear',
    })
}
/**
 * 根据ID查询系统操作日志
 */
export function get(data: any) {
    return http.get({
        url: import.meta.env.VITE_API_URL_SYSTEM + '/v1/sys/log/oper/get',
        data,
    })
}
