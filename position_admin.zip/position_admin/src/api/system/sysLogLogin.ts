import http from '@/utils/http'

/**
 * 保存系统登录日志
 */
export function save(data: any) {
    return http.post({
        url: import.meta.env.VITE_API_URL_SYSTEM + '/v1/sys/log/login/save',
        data,
    })
}

/**
 * 修改系统登录日志
 */
export function edit(data: any) {
    return http.post({
        url: import.meta.env.VITE_API_URL_SYSTEM + '/v1/sys/log/login/edit',
        data,
    })
}

/**
 * 清空系统操作日志
 */
export function clear() {
    return http.post({
        url: import.meta.env.VITE_API_URL_SYSTEM + '/v1/sys/log/login/clear',
    })
}

/**
 * 删除系统登录日志
 */
export function del(data: any) {
    return http.post({
        url: import.meta.env.VITE_API_URL_SYSTEM + '/v1/sys/log/login/delete',
        data,
    })
}
/**
 * 根据ID查询系统登录日志
 */
export function get(data: any) {
    return http.get({
        url: import.meta.env.VITE_API_URL_SYSTEM + '/v1/sys/log/login/get',
        data,
    })
}
