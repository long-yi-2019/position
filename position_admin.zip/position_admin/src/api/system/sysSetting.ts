import http from '@/utils/http'

/**
 * 保存参数设置
 */
export function save(data: any) {
    return http.post({
        url: import.meta.env.VITE_API_URL_SYSTEM + '/v1/sys/setting/save',
        data,
    })
}

/**
 * 修改参数设置
 */
export function edit(data: any) {
    return http.post({
        url: import.meta.env.VITE_API_URL_SYSTEM + '/v1/sys/setting/edit',
        data,
    })
}
/**
 * 删除参数设置
 */
export function del(data: any) {
    return http.post({
        url: import.meta.env.VITE_API_URL_SYSTEM + '/v1/sys/setting/delete',
        data,
    })
}
/**
 * 根据ID查询参数设置
 */
export function get(data: any) {
    return http.get({
        url: import.meta.env.VITE_API_URL_SYSTEM + '/v1/sys/setting/get',
        data,
    })
}

/**
 * 根据Key查询参数设置
 */
export function getByKey(data: any) {
    return http.get({
        url: import.meta.env.VITE_API_URL_SYSTEM + '/v1/sys/setting/getByKey',
        data,
    })
}
