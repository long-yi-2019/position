import http from '@/utils/Http'

/**
 * 保存用户表
 */
export function save(data: any) {
    return http.post({
        url: import.meta.env.VITE_API_URL_SYSTEM + '/v1/sys/user/save',
        data,
    })
}

/**
 * 修改用户表
 */
export function edit(data: any) {
    return http.post({
        url: import.meta.env.VITE_API_URL_SYSTEM + '/v1/sys/user/edit',
        data,
    })
}
/**
 * 删除用户表
 */
export function del(data: any) {
    return http.post({
        url: import.meta.env.VITE_API_URL_SYSTEM + '/v1/sys/user/delete',
        data,
    })
}
/**
 * 根据ID查询用户表
 */
export function get(data: any) {
    return http.get({
        url: import.meta.env.VITE_API_URL_SYSTEM + '/v1/sys/user/get',
        data,
    })
}

/**
 * 根据ID查询用户表
 */
export function getListByKeyword(data: any) {
    return http.get({
        url: import.meta.env.VITE_API_URL_SYSTEM + '/v1/sys/user/getListByKeyword',
        data,
    })
}

/**
 * 根据ID查询设备仪器库
 */
export function getByName(data: any) {
    return http.get({
        url: import.meta.env.VITE_API_URL_SYSTEM + '/v1/sys/user/getByName',
        data,
    })
}
/**
 * 根据ID查询个人资料
 */
export function getInfo(data: any) {
    return http.get({
        url: import.meta.env.VITE_API_URL_SYSTEM + '/v1/sys/user/getInfo',
        data,
    })
}

/**
 * 修改密码
 * @param data
 */
export function updPass(data: any) {
    return http.post({
        url: import.meta.env.VITE_API_URL_SYSTEM + '/v1/sys/user/updPass',
        data,
    })
}

/**
 * 记录最近访问
 * @param data
 */
export function latelyRouter(data: any) {
    return http.post({
        url: import.meta.env.VITE_API_URL_SYSTEM + '/v1/sys/user/latelyRouter',
        data,
        showError: false,
    })
}

/**
 * 记录最近访问
 * @param data
 */
export function getLatelyRouter() {
    return http.get({
        url: import.meta.env.VITE_API_URL_SYSTEM + '/v1/sys/user/latelyRouter',
    })
}
