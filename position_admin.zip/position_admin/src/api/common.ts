import http from '@/utils/Http'

/**
 * 请求数据列表
 */
export function getList(url: string, data?: any) {
    return http.get({
        url,
        data,
    })
}

/**
 * 文件上传
 */
export function uploadFile(file: any, data?: any) {
    return http.upload({
        url: import.meta.env.VITE_API_URL_UPLOAD,
        file,
        data,
    })
}

/**
 * get请求
 * @param url
 * @param data
 */
export function get(url: string, data?: any) {
    return http.get({
        url,
        data,
    })
}
