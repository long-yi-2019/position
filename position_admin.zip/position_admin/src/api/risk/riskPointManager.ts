import http from '@/utils/http'

/**
 * 保存风险点管理
 */
export function save(data: any) {
    return http.post({
        url: import.meta.env.VITE_API_URL_SYSTEM + '/v1/risk/point/manager/save',
        data,
    })
}

/**
 * 修改风险点管理
 */
export function edit(data: any) {
    return http.post({
        url: import.meta.env.VITE_API_URL_SYSTEM + '/v1/risk/point/manager/edit',
        data,
    })
}
/**
 * 删除风险点管理
 */
export function del(data: any) {
    return http.post({
        url: import.meta.env.VITE_API_URL_SYSTEM + '/v1/risk/point/manager/delete',
        data,
    })
}
/**
 * 根据ID查询风险点管理
 */
export function get(data: any) {
    return http.get({
        url: import.meta.env.VITE_API_URL_SYSTEM + '/v1/risk/point/manager/get',
        data,
    })
}
