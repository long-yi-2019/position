import http from '@/utils/Http'

/**
 * 登录
 * @param data
 */
export function login(data: any) {
    return http.post({
        url: import.meta.env.VITE_API_URL_SYSTEM + '/v1/sys/login',
        data,
    })
}

/**
 * 获取用户路由
 * @param data
 */
export function getMyRouter(data: any) {
    return http.get({
        url: import.meta.env.VITE_API_URL_SYSTEM + '/v1/sys/getMyRouter',
        data,
        showError: false,
    })
}
