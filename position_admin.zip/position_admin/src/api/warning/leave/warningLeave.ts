import http from '@/utils/http'

/**
 * 保存离岗限制
 */
export function save(data: any) {
    return http.post({
        url: import.meta.env.VITE_API_URL_SYSTEM + '/v1/warning/leave/save',
        data,
    })
}

/**
 * 修改离岗限制
 */
export function edit(data: any) {
    return http.post({
        url: import.meta.env.VITE_API_URL_SYSTEM + '/v1/warning/leave/edit',
        data,
    })
}
/**
 * 删除离岗限制
 */
export function del(data: any) {
    return http.post({
        url: import.meta.env.VITE_API_URL_SYSTEM + '/v1/warning/leave/delete',
        data,
    })
}
/**
 * 根据ID查询离岗限制
 */
export function get(data: any) {
    return http.get({
        url: import.meta.env.VITE_API_URL_SYSTEM + '/v1/warning/leave/get',
        data,
    })
}
