import http from '@/utils/http'

/**
 * 保存移动围栏
 */
export function save(data: any) {
    return http.post({
        url: import.meta.env.VITE_API_URL_SYSTEM + '/v1/warning/move/fence/save',
        data,
    })
}

/**
 * 修改移动围栏
 */
export function edit(data: any) {
    return http.post({
        url: import.meta.env.VITE_API_URL_SYSTEM + '/v1/warning/move/fence/edit',
        data,
    })
}
/**
 * 删除移动围栏
 */
export function del(data: any) {
    return http.post({
        url: import.meta.env.VITE_API_URL_SYSTEM + '/v1/warning/move/fence/delete',
        data,
    })
}
/**
 * 根据ID查询移动围栏
 */
export function get(data: any) {
    return http.get({
        url: import.meta.env.VITE_API_URL_SYSTEM + '/v1/warning/move/fence/get',
        data,
    })
}
