import http from '@/utils/http'

/**
 * 保存滞留警告
 */
export function save(data: any) {
    return http.post({
        url: import.meta.env.VITE_API_URL_SYSTEM + '/v1/warning/stay/save',
        data,
    })
}

/**
 * 修改滞留警告
 */
export function edit(data: any) {
    return http.post({
        url: import.meta.env.VITE_API_URL_SYSTEM + '/v1/warning/stay/edit',
        data,
    })
}
/**
 * 删除滞留警告
 */
export function del(data: any) {
    return http.post({
        url: import.meta.env.VITE_API_URL_SYSTEM + '/v1/warning/stay/delete',
        data,
    })
}
/**
 * 根据ID查询滞留警告
 */
export function get(data: any) {
    return http.get({
        url: import.meta.env.VITE_API_URL_SYSTEM + '/v1/warning/stay/get',
        data,
    })
}
