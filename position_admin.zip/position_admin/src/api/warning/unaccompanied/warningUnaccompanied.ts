import http from '@/utils/http'

/**
 * 保存无陪同警告

 */
export function save(data: any) {
    return http.post({
        url: import.meta.env.VITE_API_URL_SYSTEM + '/v1/warning/unaccompanied/save',
        data,
    })
}

/**
 * 修改无陪同警告

 */
export function edit(data: any) {
    return http.post({
        url: import.meta.env.VITE_API_URL_SYSTEM + '/v1/warning/unaccompanied/edit',
        data,
    })
}
/**
 * 删除无陪同警告

 */
export function del(data: any) {
    return http.post({
        url: import.meta.env.VITE_API_URL_SYSTEM + '/v1/warning/unaccompanied/delete',
        data,
    })
}
/**
 * 根据ID查询无陪同警告

 */
export function get(data: any) {
    return http.get({
        url: import.meta.env.VITE_API_URL_SYSTEM + '/v1/warning/unaccompanied/get',
        data,
    })
}
