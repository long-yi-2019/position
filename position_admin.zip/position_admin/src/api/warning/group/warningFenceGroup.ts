import http from '@/utils/http'

/**
 * 保存围栏联组任务
 */
export function save(data: any) {
    return http.post({
        url: import.meta.env.VITE_API_URL_SYSTEM + '/v1/warning/fence/group/save',
        data,
    })
}

/**
 * 修改围栏联组任务
 */
export function edit(data: any) {
    return http.post({
        url: import.meta.env.VITE_API_URL_SYSTEM + '/v1/warning/fence/group/edit',
        data,
    })
}
/**
 * 删除围栏联组任务
 */
export function del(data: any) {
    return http.post({
        url: import.meta.env.VITE_API_URL_SYSTEM + '/v1/warning/fence/group/delete',
        data,
    })
}
/**
 * 根据ID查询围栏联组任务
 */
export function get(data: any) {
    return http.get({
        url: import.meta.env.VITE_API_URL_SYSTEM + '/v1/warning/fence/group/get',
        data,
    })
}
