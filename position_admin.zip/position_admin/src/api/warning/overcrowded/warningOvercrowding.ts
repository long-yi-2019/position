import http from '@/utils/http'

/**
 * 保存区域超员警告

 */
export function save(data: any) {
    return http.post({
        url: import.meta.env.VITE_API_URL_SYSTEM + '/v1/warning/overcrowding/save',
        data,
    })
}

/**
 * 修改区域超员警告

 */
export function edit(data: any) {
    return http.post({
        url: import.meta.env.VITE_API_URL_SYSTEM + '/v1/warning/overcrowding/edit',
        data,
    })
}
/**
 * 删除区域超员警告

 */
export function del(data: any) {
    return http.post({
        url: import.meta.env.VITE_API_URL_SYSTEM + '/v1/warning/overcrowding/delete',
        data,
    })
}
/**
 * 根据ID查询区域超员警告

 */
export function get(data: any) {
    return http.get({
        url: import.meta.env.VITE_API_URL_SYSTEM + '/v1/warning/overcrowding/get',
        data,
    })
}
