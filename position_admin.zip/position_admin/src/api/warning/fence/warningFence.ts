import http from '@/utils/http'

/**
 * 保存电子围栏
 */
export function save(data: any) {
    return http.post({
        url: import.meta.env.VITE_API_URL_SYSTEM + '/v1/warning/fence/save',
        data,
    })
}

/**
 * 修改电子围栏
 */
export function edit(data: any) {
    return http.post({
        url: import.meta.env.VITE_API_URL_SYSTEM + '/v1/warning/fence/edit',
        data,
    })
}
/**
 * 删除电子围栏
 */
export function del(data: any) {
    return http.post({
        url: import.meta.env.VITE_API_URL_SYSTEM + '/v1/warning/fence/delete',
        data,
    })
}
/**
 * 根据ID查询电子围栏
 */
export function get(data: any) {
    return http.get({
        url: import.meta.env.VITE_API_URL_SYSTEM + '/v1/warning/fence/get',
        data,
    })
}
