import http from '@/utils/http'

/**
 * 保存超速告警
 */
export function save(data: any) {
    return http.post({
        url: import.meta.env.VITE_API_URL_SYSTEM + '/v1/warning/speeding/save',
        data,
    })
}

/**
 * 修改超速告警
 */
export function edit(data: any) {
    return http.post({
        url: import.meta.env.VITE_API_URL_SYSTEM + '/v1/warning/speeding/edit',
        data,
    })
}
/**
 * 删除超速告警
 */
export function del(data: any) {
    return http.post({
        url: import.meta.env.VITE_API_URL_SYSTEM + '/v1/warning/speeding/delete',
        data,
    })
}
/**
 * 根据ID查询超速告警
 */
export function get(data: any) {
    return http.get({
        url: import.meta.env.VITE_API_URL_SYSTEM + '/v1/warning/speeding/get',
        data,
    })
}
