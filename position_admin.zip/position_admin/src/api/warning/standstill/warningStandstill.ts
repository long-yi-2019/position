import http from '@/utils/http'

/**
 * 保存静止超时
 */
export function save(data: any) {
    return http.post({
        url: import.meta.env.VITE_API_URL_SYSTEM + '/v1/warning/standstill/save',
        data,
    })
}

/**
 * 修改静止超时
 */
export function edit(data: any) {
    return http.post({
        url: import.meta.env.VITE_API_URL_SYSTEM + '/v1/warning/standstill/edit',
        data,
    })
}
/**
 * 删除静止超时
 */
export function del(data: any) {
    return http.post({
        url: import.meta.env.VITE_API_URL_SYSTEM + '/v1/warning/standstill/delete',
        data,
    })
}
/**
 * 根据ID查询静止超时
 */
export function get(data: any) {
    return http.get({
        url: import.meta.env.VITE_API_URL_SYSTEM + '/v1/warning/standstill/get',
        data,
    })
}
