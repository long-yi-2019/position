import http from '@/utils/http'

/**
 * 保存巡检点
 */
export function save(data: any) {
    return http.post({
        url: import.meta.env.VITE_API_URL_SYSTEM + '/v1/inspectio/points/save',
        data,
    })
}

/**
 * 修改巡检点
 */
export function edit(data: any) {
    return http.post({
        url: import.meta.env.VITE_API_URL_SYSTEM + '/v1/inspectio/points/edit',
        data,
    })
}
/**
 * 删除巡检点
 */
export function del(data: any) {
    return http.post({
        url: import.meta.env.VITE_API_URL_SYSTEM + '/v1/inspectio/points/delete',
        data,
    })
}
/**
 * 根据ID查询巡检点
 */
export function get(data: any) {
    return http.get({
        url: import.meta.env.VITE_API_URL_SYSTEM + '/v1/inspectio/points/get',
        data,
    })
}
