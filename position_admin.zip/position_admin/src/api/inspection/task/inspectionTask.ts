import http from '@/utils/http'

/**
 * 保存巡检任务
 */
export function save(data: any) {
    return http.post({
        url: import.meta.env.VITE_API_URL_SYSTEM + '/v1/inspection/task/save',
        data,
    })
}

/**
 * 修改巡检任务
 */
export function edit(data: any) {
    return http.post({
        url: import.meta.env.VITE_API_URL_SYSTEM + '/v1/inspection/task/edit',
        data,
    })
}
/**
 * 删除巡检任务
 */
export function del(data: any) {
    return http.post({
        url: import.meta.env.VITE_API_URL_SYSTEM + '/v1/inspection/task/delete',
        data,
    })
}
/**
 * 根据ID查询巡检任务
 */
export function get(data: any) {
    return http.get({
        url: import.meta.env.VITE_API_URL_SYSTEM + '/v1/inspection/task/get',
        data,
    })
}
/**
 * 根据ID查询部门
 */
export function getTree(data: any) {
    return http.get({
        url: import.meta.env.VITE_API_URL_SYSTEM + '/v1/inspection/task/getTree',
        data,
    })
}
