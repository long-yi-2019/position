import http from '@/utils/http'

/**
 * 保存巡检路线
 */
export function save(data: any) {
    return http.post({
        url: import.meta.env.VITE_API_URL_SYSTEM + '/v1/inspection/route/save',
        data,
    })
}

/**
 * 修改巡检路线
 */
export function edit(data: any) {
    return http.post({
        url: import.meta.env.VITE_API_URL_SYSTEM + '/v1/inspection/route/edit',
        data,
    })
}
/**
 * 删除巡检路线
 */
export function del(data: any) {
    return http.post({
        url: import.meta.env.VITE_API_URL_SYSTEM + '/v1/inspection/route/delete',
        data,
    })
}
/**
 * 根据ID查询巡检路线
 */
export function get(data: any) {
    return http.get({
        url: import.meta.env.VITE_API_URL_SYSTEM + '/v1/inspection/route/get',
        data,
    })
}
