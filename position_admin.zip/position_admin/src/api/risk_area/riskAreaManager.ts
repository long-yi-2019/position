import http from '@/utils/http'

/**
 * 保存风险区域管理
 */
export function save(data: any) {
    return http.post({
        url: import.meta.env.VITE_API_URL_SYSTEM + '/v1/risk/area/manager/save',
        data,
    })
}

/**
 * 修改风险区域管理
 */
export function edit(data: any) {
    return http.post({
        url: import.meta.env.VITE_API_URL_SYSTEM + '/v1/risk/area/manager/edit',
        data,
    })
}
/**
 * 删除风险区域管理
 */
export function del(data: any) {
    return http.post({
        url: import.meta.env.VITE_API_URL_SYSTEM + '/v1/risk/area/manager/delete',
        data,
    })
}
/**
 * 根据ID查询风险区域管理
 */
export function get(data: any) {
    return http.get({
        url: import.meta.env.VITE_API_URL_SYSTEM + '/v1/risk/area/manager/get',
        data,
    })
}
