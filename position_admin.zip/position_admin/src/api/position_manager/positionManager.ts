import http from '@/utils/http'

/**
 * 保存岗位管理
 */
export function save(data: any) {
    return http.post({
        url: import.meta.env.VITE_API_URL_SYSTEM + '/v1/position/manager/save',
        data,
    })
}

/**
 * 修改岗位管理
 */
export function edit(data: any) {
    return http.post({
        url: import.meta.env.VITE_API_URL_SYSTEM + '/v1/position/manager/edit',
        data,
    })
}
/**
 * 删除岗位管理
 */
export function del(data: any) {
    return http.post({
        url: import.meta.env.VITE_API_URL_SYSTEM + '/v1/position/manager/delete',
        data,
    })
}
/**
 * 根据ID查询岗位管理
 */
export function get(data: any) {
    return http.get({
        url: import.meta.env.VITE_API_URL_SYSTEM + '/v1/position/manager/get',
        data,
    })
}
