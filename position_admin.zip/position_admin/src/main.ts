import { createApp } from 'vue'
import App from './App.vue'
import '@/utils/PrintAscii'
import Antd from 'ant-design-vue'
import router from './router'
import './permission'
import 'virtual:svg-icons-register'
import '@/assets/css/iconfont.css'
import 'animate.css'
import OpenLayersMap from '@/components/openlayer.vue'

import YxModal from '@liuyunxi/modal'
import '@liuyunxi/modal/lib/style.css'
import YxTree from '@liuyunxi/tree'
import '@liuyunxi/tree/lib/style.css'
import YxPictureViewer from '@liuyunxi/picture-viewer'
import '@liuyunxi/picture-viewer/lib/style.css'
import YxPdfViewer from '@liuyunxi/viewer-pdf'
import '@liuyunxi/viewer-pdf/lib/style.css'
import YxOfficeViewer from '@liuyunxi/office-viewer'
import '@liuyunxi/office-viewer/lib/style.css'
import YxVideoViewer from '@liuyunxi/viewer-video'
import '@liuyunxi/viewer-video/lib/style.css'
import YxCaptcha from '@liuyunxi/captcha'
import '@liuyunxi/captcha/lib/style.css'
import YxSearch from '@liuyunxi/search-bar'
import '@liuyunxi/search-bar/lib/style.css'
import YxTable from '@liuyunxi/table'
import '@liuyunxi/table/lib/style.css'
import YxDatePicker from '@liuyunxi/date-picker'
import YxRichText from '@liuyunxi/rich-text'
import '@liuyunxi/rich-text/lib/style.css'
import YxUpload from '@liuyunxi/upload'
import '@liuyunxi/upload/lib/style.css'

import MyPagination from '@/components/MyPagination.vue'
import MyTablePage from '@/components/MyTablePage.vue'
import MyTreeTablePage from '@/components/MyTreeTablePage.vue'
import PageWrapper from '@/layouts/PageWrapper.vue'
import YxSvgIcon from './components/SvgIcon/YxSvgIcon.vue'

import { getPermissionStore } from '@/store'
const permissionStore = getPermissionStore()

const app = createApp(App)
app.component('OpenLayersMap', OpenLayersMap)
app.use(Antd)
    .use(YxTree)
    .use(YxModal)
    .use(YxPdfViewer)
    .use(YxOfficeViewer)
    .use(YxVideoViewer)
    .use(YxPictureViewer)
    .use(YxCaptcha)
    .use(YxSearch)
    .use(YxTable)
    .use(YxDatePicker)
    .use(YxRichText)
    .use(YxUpload)
    .use(router)
    .component('YxSvgIcon', YxSvgIcon)
    .component('MyPagination', MyPagination)
    .component('MyTablePage', MyTablePage)
    .component('MyTreeTablePage', MyTreeTablePage)
    .component('PageWrapper', PageWrapper)
    .mount('#app')

app.directive('permission', {
    mounted(el, binding) {
        if (!permissionStore.h(binding.value)) {
            el.parentNode && el.parentNode.removeChild(el)
        }
    },
})
