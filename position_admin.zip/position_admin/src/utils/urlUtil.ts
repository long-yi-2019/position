/**
 * 获取url路径参数
 * @param str
 */
export function getQueryParam(str = window.location.search): any {
    const reg = /([^?&=]+)=([^&]+)/g // 分组捕获 两个子组
    const params = {}
    str.replace(reg, (_, k, v) => (params[k] = v))
    return params
}
