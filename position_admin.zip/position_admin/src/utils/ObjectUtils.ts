import { cloneDeep } from 'lodash-es'

/**
 * 向左侧覆盖数据
 */
export function leftCover(target: any, source: any) {
    const newSource = Object.assign({}, source)
    for (const key in target) {
        if (newSource[key]) {
            target[key] = newSource[key]
        }
    }
    return cloneDeep(target)
}
/**
 * 合并数据
 */
export function assignIn(target: any, source: any) {
    return Object.assign(target, source)
}
