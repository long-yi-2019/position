import { ColInfo, RowInfo, utils, writeFile } from 'xlsx'
class ExcelUtil {
    private readonly column: any[]
    private readonly data: any[]
    private readonly name: string

    constructor(column: any[], data: any[], name: string) {
        this.column = column
        this.data = data
        this.name = name
    }
    export() {
        const data = [] as any[]
        const wsColumnInfoArray = [] as ColInfo[]
        const wsRowInfoArray = [
            {
                hpx: 20, //行高
            },
        ] as RowInfo[]

        this.data.forEach((d) => {
            wsRowInfoArray.push({ hpx: 20 })
            const obj = {} as any
            const column = this.column.filter((c) => c.hidden !== true)
            column.forEach((c) => {
                wsColumnInfoArray.push({
                    wpx: c.width || 150, //列宽
                })
                if (c.formatter?.type === 'text' || c.formatter?.type === 'tag') {
                    obj[c.title] = c.formatter?.format(d).value
                } else if (c.formatter?.type === 'select') {
                    const values = c.formatter?.format(d).value
                    const value = d[c.dataIndex]
                    const v = values.filter((v: any) => v.value === value)
                    if (v.length > 0) {
                        obj[c.title] = v[0].label
                    } else {
                        obj[c.title] = value
                    }
                } else if (c.formatter?.type === 'file' || c.formatter?.type === 'video') {
                    const values = c.formatter?.format(d)
                    obj[c.title] = values.map((v: any) => v.url).join(',')
                } else if (c.formatter?.type === 'image') {
                    const values = c.formatter?.format(d)
                    obj[c.title] = values.map((v: any) => v.src).join(',')
                } else {
                    obj[c.title] = d[c.dataIndex]
                }
            })
            data.push(obj)
        })
        const worksheet = utils.json_to_sheet(data)
        const workbook = utils.book_new()
        worksheet['!cols'] = wsColumnInfoArray
        worksheet['!rows'] = wsRowInfoArray
        utils.book_append_sheet(workbook, worksheet, 'Sheet1')
        writeFile(workbook, this.name + '.xlsx')
    }
}

export default ExcelUtil
