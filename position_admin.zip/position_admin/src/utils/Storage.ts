interface StoreVal {
    value: any
    expire: number
}

export function set(k: string, v: any, expire?: number): void {
    if (expire != undefined && expire !== -1) {
        expire = new Date().getTime() + expire
    }
    const valueObj: StoreVal = {
        value: v,
        expire: expire || -1,
    }
    localStorage.setItem(k, JSON.stringify(valueObj))
}

export function get(k: string) {
    try {
        const v = localStorage.getItem(k)
        if (v) {
            const valueObj: StoreVal = JSON.parse(v) as StoreVal
            const expire = valueObj.expire
            if (expire != -1) {
                const nowTime = new Date().getTime()
                if (nowTime > expire) {
                    localStorage.removeItem(k)
                    return null
                }
            }
            return valueObj.value
        }
    } catch (e) {
        return null
    }
    return null
}

export function remove(k: string): void {
    localStorage.removeItem(k)
}

export function clear(): void {
    localStorage.clear()
}
