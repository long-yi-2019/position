/**
 * 获取屏幕dpi
 */
export function getDpi() {
    const div = document.createElement('div')
    div.style.cssText = 'height: 1in; left: -100%; position: absolute; top: -100%; width: 1in;'
    document.body.appendChild(div)
    const devicePixelRatio = window.devicePixelRatio || 1
    const dpi = div.offsetWidth * devicePixelRatio
    document.body.removeChild(div)
    return dpi
}

/**
 * 获取屏幕毫米对应的像素值
 */
export function mm2Px(mm: number) {
    const div = document.createElement('div')
    div.style.width = mm + 'mm'
    document.body.appendChild(div)
    const d = div.getBoundingClientRect()
    const px = d.width
    document.body.removeChild(div)
    return px
}

/**
 * 指定dpi毫米转像素
 * 象素数/ DPI = 英寸数；
 * 英寸数 * 25.4 = 毫米数；
 */
export function mm2PxByDpi(mm: number, dpi: number) {
    return (mm / 25.4) * dpi
}

/**
 * 指定dpi像素转毫米
 */
export function px2MmByDpi(px: number, dpi: number) {
    return (px / dpi) * 25.4
}
