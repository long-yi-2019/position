/**
 * 求百分比，保留两位小数点 n1/n2
 * @param n1
 * @param n2
 */
export function toRate(n1: number, n2: number) {
    try {
        const num = (n1 / n2) * 10000
        return Math.round(num) / 100 || '-'
    } catch (e) {
        return '-'
    }
}
