/**
 * 日期工具类
 */
import dayjs from 'dayjs'
class DateUtils {
    /**
     * 日期格式化
     * @param date
     * @param fmt
     */
    formatDate(date: any, fmt: string): string {
        try {
            // @ts-ignore
            if (!(date instanceof Date)) {
                date = new Date(date)
            }
            if (fmt === undefined || fmt === '') {
                fmt = 'yyyy-MM-dd hh:mm:ss'
            }
            if (/(y+)/.test(fmt)) {
                fmt = fmt.replace(RegExp.$1, (date.getFullYear() + '').substr(4 - RegExp.$1.length))
            }
            const o = {
                'M+': date.getMonth() + 1,
                'd+': date.getDate(),
                'h+': date.getHours(),
                'm+': date.getMinutes(),
                's+': date.getSeconds(),
            }
            for (const k in o) {
                if (new RegExp(`(${k})`).test(fmt)) {
                    const str = o[k] + ''
                    fmt = fmt.replace(
                        RegExp.$1,
                        RegExp.$1.length === 1 ? str : this.padLeftZero(str),
                    )
                }
            }
            return fmt
        } catch (e) {
            console.log(e)
            return '-'
        }
    }
    padLeftZero(str): string {
        return ('00' + str).substr(str.length)
    }

    /**
     * 判断当前时间是否在指定日期之后
     * @param dateStr
     */
    isNowAfter(dateStr): boolean {
        return dayjs().isBefore(dayjs(dateStr))
    }
}

export default new DateUtils()
