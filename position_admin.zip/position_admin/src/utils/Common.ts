/**
 * 常量
 */
import * as tokenUtil from '@/utils/tokenUtil'
import { message } from 'ant-design-vue'
import dayjs, { Dayjs } from 'dayjs'
const cosUrl = import.meta.env.VITE_API_URL_STATIC

export function sexStr(sex: string) {
    if (sex == '1') {
        return '男'
    } else if (sex == '0') {
        return '女'
    } else {
        return '未知'
    }
}

/**
 * 通过身份证解析生日
 * @param sex
 */
export function getBirthday(idCard: string) {
    try {
        const birth =
            idCard.substring(6, 10) +
            '-' +
            idCard.substring(10, 12) +
            '-' +
            idCard.substring(12, 14)
        return birth
    } catch (e) {
        return ''
    }
}

/**
 * 通过身份证解析性别
 * @param idCard
 */
export function getSex(idCard: string) {
    try {
        //获取性别
        if (parseInt(idCard.substring(17, 18)) % 2 == 0) {
            return '0'
        } else {
            return '1'
        }
    } catch (e) {
        return '-1'
    }
}

/**
 * 判断是否为移动设备
 */
export function isMobileDevice() {
    const ua = navigator.userAgent.toLowerCase()
    const t1 = /android|webos|iphone|ipad|ipod|blackberry|iemobile|opera mini/i.test(ua)
    const t2 = !ua.match('iphone') && navigator.maxTouchPoints > 1
    return t1 || t2
}

/**
 * 文件下载
 * @param url 文件地址
 * @param name 文件名称
 * @param hasToken
 */
interface options {
    useToken: boolean
    success?: Function
}
export function downLoad(url: string, name: string, config?: options) {
    const hide = message.loading('正在下载..', 0)
    const headers = {}
    if (config?.useToken) {
        const tokenHeader = tokenUtil.getTokenHeader()
        if (tokenHeader !== null) {
            Object.assign(headers, tokenHeader)
        }
    }
    fetch(url, { headers })
        .then((res) =>
            res.blob().then((blob) => {
                const a = document.createElement('a')
                const url = window.URL.createObjectURL(blob)
                a.href = url
                a.download = name
                a.click()
                window.URL.revokeObjectURL(url)
                setTimeout(() => {
                    hide()
                }, 1000)
            }),
        )
        .catch(() => {
            hide()
            message.error('服务器繁忙，请稍后重试！').then()
        })
}

/**
 * 文件上传
 */
export function uploadFile(file, url, config?: options) {
    const hide = message.loading('正在上传..', 0)
    const formData = new FormData()
    formData.append('file', file)

    const xhr = new XMLHttpRequest()
    xhr.open('POST', url)

    const headers = {}
    if (config?.useToken) {
        const tokenHeader = tokenUtil.getTokenHeader()
        if (tokenHeader !== null) {
            Object.assign(headers, tokenHeader)
        }
    }

    for (const k in headers) {
        xhr.setRequestHeader(k, headers[k])
    }
    xhr.onload = () => {
        hide()

        if (xhr.status !== 200) {
            message.error('系统繁忙，请稍后重试！')
            return
        }
        const res = JSON.parse(xhr.response)
        config?.success && config.success(res)
    }
    xhr.onerror = () => {
        message.error('系统繁忙，请稍后重试！')
    }
    xhr.upload.onprogress = () => {}
    xhr.send(formData)
}

/**
 * 字符串转换为字节数组
 * @param s 字符串
 * @constructor
 */
export function s2ab(s) {
    const buf = new ArrayBuffer(s.length)
    const view = new Uint8Array(buf)
    for (let i = 0; i != s.length; ++i) view[i] = s.charCodeAt(i) & 0xff
    return buf
}

/**
 * 字符串转换为Blob
 * @param s
 */
export function s2Blob(s) {
    return new Blob([s2ab(s)])
}

export function welcome() {
    // 获取当前时间
    const timeNow = new Date()
    // 获取当前小时
    const hours = timeNow.getHours()
    // 设置默认文字
    let text = ``
    // 判断当前时间段
    if (hours >= 0 && hours <= 10) {
        text = `早上好`
    } else if (hours > 10 && hours <= 14) {
        text = `中午好`
    } else if (hours > 14 && hours <= 18) {
        text = `下午好`
    } else if (hours > 18 && hours <= 24) {
        text = `晚上好`
    }
    // 返回当前时间段对应的状态
    return text
}

/* 判断是否为空 */
export function isEmpty(item) {
    if (item === undefined || item === null || item === '' || isOnlyWhitespace(item)) {
        return true
    }
    return false
}
/* 判断是否只有空字符 */
export function isOnlyWhitespace(str: string): boolean {
    try {
        // 使用正则表达式移除空白字符
        const trimmedStr: string = String(str).replace(/\s/g, '')
        // 检查剩余内容的长度是否为零
        return trimmedStr.length === 0
    } catch (e) {
        return true
    }
}

/* 判断是否为空 */
export function isNotEmpty(item) {
    return !isEmpty(item)
}
/**
 * 通用映射
 * @param fieldData 当前行格式化数据
 * @param property {1:"开启":,2:"关闭"}
 */
export function parseField(fieldData, property) {
    let end = '-'
    if (isEmpty(fieldData)) {
        return end
    } else {
        if (typeof fieldData !== 'string') {
            // 转换成string
            fieldData += ''
        }
    }
    if (property instanceof Object) {
        Object.keys(property).forEach((key?: any) => {
            if (typeof key !== 'string') {
                key += ''
            }
            if (key === fieldData) {
                end = property[key]
            }
        })
        return end
    } else {
        throw new Error('property is not a Object')
    }
}

/**
 * 通用格式化图片 默认返回数组第一个图片
 * @param fieldData 当前行格式化图片数据string类型 数组
 * @param property {1:"开启":,2:"关闭"}
 * @return { src:'x' , name:'x' }
 */
export function parseImage(fieldData) {
    const end = { src: '/noImage.png', name: '暂无图片' }
    if (isEmpty(fieldData)) {
        return [end]
    } else {
        if (typeof fieldData !== 'string') {
            // 转换成string
            throw new Error('property is not a string')
        }
    }
    try {
        const parse = JSON.parse(fieldData)
        if (parse.length > 0) {
            const tmp: any = []
            parse.forEach((item) => {
                tmp.push({
                    src: cosUrl + item.path,
                    name: cosUrl + item.name,
                })
            })
            return tmp
        }
        return [end]
    } catch (e) {
        throw new Error('Can not format')
    }
}

// @ts-ignore
/**
 * 计算默认学年
 */
export function getNowSchoolYear(isDayjs = false, ...years: any[]): any[] {
    const fmt = 'YYYY-MM-DD'
    const nowYear = dayjs(new Date()).year()
    const r: any[] = []
    if (isEmpty(years) || years.length === 0) {
        years = [nowYear]
    }
    years.forEach((i: number) => {
        const ti = dayjs().year(Number(i))
        const nowYear: Dayjs = ti.month(7).endOf('month')
        const previousYear: Dayjs = nowYear.subtract(1, 'year').add(1, 'month').startOf('month')
        if (isDayjs) {
            r.push([previousYear, nowYear])
        } else {
            r.push([previousYear.format(fmt), nowYear.format(fmt)])
        }
    })
    return r
}
