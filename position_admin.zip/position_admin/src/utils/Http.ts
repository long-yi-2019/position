import axios, { AxiosInstance } from 'axios'
import { message, Modal } from 'ant-design-vue'
import { close, start } from '@/utils/Nprogress'
import * as tokenUtil from '@/utils/tokenUtil'
/**
 * axios拦截器
 */
class Http {
    private instance: AxiosInstance
    private showError = true //是否主动显示错误弹窗
    private progress = true //是否显示请求进度条
    constructor() {
        // 创建axios实例
        this.instance = axios.create({
            baseURL: '',
            timeout: 30000,
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
        })
        // 初始化拦截器
        this.RequestInterceptor()
        //  初始化响应拦截器
        this.ResponseInterceptor()
    }

    /**
     * get请求
     * @param url
     * @param data
     * @param showError 是否显示错误弹窗
     * @param progress
     */
    public get({
        url,
        data,
        showError,
        progress,
    }: {
        url: string
        data?: any
        showError?: boolean
        progress?: boolean
    }) {
        if (showError == undefined) {
            this.showError = true
        } else {
            this.showError = showError
        }
        if (progress == undefined) {
            this.progress = true
        } else {
            this.progress = progress
        }
        return this.instance.request({
            method: 'get', // 默认值
            url,
            params: data,
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
        })
    }

    /**
     * post 请求
     * @param url
     * @param data
     * @param showError 是否显示错误弹窗
     * @param progress
     */
    public post({
        url,
        data,
        showError,
        progress,
    }: {
        url: string
        data?: any
        showError?: boolean
        progress?: boolean
    }) {
        if (showError == undefined) {
            this.showError = true
        } else {
            this.showError = showError
        }
        if (progress == undefined) {
            this.progress = true
        } else {
            this.progress = progress
        }
        return this.instance.request({
            method: 'post', // 默认值
            url,
            data,
            headers: {
                'Content-Type': 'application/json',
            },
        })
    }

    /**
     * upload 请求
     * @param url
     * @param file
     * @param data
     * @param showError 是否显示错误弹窗
     */
    public upload({
        url,
        file,
        data,
        showError,
    }: {
        url: string
        file: any
        data?: any
        showError?: boolean
    }) {
        const formData = new FormData()
        formData.append('file', file)
        if (data) {
            for (const d in data) {
                formData.append(d, data[d])
            }
        }
        if (showError == undefined) {
            this.showError = true
        } else {
            this.showError = showError
        }
        return this.instance.request({
            method: 'post', // 默认值
            url,
            data: formData,
            headers: {
                'Content-Type': 'multipart/form-data;boundary=' + new Date().getTime(),
            },
        })
    }

    /**
     * 请求拦截器
     * @constructor
     * @private
     */
    private RequestInterceptor() {
        this.instance.interceptors.request.use(
            (config) => {
                if (this.progress) {
                    start()
                }
                // 在发送请求之前做些什么
                if (!config.headers) {
                    config.headers = {} as any
                }
                const tokenHeader = tokenUtil.getTokenHeader()
                if (tokenHeader) {
                    Object.assign(config.headers, tokenHeader)
                }
                return config
            },
            (error) => {
                close()
                console.log('请求错误！', error)
                return Promise.reject(error)
            },
        )
    }

    /**
     * 响应拦截器
     * @constructor
     * @private
     */
    private ResponseInterceptor() {
        this.instance.interceptors.response.use(
            (response) => {
                close()
                const freshToken = response.headers['fresh-token']
                if (freshToken) {
                    // const freshTokenJSON = JSON.parse(freshToken)
                    tokenUtil.setToken(freshToken)
                }
                const { data } = response
                /* 200响应提示 */
                if (data.code !== 1) {
                    console.log('response:{}', response)
                    // 响应200 ，code=0 ，标记业务处理失败的请求
                    if (this.showError && data.code === 0) {
                        Modal.error({
                            title: '提示',
                            content: data.msg || data.message || '请求失败',
                        })
                    }
                }
                return data
            },
            (error) => {
                close()
                this.ResponseErrorHandel(error)
                return Promise.reject(error)
            },
        )
    }

    /**
     * 响应错误处理
     * @param error
     * @constructor
     * @private
     */
    private ResponseErrorHandel(error: any) {
        const errorCode = error.response?.status
        console.log(error)
        if (!this.showError) {
            return
        }
        /*权限问题直接去登录，*/
        if (errorCode === 401) {
            // Modal.error({
            //     title: '警告',
            //     content: (error.msg || error.response.data.msg || '未授权(401)'),
            //     onOk() {
            //         window.location.href = '/login'
            //     },
            // })
            const msg = error.msg || error.response.data.msg || '未授权(401)。'
            message.error(msg).then(() => {
                setTimeout(() => {
                    // window.location.href = import.meta.env.VITE_BASE_URL + '/login'
                    window.location.href = import.meta.env.VITE_PAGE_LOGIN
                }, 2000)
            })
            return
        }

        /*其他问题错误提示*/
        if (errorCode === 'ERR_NETWORK') {
            error.message = '网络异常，请检查网络连接情况！' + `[${error.config?.url}]`
        } else if (errorCode === 'ECONNABORTED') {
            error.message = '请求超时，请检查网络连接情况！' + `[${error.config?.url}]`
        } else if (errorCode === 500) {
            error.message = error.msg || '网络繁忙'
        } else if (errorCode === 404) {
            error.message = error.msg || '请求出错(404)'
        }

        error.message += `[${error.request?.responseURL}]`
        Modal.error({
            title: '错误提示',
            content: `[${errorCode}]${error.message}`,
        })

        // switch (errorCode) {
        //     case 0:
        //         error.message = error.msg || '请求失败(0)'
        //         break
        //     case 400:
        //         error.message = error.msg || '请求错误(400)'
        //         break
        //     case 401:
        //         error.message = error.msg || error.response.data.msg || '未授权(401)'
        //         break
        //     case 403:
        //         error.message = error.msg || '拒绝访问(403)'
        //         break
        //     case 404:
        //         error.message = error.msg || '请求出错(404)'
        //         break
        //     case 405:
        //         error.message = error.msg || '请求方法不允许(405)'
        //         break
        //     case 408:
        //         error.message = error.msg || '请求超时(408)'
        //         break
        //     case 500:
        //         error.message = error.msg || '服务器错误(500)' + `[${error.request?.responseURL}]`
        //         break
        //     case 501:
        //         error.message = error.msg || '服务未实现(501)' + `[${error.request?.responseURL}]`
        //         break
        //     case 502:
        //         error.message = error.msg || '网络错误(502)' + `[${error.request?.responseURL}]`
        //         break
        //     case 503:
        //         error.message = error.msg || '服务不可用(503)' + `[${error.request?.responseURL}]`
        //         break
        //     case 504:
        //         error.message = error.msg || '网络超时(504)' + `[${error.request?.responseURL}]`
        //         break
        //     case 505:
        //         error.message =
        //             error.msg || 'HTTP版本不受支持(505)' + `[${error.request?.responseURL}]`
        //         break
        //     default:
        //         error.message =
        //             error.msg ||
        //             `网络异常，请截图联系管理员。(${errorCode})!(${
        //                 error.message || error.msg || ''
        //             })` + `[${error.request?.responseURL || ''}]`
        // }

        // error.message += `[${error.request?.responseURL}]`
    }
}

const http = new Http()
export default http
