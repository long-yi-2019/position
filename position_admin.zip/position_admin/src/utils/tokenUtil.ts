const USER_KEY = 'userId' //用户信息
const ACCESS_TOKEN_KEY = 'access_token' //token
const ACCESS_TOKEN_HEADER_KEY = 'access_token_header' //token_header
import * as storage from '@/utils/Storage'
// @ts-ignore
import { jwtDecode } from 'jwt-decode'

/**
 * 缓存用户信息
 * @param {Object} val
 */
export function setUser(val: any) {
    storage.set(USER_KEY, val)
}

/** 获取用户信息
 */
export function getUser() {
    return storage.get(USER_KEY)
}

/**
 * 缓存token信息
 * @param {Object} val
 */
export function setToken(val: string) {
    // 缓存token信息
    storage.set(ACCESS_TOKEN_KEY, val)
    // 解析token信息
    const decoded = jwtDecode(val) as any
    const payload = decoded.payload
    // 过期时间payload,freshTime
    // 缓存用户信息
    setUser(JSON.parse(payload.info))
    // 缓存 tokenHeader信息
    const header = {}
    header[payload.k] = val
    storage.set(ACCESS_TOKEN_HEADER_KEY, header)
}

/** 获取token信息
 */
export function getToken() {
    return storage.get(ACCESS_TOKEN_KEY)
}

/** 获取tokenHeader信息
 */
export function getTokenHeader() {
    return storage.get(ACCESS_TOKEN_HEADER_KEY)
}
