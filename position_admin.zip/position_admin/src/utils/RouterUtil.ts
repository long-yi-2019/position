import { RouteRecordRaw } from 'vue-router'
import BlankLayout from '@/layouts/BlankLayout.vue'
import { cloneDeep } from 'lodash-es'

class RouterUtil {
    /**
     * 初始化
     * @param routeAllPathToCompMap（路由数组）
     * @param viewRoot(/src/views)
     */
    private readonly routeAllPathToCompMap
    private readonly viewRoot: string
    constructor(routeAllPathToCompMap, viewRoot: string) {
        this.routeAllPathToCompMap = routeAllPathToCompMap
        this.viewRoot = viewRoot
    }

    /**
     * 路由转换树形
     * @param arr 路由简单数组
     * @param parentId 父ID
     */
    routerListToTree(arr: any[], parentId = '0') {
        const newArr: any[] = []
        arr.forEach((item) => {
            if (item.menuType != 3 && item.parentId === parentId) {
                const router = {
                    name: item.authIdent || item.id,
                    path: item.routeAddress || `/${item.id}`,
                    meta: {
                        title: item.title,
                        icon: item.icons,
                        keepAlive: item.keepAlive === 1,
                        hidden: item.showState === 0,
                        moduleId: item.moduleId,
                    },
                }
                // if (!router.path.startsWith('http')) {
                //     router.path = import.meta.env.BASE_URL + router.path
                // }
                if (item.menuType === 1) {
                    // @ts-ignore
                    router.component = BlankLayout
                } else if (item.menuType === 2) {
                    // @ts-ignore
                    router.component =
                        this.routeAllPathToCompMap[
                            `${this.viewRoot}${item.componentView || item.routeAddress}.vue`
                        ]
                }
                const children = this.routerListToTree(arr, item.id)
                if (item.redirect) {
                    // @ts-ignore
                    router.redirect = item.redirect
                } else {
                    if (children.length > 0) {
                        // @ts-ignore
                        router.redirect = children[0].path
                    }
                }
                newArr.push({
                    ...router,
                    children: children,
                })
            }
        })
        return newArr
    }

    /**
     * 路由转换为一级路由
     * @param routes 路由
     * @param newRoutes
     * @param parents
     */
    routerOneStage(routes: Array<RouteRecordRaw>, newRoutes: any[] = [], parents: any[] = []) {
        routes.forEach((item) => {
            if (item.children && item.children.length > 0) {
                const p = cloneDeep(parents) as any
                p.push(item)
                this.routerOneStage(item.children, newRoutes, p)
                newRoutes.push({
                    name: item.name,
                    path: item.path,
                    meta: {
                        title: item.meta?.title,
                        icon: item.meta?.icon,
                        moduleId: item.meta?.moduleId,
                    },
                    component: item.component,
                    redirect: item.redirect,
                })
            } else {
                // const lastParent = parents[parents.length - 1]
                // const redirect = lastParent.redirect
                newRoutes.push({
                    name: item.name,
                    path: item.path,
                    meta: {
                        title: item.meta?.title,
                        icon: item.meta?.icon,
                        keepAlive: item.meta?.keepAlive,
                        hidden: item.meta?.hidden,
                        moduleId: item.meta?.moduleId,
                        breadcrumb: [
                            ...parents.map((p) => {
                                return {
                                    name: p.meta.title,
                                    path: p.redirect || p.path,
                                    key: p.name,
                                }
                            }),
                        ],
                    },
                    component: item.component,
                })
            }
        })
        return newRoutes
    }
}
export default RouterUtil
