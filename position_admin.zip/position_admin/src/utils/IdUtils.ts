class IdUtils {
    /**
     *  随机生成指定数量的16进制key
     * @param length 生成长度
     */
    random(length: number): string {
        const library = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789'
        let key = ''
        for (let i = 0; i < length; i++) {
            const randomPoz = Math.floor(Math.random() * library.length)
            key += library.substring(randomPoz, randomPoz + 1)
        }
        return key
    }
}

export default new IdUtils()
