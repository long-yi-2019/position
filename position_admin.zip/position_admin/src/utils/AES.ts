import CryptoJS from 'crypto-js'

/**
 * 废弃
 */
class AES {
    private k = '1SqhC8EshUHghyhc'
    private v = 'tubLgbBEovftTEHj'
    /**
     * 加密
     * @param data
     */
    public encode(data: string): string {
        const key = CryptoJS.enc.Utf8.parse(this.k)
        const iv = CryptoJS.enc.Utf8.parse(this.v)
        return CryptoJS.AES.encrypt(data, key, {
            iv,
            mode: CryptoJS.mode.CBC,
            padding: CryptoJS.pad.Pkcs7,
        }).toString()
    }

    /**
     * 解密
     * @param data
     */
    public decode(data: string): string {
        const key = CryptoJS.enc.Utf8.parse(this.k)
        const iv = CryptoJS.enc.Utf8.parse(this.v)
        const encrypted = CryptoJS.AES.decrypt(data, key, {
            iv,
            mode: CryptoJS.mode.CBC,
            padding: CryptoJS.pad.Pkcs7,
        })
        return encrypted.toString(CryptoJS.enc.Utf8)
    }
}
export default new AES()
