/// <reference types="vite/client" />
declare module '*.vue' {
    import type { DefineComponent } from 'vue'
    // eslint-disable-next-line @typescript-eslint/no-explicit-any, @typescript-eslint/ban-types
    const component: DefineComponent<{}, {}, any>
    export default component
}

import 'vue-router'

declare module 'vue-router' {
    interface breadcrumbType {
        name: string
        path: string
        key: string
    }
    interface RouteMeta {
        title: string
        subTitle?: string
        icon?: string
        hidden?: boolean
        keepAlive?: boolean
        breadcrumb?: breadcrumbType[]
    }
}

/**
 * 重写类型定义
 */
import { AxiosRequestConfig, AxiosResponseHeaders } from 'axios'

declare module 'axios' {
    interface AxiosResponse<T = any, D = any> {
        data: T
        status: number
        statusText: string
        headers: AxiosResponseHeaders
        config: AxiosRequestConfig<D>
        request?: any
        code: number
        msg?: string
        total?: number
    }
}
declare module '@liuyunxi/*'

declare global {
    import('cesium')
    import * as Cesium from 'cesium'
    import { Buffer } from 'buffer'
    interface Window {
        viewer?: any
        CESIUM_BASE_URL?: any
        Cesium?: Cesium
        Buffer?: Buffer
    }
}
