import { defineStore } from 'pinia'
import store from '@/store'
import { getMyUnRead } from '@/api/system/sysNoticeUser'

export const noticeStore = defineStore('notice', {
    state: () => ({
        unReadNum: 0,
    }),
    getters: {},
    actions: {
        getUnreadNum() {
            return new Promise((resolve) => {
                getMyUnRead({}).then((res) => {
                    if (res.code === 1) {
                        this.unReadNum = res.data
                        resolve(res.data)
                    }
                })
            })
        },
    },
})

export function getNoticeStore() {
    return noticeStore(store)
}
