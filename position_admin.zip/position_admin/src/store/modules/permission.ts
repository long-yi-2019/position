import { defineStore } from 'pinia'
import { RouteRecordName, RouteRecordRaw } from 'vue-router'
import router from '@/router'
import store from '@/store'
import { defaultRouterList, devRouter } from '@/router/defaultRouter'
import { getMyRouter } from '@/api/auth'

const routeAllPathToCompMap = import.meta.glob(`@/views/**/*.vue`)
import RouterUtil from '@/utils/RouterUtil'

const routerUtil = new RouterUtil(routeAllPathToCompMap, '/src/views')
import BaseLayout from '@/layouts/BaseLayout.vue'
import { cloneDeep } from 'lodash-es'
const rootRouter = {
    name: 'root',
    path: '/',
    redirect: '/system/user/workbench',
    component: BaseLayout,
    meta: { title: '首页' },
    children: [] as any,
}

const noPage = {
    path: '/:w+',
    name: '404',
    redirect: '/exception/404Page',
}

export const usePermissionStore = defineStore('permission', {
    state: () => ({
        whiteListRouters: ['/login'],
        menuRouters: [] as Array<RouteRecordRaw>,
        menuRoutersOneStages: [] as Array<RouteRecordRaw>,
        aliveViews: [] as string[],
        buttons: [] as string[],
        activeModule: {} as any,
        tabsList: [] as Array<RouteRecordRaw>,
        tabsActive: '',
        onLoaded: false,
        allMenu: [],
    }),
    actions: {
        /**
         * 判断是否有权限
         * @param s
         */
        h(s: string) {
            return this.buttons.indexOf(s) > -1
        },
        aliveTabs(item) {
            const tabs = this.tabsList.filter((t) => t.path === item.path)
            if (tabs.length < 1) {
                this.tabsList.push(item)
            }
            this.tabsActive = item.path
        },
        tabsChange(path) {
            this.tabsActive = path
        },
        /**
         * 删除一个
         * @param path
         */
        tabsRemove(path, activePath) {
            this.tabsList = this.tabsList.filter((t) => t.path !== path)
            if (activePath) {
                this.tabsActive = activePath
            }
        },
        /**
         * 删除其他
         * @param path
         */
        tabsCloseOther(path) {
            this.tabsList = this.tabsList.filter((t) => t.path === path)
            this.tabsActive = path
        },
        /**
         * 关闭左侧标签
         * @param path
         */
        tabsCloseLeft(path) {
            const index = this.tabsList.findIndex((t) => t.path === path)
            this.tabsList.splice(0, index)
            const activeIndex = this.tabsList.findIndex((t) => t.path === this.tabsActive)
            if (activeIndex === -1) {
                return this.tabsList[0].path
            }
            return null
        },
        /**
         * 关闭右侧标签
         * @param path
         */
        tabsCloseRight(path) {
            const index = this.tabsList.findIndex((t) => t.path === path)
            this.tabsList.splice(index + 1)
            const activeIndex = this.tabsList.findIndex((t) => t.path === this.tabsActive)
            if (activeIndex === -1) {
                return this.tabsList[this.tabsList.length - 1].path
            }
            return null
        },
        initRoutes() {
            return new Promise((resolve, reject) => {
                getMyRouter({})
                    .then((res: any) => {
                        if (res.code === 1) {
                            this.allMenu = res.data
                            this.init(this.loadAllMenu())
                            this.onLoaded = true
                            resolve(1)
                        } else {
                            reject(res)
                        }
                    })
                    .catch((res) => {
                        reject(res)
                    })
            })
        },
        loadAllMenu() {
            let asyncRouters = [] as any
            const data = JSON.parse(JSON.stringify(this.allMenu))
            asyncRouters = asyncRouters.concat(data)
            return asyncRouters
        },
        init(asyncRouters: any) {
            const btnArr = [] as string[]
            asyncRouters.forEach((v: any) => {
                if (v.menuType === 3) {
                    btnArr.push(v.authIdent)
                }
            })
            this.buttons = btnArr
            /* 构建路由 --基础类型转换为树形 */
            let asyncRoutersTree = routerUtil.routerListToTree(asyncRouters)
            /*合并默认路由*/
            defaultRouterList.forEach((item: RouteRecordRaw) => {
                if (item.children && item.children.length > 0) {
                    asyncRoutersTree.push(item)
                }
            })
            /*合并开发环境路由*/
            if (import.meta.env.MODE === 'development') {
                asyncRoutersTree = devRouter.concat(asyncRoutersTree)
            }

            // this.menuRouters = cloneDeep(asyncRoutersTree) as any

            /*路由处理为1级*/
            const routerOneStages = routerUtil.routerOneStage(asyncRoutersTree)
            this.menuRoutersOneStages = routerOneStages
            /*缓存路由*/
            this.aliveViews = routerOneStages
                .filter((value) => value.meta.keepAlive)
                .map((value) => value.name)
            rootRouter.children = [...routerOneStages]
            if (!rootRouter.redirect) {
                rootRouter.redirect = rootRouter.children[0].path
                // rootRouter.redirect = '/system/user/workbench'
            }
            this.restore()
            router.addRoute(rootRouter)
            router.addRoute(noPage)
        },
        restMenuRouters(asyncRouters: any) {
            /* 构建路由 --基础类型转换为树形 */
            let asyncRoutersTree = routerUtil.routerListToTree(asyncRouters)
            /*合并开发环境路由*/
            if (import.meta.env.MODE === 'development') {
                asyncRoutersTree = devRouter.concat(asyncRoutersTree)
            }
            this.menuRouters = cloneDeep(asyncRoutersTree) as any
        },
        restore() {
            const allRouters = router.getRoutes()
            allRouters.forEach((item: RouteRecordRaw) => {
                router.removeRoute(<RouteRecordName>item.name)
            })
            /* 合并默认路由 */
            defaultRouterList.forEach((item: RouteRecordRaw) => {
                if (!(item.children && item.children.length > 0)) {
                    router.addRoute(item)
                }
            })
            /*合并默认路由*/
            // asyncRoutersTree = defaultRouterList.concat(asyncRoutersTree)
        },
    },
})

export function getPermissionStore() {
    return usePermissionStore(store)
}
