import { defineStore } from 'pinia'
import store from '@/store'
import { login } from '@/api/auth'
import * as tokenUtil from '@/utils/tokenUtil'
const InitUserInfo: any = {
    roles: [] as string[],
    userName: '',
    departmentName: '',
}

export const useUserStore = defineStore('user', {
    state: () => ({
        token: tokenUtil.getToken(),
        userInfo: InitUserInfo,
    }),
    getters: {
        roles: (state) => {
            return state.userInfo?.roles
        },
    },
    actions: {
        /**
         * 登录
         * @param userInfo
         */
        login(userInfo: Record<string, unknown>) {
            return new Promise((resolve, reject) => {
                login(userInfo)
                    .then((res: any) => {
                        if (res.code === 1) {
                            this.token = res.data
                            tokenUtil.setToken(res.data)
                            resolve(1)
                        } else {
                            reject(res)
                        }
                    })
                    .catch((e: any) => {
                        reject(e)
                    })
            })
        },
        /**
         * 获取用户基本信息，角色信息
         */
        getUserInfo() {
            return new Promise((resolve) => {
                const userInfo = tokenUtil.getUser()
                if (userInfo.avatar) {
                    const avatar = JSON.parse(userInfo.avatar)
                    userInfo.avatar = import.meta.env.VITE_API_URL_STATIC + avatar.path
                } else {
                    userInfo.avatar = '/avatar.jpeg'
                }
                this.userInfo = userInfo
                resolve(1)
            })
        },
        /**
         * 主动退出
         * 1清空缓存，2重置路由
         */
        logout() {
            return new Promise((resolve) => {
                localStorage.clear()
                this.token = ''
                this.userInfo = InitUserInfo
                resolve(1)
            })
        },
    },
})

export function getUserStore() {
    return useUserStore(store)
}
