import { defineStore } from 'pinia'
import store from '@/store'
export const globalStore = defineStore('global', {
    state: () => ({
        clientHeight: 0,
    }),
    actions: {},
})

export function getGlobalStore() {
    return globalStore(store)
}
