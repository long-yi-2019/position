import { createPinia } from 'pinia'

const store = createPinia()

export * from './modules/global'
export * from './modules/permission'
export * from './modules/user'
export * from './modules/notice'

export default store
