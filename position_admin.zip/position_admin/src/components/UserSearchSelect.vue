<template>
    <ASelect
        allow-clear
        v-model:value="value"
        show-search
        placeholder="请输入并选择人员"
        :default-active-first-option="false"
        :not-found-content="loading ? undefined : null"
        :show-arrow="false"
        :filter-option="false"
        :options="options"
        labelInValue
        @search="handleSearch"
        @change="handleChange"
    >
        <template v-if="loading" #notFoundContent>
            <ASpin size="small" />
        </template>
    </ASelect>
</template>
<script setup lang="ts">
import { ref } from 'vue'
import { debounce } from 'lodash'
import { getListByKeyword } from '@/api/system/sysUser'

const value = ref('')
const loading = ref(false)
const options = ref([])
let lastFetchId = 0
const handleSearch = debounce((val: string) => {
    options.value = []
    loading.value = true
    lastFetchId += 1
    const fetchId = lastFetchId

    if (val.length < 2) {
        return
    }
    getListByKeyword({ keyword: val }).then((res) => {
        if (res.code === 1) {
            const data = res.data || []
            const result = data.map((d) => {
                return {
                    value: d.id,
                    label: `${d.userName}(${d.accountName})`, //
                    phoneNumber: d.phoneNumber,
                    id: d.id,
                    name: d.userName,
                }
            })
            loading.value = false
            if (fetchId !== lastFetchId) {
                // 只需要更新最后一次搜索结果
                return
            }
            options.value = result
        } else {
            console.error(res)
        }
    })
}, 300)

const emits = defineEmits(['change'])

const handleChange = (value) => {
    if (value) {
        emits('change', value.option)
    } else {
        emits('change', {})
    }
}
</script>
<style scoped lang="less"></style>
