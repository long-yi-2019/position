<template></template>

<script>
export default {
    // eslint-disable-next-line vue/no-reserved-component-names
    name: 'map',
}
</script>

<style scoped></style>
