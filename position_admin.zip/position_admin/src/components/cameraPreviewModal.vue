<template>
    <AModal
        :title="iframeInfo.title"
        :footer="null"
        v-model:visible="visible"
        width="100%"
        wrap-class-name="full-modal"
        @cancel="closeIframe"
    >
        <iframe
            style="width: 100%; height: 100%; border: none"
            :src="iframeInfo.src"
            frameborder="0"
            marginwidth="0"
            marginheight="0"
            vspace="0"
            hspace="0"
            allowtransparency="true"
            scrolling="no"
            allowfullscreen="true"
        ></iframe>
    </AModal>
</template>

<script setup>
/**
 * 国标视频监控预览弹窗
 */
import { ref } from 'vue'

const iframeInfo = ref({
    title: '',
    src: '',
})
const visible = ref(false)
/**
 * 显示弹窗
 * @deviceId 设备ID
 * @channelId 通道ID
 * @title 弹窗标题
 */
const show = (params) => {
    let url = import.meta.env.VITE_CAMERA_URL
    url = url.replace('{deviceId}', params.deviceId)
    url = url.replace('{channelId}', params.channelId)
    iframeInfo.value = {
        title: params.title,
        src: url,
    }
    visible.value = true
}
defineExpose({ show })

const closeIframe = () => {
    iframeInfo.value = {
        title: '',
        src: '',
    }
}
</script>

<style lang="less">
.full-modal {
    .ant-modal {
        max-width: 100%;
        top: 0;
        padding-bottom: 0;
        margin: 0;
    }

    .ant-modal-content {
        display: flex;
        flex-direction: column;
        height: calc(100vh);
    }

    .ant-modal-body {
        flex: 1;
    }
}
</style>
