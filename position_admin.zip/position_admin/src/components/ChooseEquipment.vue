<template>
    <YxModal
        ref="YxModalRef"
        :title="modalTitle"
        v-model:visible="visible"
        @ok="onSubmit"
        @cancel="onCancel"
        :submit-loading="submitLoading"
    >
        <MyTablePage
            :showTools="false"
            ref="MyTablePageRef"
            :search-item="searchItem"
            :url="dataUrl"
            :columns="columns"
            :action="action"
            :ellipsis="1"
            show-index
            pagination
            selection="checkbox"
        >
        </MyTablePage>
    </YxModal>
</template>
<script setup lang="ts">
import { nextTick, ref } from 'vue'
import { parseField } from '@/utils/Common'
import { message } from 'ant-design-vue'

/**
 * 基础数据定义
 */
const MyTablePageRef = ref()
const visible = ref(false)
const submitLoading = ref(false)
const modalTitle = ref('选择仪器设备')
const dataUrl = `${import.meta.env.VITE_API_URL_SYSTEM}/v1/bz/equipment/library/getNoLabInfoList`

/*列配置 api https://itvita.gitee.io/liuyunxi-antd-extend/#/YxTable*/
const columns = ref<any[]>([
    {
        title: '资产编号',
        dataIndex: 'assetNumber',
        hidden: false,
        sorter: true,
        width: 200,
    },
    {
        title: '资产名称',
        dataIndex: 'name',
        hidden: false,
        sorter: true,
        width: 200,
    },
    {
        title: '单价(元)',
        dataIndex: 'price',
        hidden: false,
        sorter: true,
        width: 200,
    },
    {
        title: '所属单位部门',
        dataIndex: 'departmentName',
        hidden: false,
        sorter: true,
        width: 200,
    },
    {
        title: '使用人名称',
        dataIndex: 'useUserName',
        hidden: false,
        sorter: true,
        width: 200,
    },
    {
        title: '使用人编号',
        dataIndex: 'useUserNumber',
        hidden: false,
        sorter: true,
        width: 200,
    },
    {
        title: '国标分类号',
        dataIndex: 'propertyChinaUnspsc',
        hidden: false,
        sorter: true,
        width: 200,
    },
    {
        title: '国标分类名称',
        dataIndex: 'propertyChinaName',
        hidden: false,
        sorter: true,
        width: 200,
    },
    {
        title: '购置日期',
        dataIndex: 'buyDate',
        hidden: false,
        sorter: true,
        width: 200,
    },
    {
        title: '规格',
        dataIndex: 'specification',
        hidden: false,
        sorter: true,
        width: 200,
    },
    {
        title: '型号/品牌',
        dataIndex: 'model',
        hidden: false,
        sorter: true,
        width: 200,
    },
    {
        title: '厂家',
        dataIndex: 'vender',
        hidden: false,
        sorter: true,
        width: 200,
    },
    {
        title: '现状',
        dataIndex: 'actuality',
        hidden: false,
        sorter: true,
        width: 200,
        formatter: {
            type: 'text',
            format: (row: any) => {
                return {
                    value: parseField(row.actuality, {
                        1: '在用',
                        2: '多余',
                        3: '待修',
                        4: '待报废',
                        8: '降档',
                        9: '其他',
                    }),
                }
            },
        },
    },
    {
        title: '资产来源',
        dataIndex: 'origin',
        hidden: false,
        sorter: true,
        width: 200,
        formatter: {
            type: 'text',
            format: (row: any) => {
                return {
                    value: parseField(row.origin, {
                        1: '购置',
                        2: '捐赠',
                        3: '自制',
                        4: '校外调入',
                    }),
                }
            },
        },
    },
    {
        title: '教育部分类号',
        dataIndex: 'educationClassifyUnspsc',
        hidden: false,
        sorter: true,
        width: 200,
    },
    {
        title: '教育部分类名',
        dataIndex: 'educationClassifyName',
        hidden: false,
        sorter: true,
        width: 200,
    },
    {
        title: '资产类别',
        dataIndex: 'type',
        hidden: false,
        sorter: true,
        width: 200,
    },
    {
        title: '供货商/电话',
        dataIndex: 'supplier',
        hidden: false,
        sorter: true,
        width: 200,
    },
    {
        title: '使用单位号',
        dataIndex: 'useUnitNumber',
        hidden: false,
        sorter: true,
        width: 200,
    },
    {
        title: '使用期限(月)',
        dataIndex: 'useTimeLimit',
        hidden: false,
        sorter: true,
        width: 200,
    },
    {
        title: '使用方向',
        dataIndex: 'useDirection',
        hidden: false,
        sorter: true,
        width: 200,
        formatter: {
            type: 'text',
            format: (row: any) => {
                return {
                    value: parseField(row.useDirection, {
                        1: '教学为主',
                        2: '科研为主',
                    }),
                }
            },
        },
    },
])

/*搜索条配置*/
const searchItem = ref<any[]>([
    {
        type: 'text',
        key: 'assetNumber',
        label: '资产编号',
        value: '',
        placeholder: '请输入',
    },
    {
        type: 'text',
        key: 'name',
        label: '资产名称',
        value: '',
        placeholder: '请输入',
    },
])
/*table 操作列配置*/
const action = ref({
    width: 150,
    buttons: [
        {
            title: '详情',
            icon: 'iconfont icon-caidan',
            event: (row: any) => {
                MyTablePageRef.value.showDetail(row)
            },
        },
    ],
})

/**
 * 显示弹窗
 */
const show = (params?: any) => {
    visible.value = true
    nextTick(() => {
        MyTablePageRef.value.search(params || {})
    })
}
defineExpose({ show })

/**
 * 提交方法
 */
const onSubmit = () => {
    const rows = MyTablePageRef.value.getSelection().selectedRows
    if (rows.length < 1) {
        message.warn('请选择仪器设备！')
        return
    } else {
        visible.value = false
        emits('setEquipmentDataSource', rows)
    }
}

/**
 * 关闭弹窗
 */
const onCancel = () => {
    visible.value = false
}
/**
 * 接收方法
 */
const emits = defineEmits(['setEquipmentDataSource'])
</script>
