<template>
    <div class="map-container" style="width: 100%; height: 500px">
        <div ref="map" class="map"></div>
    </div>
</template>

<script>
import 'ol/ol.css'
import Map from 'ol/Map'
import View from 'ol/View'
import ImageLayer from 'ol/layer/Image'
import ImageStatic from 'ol/source/ImageStatic'
import Draw from 'ol/interaction/Draw'
import VectorSource from 'ol/source/Vector'

export default {
    name: 'OpenLayersMap',
    props: {
        modelValue: {
            type: Array,
            default: () => [],
        },
    },
    data() {
        return {
            map: null,
            drawInteraction: null,
        }
    },
    watch: {
        modelValue: {
            immediate: true,
            handler(newVal) {
                console.log(newVal) // 可以在这里处理modelValue的变化
            },
        },
    },
    mounted() {
        const mapContainerHeight = this.$refs.map
        mapContainerHeight.style.height = '500px'
        setTimeout(() => {}, 100)
        this.initMap()
        this.initDrawInteraction()
    },
    methods: {
        initMap() {
            this.map = new Map({
                target: this.$refs.map,
                layers: [
                    new ImageLayer({
                        source: new ImageStatic({
                            url: 'map.png',
                            projection: 'EPSG:4326',
                            imageExtent: [0, 0, 1, 1],
                        }),
                    }),
                ],
                view: new View({
                    center: [0.5, 0.5],
                    zoom: 9,
                    projection: 'EPSG:4326',
                }),
            })
        },
        initDrawInteraction() {
            this.drawInteraction = new Draw({
                source: new VectorSource(),
                type: 'Polygon',
            })
            this.drawInteraction.on('drawend', this.onDrawEnd)
            this.map.addInteraction(this.drawInteraction)
        },
        onDrawEnd(event) {
            const feature = event.feature
            const geometry = feature.getGeometry()
            const coordinates = geometry.getCoordinates()
            console.log('Polygon coordinates:', coordinates)

            // Emit the coordinates back to the parent component
            this.$emit('update:modelValue', coordinates)
        },
    },
}
</script>

<style scoped></style>
