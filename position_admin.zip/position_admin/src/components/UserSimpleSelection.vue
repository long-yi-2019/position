<!--用户单选-->
<template>
    <YxModal
        ref="YxModalRef"
        title="用户单选"
        :style="{ position: 'fixed' }"
        v-model:visible="visible"
        @ok="onSubmit"
        @cancel="onCancel"
        :submit-loading="submitLoading"
    >
        <div class="table-tree-container">
            <div class="list-tree-wrapper">
                <div
                    class="list-tree-operator"
                    :style="{
                        width: '320px',
                    }"
                >
                    <YxTree ref="YxTreeRef" @click="handleTreeClick"></YxTree>
                </div>
                <div class="list-tree-content">
                    <ARow :gutter="0">
                        <ACol :span="12">
                            <YxSearch
                                ref="YxSearchRef"
                                @expand="searchExpand"
                                :items="searchItem"
                                @search="handelSearch"
                            />
                            <ARadioGroup v-model:value="checkValue" style="width: 100%">
                                <AList
                                    :style="{ height: tableHeight }"
                                    style="overflow: auto"
                                    class="left_list"
                                    item-layout="horizontal"
                                    :data-source="userList"
                                >
                                    <template #loadMore>
                                        <div
                                            v-if="hasNext"
                                            :style="{
                                                textAlign: 'center',
                                                marginTop: '12px',
                                                marginBottom: '12px',
                                                height: '32px',
                                                lineHeight: '32px',
                                            }"
                                        >
                                            <AButton :loading="loading" @click="onLoadMore"
                                                >加载更多</AButton
                                            >
                                        </div>
                                    </template>
                                    <template #renderItem="{ item }">
                                        <AListItem>
                                            <AListItemMeta>
                                                <template #title>
                                                    <ARadio :value="item.id">
                                                        <a>
                                                            {{ item.userName }}
                                                            <ATag
                                                                v-for="(
                                                                    role, index
                                                                ) in item.roleList"
                                                                :key="index"
                                                                color="#2db7f5"
                                                            >
                                                                {{ role.title }}
                                                            </ATag>
                                                        </a>
                                                    </ARadio>
                                                </template>
                                                <template #avatar>
                                                    <AAvatar :src="getAvatar(item)" />
                                                </template>
                                                <template #description>
                                                    <div>{{ item.deptCode }}</div>
                                                </template>
                                            </AListItemMeta>
                                        </AListItem>
                                    </template>
                                </AList>
                            </ARadioGroup>
                        </ACol>
                        <ACol :span="12" style="padding-left: 20px">
                            <ARadioGroup
                                v-model:value="checkValue"
                                style="width: 100%; margin-top: 20px"
                            >
                                <AList
                                    :style="{ height: tableHeight }"
                                    style="overflow: auto"
                                    item-layout="horizontal"
                                    :data-source="selectUserList"
                                >
                                    <template #renderItem="{ item }">
                                        <AListItem>
                                            <AListItemMeta>
                                                <template #title>
                                                    <ARadio :value="item.id">
                                                        <a>
                                                            {{ item.userName }}
                                                            <ATag
                                                                v-for="(
                                                                    role, index
                                                                ) in item.roleList"
                                                                :key="index"
                                                                color="#2db7f5"
                                                            >
                                                                {{ role.title }}
                                                            </ATag>
                                                        </a>
                                                    </ARadio>
                                                </template>
                                                <template #avatar>
                                                    <AAvatar :src="getAvatar(item)" />
                                                </template>
                                                <template #description>
                                                    <div>{{ item.deptCode }}</div>
                                                </template>
                                            </AListItemMeta>
                                        </AListItem>
                                    </template>
                                </AList>
                            </ARadioGroup>
                        </ACol>
                    </ARow>
                </div>
            </div>
        </div>
    </YxModal>
</template>
<script setup lang="ts" name="UserSimpleSelection">
/**
 * 准备废弃，使用UserSingleChoice替代
 */

import { computed, nextTick, onMounted, ref, watch } from 'vue'
import { getList } from '@/api/common'
import { assignIn } from '@/utils/ObjectUtils'
import { getGlobalStore } from '@/store'
const YxSearchRef = ref()
const YxTreeRef = ref()
const userList = ref([])
const selectUserList = ref([])

const checkValue = ref<any>([])

watch(checkValue, () => {
    selectUserList.value = userList.value.filter((item: any) => item.id === checkValue.value)
})

/**
 * 基础数据定义
 */
const visible = ref(false)
const submitLoading = ref(false)
const loading = ref(false)
let defParams = {}

const searchExpand = (clientHeight: any) => {
    getGlobalStore().clientHeight = clientHeight
}

const getAvatar = (item) => {
    if (item.avatar) {
        const avatar = JSON.parse(item.avatar)
        return import.meta.env.VITE_API_URL_STATIC + avatar.path
    } else {
        return import.meta.env.VITE_BASE_URL + '/static/image/avatar.jpeg'
    }
}
const searchItem = ref([
    {
        type: 'text',
        key: 'userName',
        label: '姓名',
        value: '',
        placeholder: '',
    },
    {
        type: 'text',
        key: 'phoneNumber',
        label: '手机号',
        value: '',
        placeholder: '',
    },
    {
        type: 'select',
        key: 'state',
        label: '状态',
        value: '1',
        placeholder: '',
        options: [
            {
                label: '启用',
                value: '1',
            },
            {
                label: '禁用',
                value: '0',
            },
        ],
    },
])

const initTree = () => {
    YxTreeRef.value.showLoading()
    getList(`${import.meta.env.VITE_API_URL_SYSTEM}/v1/sys/department/getZtree`, {}).then((res) => {
        if (res.code === 1) {
            const TreeNodes = res.data
            YxTreeRef.value.init(TreeNodes, {})
            YxTreeRef.value.select()
        }
        YxTreeRef.value.hideLoading()
    })
}
const tableHeight = computed(() => {
    return `calc(100vh - ${getGlobalStore().clientHeight + 140}px)`
})
/**
 * 显示弹窗
 * @param checked 已选[｛id:'',xxx｝]
 * @param param 其他参数
 */
const show = (checked, param) => {
    checked = checked || []
    defParams = param || {}
    visible.value = true
    nextTick(() => {
        initTree()
        if (checked) {
            checkValue.value = checked.id
        }
    })
}
defineExpose({ show })

const emits = defineEmits(['ok'])
const onSubmit = () => {
    const result = selectUserList.value.map((u: any) => {
        return {
            id: u.id,
            name: u.userName,
        }
    })
    emits('ok', result)
    onCancel()
}
const onCancel = () => {
    visible.value = false
}

const selectNode = ref({ code: '100' })

const pageNumber = ref(1)
const pageSize = ref(10)
const hasNext = ref(true)
const search = (params) => {
    loading.value = true
    params = params || {}
    params = Object.assign(
        {
            pageNumber: pageNumber.value,
            pageSize: pageSize.value,
        },
        params,
        defParams,
    )

    getList(`${import.meta.env.VITE_API_URL_SYSTEM}/v1/sys/user/getList`, params).then((res) => {
        if (res.code === 1) {
            const data = res.data
            if (params.pageNumber === 1) {
                userList.value = []
            }
            userList.value = userList.value.concat(data.rows)
            hasNext.value = data.pages > params.pageNumber
        }
        loading.value = false
    })
}
const onLoadMore = () => {
    pageNumber.value += 1
    const params = Object.assign({ deptCode: selectNode.value.code }, YxSearchRef.value.getValues())
    search(params)
}
/*点击*/
const handleTreeClick = (treeNodes: any) => {
    selectNode.value = treeNodes
    pageNumber.value = 1
    search({ deptCode: selectNode.value.code })
}

const handelSearch = () => {
    pageNumber.value = 1
    const params = assignIn(
        {
            deptCode: selectNode.value.code,
        },
        YxSearchRef.value.getValues(),
    )
    search(params)
}

onMounted(() => {})
</script>
<style scoped lang="less">
@import '@/theme/theme.less';
.list-tree-wrapper {
    background-color: @component-background;
    overflow-y: hidden;
}

.list-tree-operator {
    float: left;
    padding: 12px 20px;
    min-height: 250px;
    overflow: auto;
    max-height: calc(100vh - 305px);
}

.list-tree-content {
    //border-left: 1px solid #e7e7e7;
    overflow: auto;
}
.left_list {
    border-right: 1px solid @border-color-base;
}
</style>
