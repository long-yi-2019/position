<template>
    <div title="数据大屏" class="flex align-center pointer">
        <i class="iconfont icon-shujudaping margin-right-xs"></i>
        <div>数据大屏</div>
    </div>
</template>

<script setup lang="ts"></script>

<style scoped lang="less"></style>
