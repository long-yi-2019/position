<template>
    <ABadge style="z-index: 1" :count="noticeStore.unReadNum" :offset="[5, -4]">
        <div title="消息通知" class="flex pointer" @click="showMyNotice">
            <i class="iconfont icon-tongzhi"></i>
            <div class="margin-left-xs">消息通知</div>
        </div>
    </ABadge>
</template>

<script setup lang="ts">
import { onMounted } from 'vue'
import { useRouter } from 'vue-router'
const router = useRouter()
import { getNoticeStore } from '@/store'
const noticeStore = getNoticeStore()
const showMyNotice = () => {
    router.push({ path: '/system/user/notice' })
}

/**
 * 挂载，页面初始化后执行
 */
onMounted(() => {})
</script>

<style scoped lang="less">
.iconfont {
    font-size: 16px;
}
</style>
