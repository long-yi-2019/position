<template>
    <ADropdown placement="bottomRight" :trigger="['click']">
        <div class="pointer">
            <i class="iconfont icon-user"></i>
            <span class="margin-left-xs">{{ userInfo.userName }}</span>
        </div>
        <template #overlay>
            <div class="layout__header__user">
                <AMenu :selected-keys="[]">
                    <AMenuItem key="Workbench" @click="goWorkbench">
                        <KeyOutlined />
                        工作台
                    </AMenuItem>
                    <AMenuItem key="userInfo" @click="goCenter">
                        <KeyOutlined />
                        个人资料
                    </AMenuItem>
                    <AMenuItem key="password" @click="goUpdPass">
                        <KeyOutlined />
                        修改密码
                    </AMenuItem>
                    <AMenuDivider />
                    <AMenuItem key="logout" @click="handelLogout">
                        <LoginOutlined />
                        退出
                    </AMenuItem>
                </AMenu>
            </div>
        </template>
    </ADropdown>
</template>

<script setup lang="ts">
// This starter template is using Vue 3 <script setup> SFCs
// Check out https://vuejs.org/api/sfc-script-setup.html#script-setup
import { KeyOutlined, LoginOutlined } from '@ant-design/icons-vue'
import { Modal } from 'ant-design-vue'
import { getUserStore } from '@/store'
import { useRouter } from 'vue-router'
import { computed } from 'vue'
const userStore = getUserStore()
const router = useRouter()

const handelLogout = () => {
    Modal.confirm({
        title: '确定退出？',
        content: '',
        okType: 'danger',
        onOk() {
            userStore.logout().then(() => {
                window.location.href = import.meta.env.VITE_PAGE_LOGOUT
            })
        },
    })
}
const userInfo = computed(() => {
    return userStore.userInfo
})
const goCenter = () => {
    router.push('/system/user/info')
}
const goWorkbench = () => {
    router.push('/system/user/workbench')
}

const goUpdPass = () => {
    router.push('/system/user/updPass')
}
</script>

<style scoped lang="less">
@import '@/theme/theme.less';
.layout__header__user {
    border-radius: 4px;
    box-shadow: 0 2px 5px 0 @border-color-base;
    //border: 1px solid @border-color-base;
    min-width: 150px;
}
.iconfont {
    font-size: 14px;
}
</style>
