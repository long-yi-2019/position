<template>
    <YxModal
        ref="YxModalRef"
        :title="modalTitle"
        v-model:visible="visible"
        @ok="onSubmit"
        @cancel="onCancel"
        :submit-loading="submitLoading"
    >
        <MyTablePage
            ref="MyTablePageRef"
            :search-item="searchItem"
            :url="dataUrl"
            :columns="columns"
            :ellipsis="1"
            pagination
            show-index
            :selection="selectionType"
        >
        </MyTablePage>
    </YxModal>
</template>
<!--添加路由地址：/system/sysRole/add，修改路由地址：/system/sysRole/edit，组件地址：/system/sysRole/edit-->
<script setup lang="ts">
/**
 * 实验室选择
 */
import { ref } from 'vue'
import { cloneDeep } from 'lodash-es'
import { Modal } from 'ant-design-vue'
import { isNotEmpty } from '@/utils/ValidateUtils'
import { getList } from '@/api/common'
/**
 * 基础数据定义
 */
const visible = ref(false)
const submitLoading = ref(false)
const modalTitle = ref('实验室选择')
const MyTablePageRef = ref()
const dataUrl = ref('')
const selectionType = ref('radio')

const columns = [
    {
        title: '所属校区',
        dataIndex: 'schoolAreaName',
        hidden: false,
        sorter: true,
        width: 200,
    },
    {
        title: '所属学院',
        dataIndex: 'departmentName',
        hidden: false,
        sorter: true,
        width: 220,
    },
    {
        title: '楼栋',
        dataIndex: 'buildingName',
        hidden: false,
        sorter: true,
        width: 200,
    },
    {
        title: '房间号',
        dataIndex: 'roomNumber',
        hidden: false,
        sorter: true,
        width: 120,
    },
    {
        title: '房间名称',
        dataIndex: 'roomName',
        hidden: false,
        sorter: true,
        width: 200,
    },

    {
        title: '房间编号',
        dataIndex: 'roomSpecificNumber',
        hidden: false,
        sorter: true,
        width: 120,
    },
    {
        title: '负责人',
        dataIndex: 'managerName',
        hidden: false,
        sorter: true,
        width: 100,
    },
    {
        title: '负责人教工号',
        dataIndex: 'managerNumber',
        hidden: false,
        sorter: true,
        width: 120,
    },
    {
        title: '安全负责人',
        dataIndex: 'safetyManagerName',
        hidden: false,
        sorter: true,
        width: 100,
    },
    {
        title: '分管领导',
        dataIndex: 'subLeaderName',
        hidden: false,
        sorter: true,
        width: 100,
    },
    {
        title: '用房性质',
        dataIndex: 'nature',
        hidden: false,
        sorter: true,
        width: 100,
    },
    {
        title: '类别',
        dataIndex: 'category',
        hidden: false,
        sorter: true,
        width: 80,
    },
    {
        title: '安全等级',
        dataIndex: 'safeLevel',
        hidden: false,
        sorter: true,
        width: 100,
        formatter: {
            type: 'text',
            format: (row) => {
                if (row.safeLevel === 1) {
                    return {
                        value: '一级',
                    }
                } else if (row.safeLevel === 2) {
                    return {
                        value: '二级',
                    }
                } else if (row.safeLevel === 3) {
                    return {
                        value: '三级',
                    }
                } else if (row.safeLevel === 4) {
                    return {
                        value: '四级',
                    }
                } else {
                    return {
                        value: '-',
                    }
                }
            },
        },
    },
    {
        title: '使用面积',
        dataIndex: 'areaSize',
        hidden: false,
        sorter: true,
        width: 100,
        formatter: {
            type: 'text',
            format: (row) => {
                if (isNotEmpty(row.areaSize)) {
                    return {
                        value: row.areaSize / 100 + '㎡',
                    }
                } else {
                    return {
                        value: '-',
                    }
                }
            },
        },
    },
    {
        title: '建筑面积',
        dataIndex: 'buildingSize',
        hidden: false,
        sorter: true,
        width: 100,
        formatter: {
            type: 'text',
            format: (row) => {
                if (isNotEmpty(row.areaSize)) {
                    return {
                        value: row.areaSize / 100 + '㎡',
                    }
                } else {
                    return {
                        value: '-',
                    }
                }
            },
        },
    },
    {
        title: '使用年份',
        dataIndex: 'createdYear',
        hidden: false,
        sorter: true,
        width: 100,
    },
    {
        title: '备注',
        dataIndex: 'remark',
        hidden: false,
        sorter: true,
        width: 300,
    },
]

const searchItem = ref<any[]>([
    {
        type: 'select',
        key: 'schoolAreaCode',
        label: '所属校区',
        options: [],
    },
    {
        type: 'organize',
        key: 'departmentCode',
        label: '所属学院',
    },
    {
        type: 'building',
        key: 'buildingCode',
        label: '楼栋',
    },
    {
        type: 'text',
        key: 'roomNumber',
        label: '房间号',
        value: '',
        placeholder: '',
    },
    {
        type: 'text',
        key: 'roomName',
        label: '房间名称',
        value: '',
        placeholder: '',
    },
    {
        type: 'text',
        key: 'roomSpecificNumber',
        label: '房间编号',
        value: '',
        placeholder: '',
    },
    {
        type: 'userId',
        key: 'managerId',
        label: '负责人',
        placeholder: '请输入姓名/工号',
    },
    {
        type: 'userId',
        key: 'safetyManagerId',
        label: '安全负责人',
        placeholder: '请输入姓名/工号',
    },
    {
        type: 'userId',
        key: 'subLeaderId',
        label: '分管领导',
        placeholder: '请输入姓名/工号',
    },
    {
        type: 'sysDict', // 数据字典类型
        key: 'nature', // 表字段名称
        dictKey: 'labNature', // 数据字典key
        label: '实验室性质',
        value: '',
        placeholder: '',
        options: [],
    },
    {
        type: 'sysDict', // 数据字典类型
        key: 'category', // 表字段名称
        dictKey: 'labCategory', // 数据字典key
        label: '实验室类别',
        value: '',
        placeholder: '',
        options: [],
    },

    {
        type: 'select',
        key: 'safeLevel',
        label: '安全等级',
        value: '',
        placeholder: '',
        options: [
            {
                label: '一级',
                value: '1',
            },
            {
                label: '二级',
                value: '2',
            },
            {
                label: '三级',
                value: '3',
            },
            {
                label: '四级',
                value: '4',
            },
        ],
    },
    {
        type: 'select',
        key: 'createdYear',
        label: '使用年份',
        value: '',
        placeholder: '',
        options: [],
    },
])

/**
 * 显示弹窗
 */
const show = (st = 'radio') => {
    selectionType.value = st
    dataUrl.value = `${import.meta.env.VITE_API_URL_SYSTEM}/v1/lab/info/getContainOrManageList`
    visible.value = true
    setTimeout(() => {
        getSchoolArea()
        getCreatedYear()
        MyTablePageRef.value.search()
    }, 500)
}
/* 获取使用年份 */
const getCreatedYear = () => {
    let tmp = searchItem.value.filter((v) => v.key === 'createdYear')[0]
    tmp.options = []
    const dd = new Date()
    let year = dd.getFullYear()
    for (let i = 0; i < 100; i++) {
        tmp.options.push({ label: year + '', value: year })
        year--
    }
}

/* 获取校区 */
const getSchoolArea = () => {
    /**查询单位数据*/
    getList(`${import.meta.env.VITE_API_URL_SYSTEM}/v1/school/area/getList`).then((res) => {
        if (res.code === 1) {
            searchItem.value[0].options = []
            res.data.rows.forEach((v: any) => {
                searchItem.value[0].options.push({
                    value: v.code,
                    label: v.name,
                })
            })
        }
    })
}
defineExpose({ show })
/**
 * 接收方法
 */
const emits = defineEmits(['success'])
/**
 * 提交方法
 */
const onSubmit = (ids?: string[]) => {
    let labInfos = []
    if (ids === undefined) {
        const { selectedRowKeys, selectedRows } = MyTablePageRef.value.getSelection()
        ids = cloneDeep(selectedRowKeys)
        labInfos = cloneDeep(selectedRows)
    }
    if (!ids || ids?.length < 1) {
        Modal.warning({
            title: '请先选择实验室',
        })
        return
    }
    console.log('打印labInfos', labInfos)
    if (selectionType.value === 'radio') {
        emits('success', labInfos[0])
    } else {
        emits('success', labInfos)
    }
    onCancel()
}
/**
 * 关闭弹窗
 */
const onCancel = () => {
    visible.value = false
}
</script>

<style scoped lang="less"></style>
