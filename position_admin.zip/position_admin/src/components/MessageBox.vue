<template>
    <AModal v-model:visible="visible" title="Basic Modal" @ok="handleOk">
        <p>{{ props.message }}</p>
    </AModal>
</template>
<script setup lang="ts">
import { ref } from 'vue'

const props = defineProps({
    message: {
        type: String,
        default: 'icon',
    },
})

const visible = ref(false)

const show = () => {
    visible.value = true
}

const handleOk = () => {
    visible.value = false
}

defineExpose({ show })
</script>
