<template>
    <div class="yunxi__avatar_container">
        <AAvatar :size="size" :src="oldSrc"> </AAvatar>
        <div class="yunxi__avatar_edit_text" @click="show">
            <a href="javascript:void(0)">修&nbsp;改头&nbsp;像</a>
        </div>
    </div>

    <AModal
        v-model:visible="visible"
        title="图片裁剪"
        width="750px"
        @ok="handleOk"
        :confirmLoading="confirmLoading"
        :destroyOnClose="true"
    >
        <ARow :gutter="20">
            <ACol :span="14">
                <ATabs v-model:activeKey="activeKey" type="card">
                    <ATabPane key="1" tab="自定义">
                        <AButton
                            >选择图片<input
                                class="yunxi__upload_tool"
                                type="file"
                                @change="selectFile"
                        /></AButton>
                        <ATypographyText type="secondary" class="margin-left-sm"
                            >支持jpg、jpeg、gif、png、bmp格式的图片</ATypographyText
                        >
                        <div class="margin-top-sm"></div>
                        <VuePictureCropper
                            v-if="picture"
                            :boxStyle="{
                                width: '100%',
                                height: '100%',
                                backgroundColor: '#f8f8f8',
                                margin: 'auto',
                            }"
                            :img="picture"
                            :options="{
                                viewMode: 1,
                                dragMode: 'move',
                                aspectRatio: 1,
                                cropBoxResizable: false,
                            }"
                            :presetMode="{
                                mode: 'fixedSize',
                                width: 200,
                                height: 200,
                            }"
                            @cropmove="handelMove"
                        />
                    </ATabPane>
                    <ATabPane key="2" tab="推荐"> 空空如也 </ATabPane>
                </ATabs>
            </ACol>
            <ACol :span="1"><ADivider type="vertical" style="height: 100%" /> </ACol>
            <ACol :span="9">
                <div class="flex align-center justify-center">
                    <ASpace direction="vertical" size="large">
                        <div class="title">头像预览</div>
                        <AAvatar shape="square" :size="100" :src="resultBase64"> </AAvatar>
                        <AAvatar :size="100" :src="resultBase64"> </AAvatar>
                    </ASpace>
                </div>
            </ACol>
        </ARow>
    </AModal>
</template>
<script setup lang="ts" name="YxCropper">
import { onMounted, ref, watch } from 'vue'
import VuePictureCropper, { cropper } from 'vue-picture-cropper'
const visible = ref(false)
const confirmLoading = ref(false)
const activeKey = ref('1')
const picture = ref('')
import { uploadFile } from '@/api/common'
import { edit } from '@/api/system/sysUser'
import { getUserStore } from '@/store'
import { message } from 'ant-design-vue'
const userStore = getUserStore()
interface Props {
    src: string
    size?: number
}
const props = withDefaults(defineProps<Props>(), {
    src: '',
    size: 80,
})
const show = () => {
    visible.value = true
}
watch(
    () => props.src,
    () => {
        oldSrc.value = props.src
        resultBase64.value = props.src
    },
)
// eslint-disable-next-line vue/no-setup-props-destructure
const oldSrc = ref(props.src)

// eslint-disable-next-line vue/no-setup-props-destructure
const resultBase64 = ref(props.src)
const pictureFile = ref()
const selectFile = (e: Event): void => {
    // 获取选取的文件
    const target = e.target as HTMLInputElement
    const { files } = target
    if (!files) return
    const file: File = files[0]
    // 转换为base64传给裁切组件
    const reader: FileReader = new FileReader()
    reader.readAsDataURL(file)
    reader.onload = (): void => {
        picture.value = String(reader.result)
        setTimeout(() => {
            // 获取生成的base64图片地址
            resultBase64.value = cropper?.getDataURL() || ''
            pictureFile.value = cropper?.getFile({ fileName: 'file' })
        }, 500)
    }
}

let moveTimer = null as any
const handelMove = () => {
    if (moveTimer !== null) {
        clearTimeout(moveTimer)
    }
    moveTimer = setTimeout(async () => {
        resultBase64.value = cropper?.getDataURL() || ''
        pictureFile.value = await cropper?.getFile()
        moveTimer = null
    }, 50)
}
const handleOk = () => {
    confirmLoading.value = true
    uploadFile(pictureFile.value).then(async (res) => {
        if (res.code === 1) {
            const data = res.data
            await edit({ avatar: JSON.stringify(data), id: userStore.userInfo.id })
            message.success('提交成功')
            oldSrc.value = resultBase64.value
            visible.value = false
        }
        confirmLoading.value = false
    })
}
onMounted(() => {})
</script>
<style scoped lang="less">
.yunxi__avatar_container {
    position: relative;
    &:hover {
        .yunxi__avatar_edit_text {
            display: block;
        }
    }
}
.yunxi__avatar_edit_text {
    display: none;
    border-radius: 50%;
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background-color: rgba(0, 0, 0, 0.4);
    color: #ffffff;
    text-align: center;
    a {
        padding: 28%;
        font-size: 14px;
        color: #fff;
        display: block;
        width: 100%;
        height: 100%;
        text-decoration: none;
        box-sizing: border-box;
    }
}
.yunxi__upload_tool {
    position: absolute;
    right: 0;
    top: 0;
    width: 100%;
    height: 100%;
    opacity: 0;
    z-index: 998;
    filter: alpha(opacity=0);
    font-size: 0;
    cursor: pointer;
}
</style>
