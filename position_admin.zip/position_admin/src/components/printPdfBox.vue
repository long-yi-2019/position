<template>
    <div style="width: 100%; height: 100%">
        <APageHeader class="yx-page-header" :title="props.title" @back="goBack">
            <template #extra>
                <AButton type="primary" @click="handleSubmit" :loading="confirmLoading">
                    打印
                </AButton>
            </template>
        </APageHeader>

        <div class="box_body">
            <div class="container">
                <div ref="printMain" id="print-js-id">
                    <slot></slot>
                </div>
            </div>
        </div>
    </div>
</template>

<script setup lang="ts" name="printPdf">
/**
 * 用于导出A4 纸质报告时使用
 */
import printJS from 'print-js'
import { onMounted, ref } from 'vue'

const printMain = ref<any>()
const confirmLoading = ref(false)
interface Props {
    title: string // 标题
}

const props = withDefaults(defineProps<Props>(), {
    title: '',
})

const emits = defineEmits(['back', 'before', 'after', 'error'])

const handleSubmit = () => {
    emits('before')
    const oldTitle = document.title
    document.title = props.title
    const windowFocus = setInterval(() => window.dispatchEvent(new Event('focus')), 500)
    printJS({
        printable: 'print-js-id',
        type: 'html',
        maxWidth: 800,
        header: '',
        headerStyle: 'font-size:14px;font-weight: 300;',
        style: `
           body{
           -webkit-print-color-adjust:exact;
        -moz-print-color-adjust:exact;
        -ms-print-color-adjust:exact;
        print-color-adjust:exact;
        }
          .paging {
              page-break-after: always;
          }
          table {
              width: 100%;
              border-collapse: collapse;
              border-spacing: 0;
              border-left: 1px solid #e4e7ed;
              border-top: 1px solid #e4e7ed;
          }
           tr {
                  page-break-inside: avoid;
              }
              td,
              th {
                  border-right: 1px solid #e4e7ed;
                  border-bottom: 1px solid #e4e7ed;
                  padding: 10px;
                  text-align: center;
              }
              th {
                  background-color: #d9d9d9;
              }
        `,
        scanStyles: false,
        showModal: true,
        modalMessage: '正在加载...',
        documentTitle: props.title,
        onPrintDialogClose: () => {
            //清除focus事件
            clearInterval(windowFocus)
            emits('after')
            document.title = oldTitle
        },
        onError: () => {
            //清除focus事件
            clearInterval(windowFocus)
            emits('error')
            document.title = oldTitle
        },
    })
}

const goBack = () => {
    emits('back')
}

onMounted(() => {})
</script>

<style scoped lang="less">
@import '@/theme/theme.less';

.yx-page-header {
    background-color: @component-background;
}

.box_body {
    position: relative;
    padding: 20px;
    height: calc(100% - 72px);
    max-height: calc(100% - 72px);
    overflow: auto;
}

.container {
    margin: 0 auto;
    position: relative;
    background-color: #ffffff;
    width: 850px;
    padding: 25px;
    color: #000;
    .print-js-id {
        width: 100%;
    }
}
</style>
