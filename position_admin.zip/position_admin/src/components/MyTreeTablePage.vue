<template>
    <div class="table-tree-container">
        <div class="list-tree-wrapper">
            <div
                class="list-tree-operator"
                :style="{
                    width: '320px',
                }"
            >
                <YxTree
                    ref="YxTreeRef"
                    @on-drop="onDrop"
                    @add="add"
                    @edit="edit"
                    @remove="remove"
                    @click="click"
                ></YxTree>
            </div>
            <div class="list-tree-content">
                <MyTablePage
                    @initTree="initTree"
                    ref="MyTablePageRef"
                    :url="url"
                    :search-item="searchItem"
                    :pagination="pagination"
                    :ellipsis="ellipsis"
                    :selection="selection"
                    :show-index="showIndex"
                    :columns="columns"
                    :action="action"
                    :drag="drag"
                    :table-sm="tableSm"
                    @dragend="(e) => emits('dragend', e)"
                    :selectNode="selectNode"
                >
                    <template #tools>
                        <ASpace>
                            <slot name="tools"></slot>
                        </ASpace>
                    </template>
                </MyTablePage>
            </div>
        </div>
    </div>
</template>

<script setup lang="ts">
/**
 * 接受参数
 */
import { ref } from 'vue'
import { getList } from '@/api/common'
import { assignIn } from '@/utils/ObjectUtils'
const MyTablePageRef = ref()
const YxTreeRef = ref()
const selectNode = ref<any>({})

interface TreeConfigTypes {
    url: string
    customParam?: boolean
    drag?: boolean
    add?: boolean
    edit?: boolean
    remove?: boolean
    handelClick?: Function
    handelAdd?: Function
    handelEdit?: Function
    handelRemove?: Function
    handelDrop?: Function
}

const props = defineProps<{
    searchItem?: any[]
    columns: any[]
    action?: any
    url: string
    tableSm?: boolean
    showIndex?: boolean
    drag?: boolean
    selection?: 'checkbox' | 'radio'
    pagination?: boolean
    ellipsis?: number
    tree: TreeConfigTypes
    defaultParam?: any
}>()

/**
 * 初始化树形数据
 */
const initTree = async () => {
    YxTreeRef.value.showLoading()
    const params = {}
    assignIn(params, props.defaultParam ? props.defaultParam() : {})

    await getList(props.tree.url, params).then((res) => {
        if (res.code === 1) {
            const TreeNodes = res.data
            // const root = {
            //     id: '0',
            //     name: '跟目录',
            //     open: true,
            //     pId: '-1',
            //     code: '1',
            //     isParent: true,
            //     edit: false,
            //     remove: false,
            //     icon: '/static/root.png',
            // }
            // if (!selectNode.value) {
            //     selectNode.value = root
            // }
            // TreeNodes.push(root)

            YxTreeRef.value.init(TreeNodes, {
                drag: props.tree.drag,
                add: props.tree.add,
                edit: props.tree.edit,
                remove: props.tree.remove,
            })
            YxTreeRef.value.select(selectNode.value.id)
        }
        YxTreeRef.value.hideLoading()
    })
}

/**
 * 搜索
 * @param params
 */
const init = async (params: any) => {
    await initTree()
    params = params || {}
    if (params.treeId) {
        selectNode.value.id = params.treeId
        selectNode.value.code = params.treeCode
    } else {
        assignIn(
            params,
            props.tree.customParam
                ? {}
                : {
                      treeId: selectNode.value.id || '0',
                      treeCode: selectNode.value.code || '1',
                  },
        )
    }

    assignIn(params, props.defaultParam ? props.defaultParam() : {})
    MyTablePageRef.value.search(params)
}

/**
 * searchTable 搜索table
 * @param params
 */
const search = async (params: any) => {
    params = params || {}
    assignIn(
        params,
        props.tree.customParam
            ? {}
            : {
                  treeId: selectNode.value.id || '0',
                  treeCode: selectNode.value.code || '1',
              },
    )
    assignIn(params, props.defaultParam ? props.defaultParam() : {})
    MyTablePageRef.value.search(params)
}

const emits = defineEmits(['dragend'])

/*=========树形操作start===============*/
/*拖动结束*/
const onDrop = (treeNodes: any, targetNode: any, moveType: any) => {
    props.tree.handelDrop && props.tree.handelDrop(treeNodes, targetNode, moveType)
}
/*添加*/
const add = (treeNodes: any) => {
    props.tree.handelAdd && props.tree.handelAdd(treeNodes)
}
/*编辑*/
const edit = (treeNodes: any) => {
    props.tree.handelEdit && props.tree.handelEdit(treeNodes)
}
/*删除*/
const remove = (treeNodes: any) => {
    props.tree.handelRemove && props.tree.handelRemove(treeNodes)
}
/*点击*/
const click = (treeNodes: any) => {
    selectNode.value = treeNodes
    props.tree.handelClick && props.tree.handelClick(treeNodes)
}
/*=========树形操作end===============*/

/*详情 start===================*/
const showDetail = (row: any) => {
    MyTablePageRef.value.showDetail(row)
}
/*详情 end===================*/

/**
 * 获取选中行
 */
const getSelection = () => {
    const selected = MyTablePageRef.value.getSelection()
    return selected
}
/**
 * 获取表格数据
 */
const getData = () => {
    return MyTablePageRef.value.getData()
}
/**
 * 导出
 */
const handleExport = (name) => {
    MyTablePageRef.value.handleExport(name)
}
/**
 * 导入
 */
const handleImport = (param) => {
    MyTablePageRef.value.handleImport(param)
}
defineExpose({
    init,
    search,
    getSelection,
    initTree,
    showDetail,
    getData,
    handleExport,
    handleImport,
})
</script>

<style scoped lang="less">
@import '@/theme/theme.less';
.list-tree-wrapper {
    background-color: @component-background;
    overflow-y: hidden;
}

.list-tree-operator {
    float: left;
    padding: 12px 20px;
    min-height: 250px;
    overflow: auto;
    max-height: calc(100vh - 305px);
}

.list-tree-content {
    //border-left: 1px solid #e7e7e7;
    overflow: auto;
}
</style>
