<template>
    <YxModal
        ref="YxModalRef"
        :title="modalTitle"
        v-model:visible="visible"
        @ok="onSubmit"
        @cancel="onCancel"
        :submit-loading="submitLoading"
    >
        <ACard>
            <div class="" v-if="selectMethod === '1'">
                <ARadioGroup v-model:value="selectedIds">
                    <ARadio
                        :style="radioStyle"
                        v-for="(item, index) in userList"
                        :key="index"
                        :value="item.id"
                        >{{ item.name }}</ARadio
                    >
                </ARadioGroup>
            </div>
            <div class="" v-if="selectMethod === '2'">
                <ACheckboxGroup v-model:value="selectedIds">
                    <ACheckbox
                        :style="radioStyle"
                        v-for="(item, index) in userList"
                        :key="index"
                        :value="item.id"
                        >{{ item.name }}</ACheckbox
                    >
                </ACheckboxGroup>
            </div>
        </ACard>
    </YxModal>
</template>
<!--添加路由地址：/server/flowHistory/add，修改路由地址：/server/flowHistory/edit，组件地址：/server/flowHistory/edit-->
<script setup lang="ts">
import { reactive, ref } from 'vue'
/**
 * 基础数据定义
 */
const visible = ref(false)
const submitLoading = ref(false)
const modalTitle = ref('用户单选')
const userList = ref<any>([])
const selectedIds = ref<any>()
const selectMethod = ref<string>('1')
const radioStyle = reactive({
    height: '50px',
    lineHeight: '50px',
})

const show = (optionScopeData, sm, curData) => {
    selectMethod.value = sm
    visible.value = true
    userList.value = optionScopeData
    if (sm === '1') {
        modalTitle.value = '用户单选'
        selectedIds.value = curData?.[0]?.id
    } else {
        modalTitle.value = '用户多选'
        selectedIds.value = curData?.map((u: any) => u.id)
    }
}

defineExpose({ show })
const emits = defineEmits(['ok'])
/**
 * 选中
 */
const onSubmit = () => {
    visible.value = false
    let selectedArr: any = []
    if (selectMethod.value === '1') {
        selectedArr.push(selectedIds.value)
    } else {
        selectedArr.push(...selectedIds.value)
    }
    let result = userList.value.filter((item) => {
        return selectedArr.some((val) => val === item.id)
    })
    emits('ok', result)
}
/**
 * 关闭弹窗
 */
const onCancel = () => {
    visible.value = false
}
</script>

<style scoped lang="less"></style>
