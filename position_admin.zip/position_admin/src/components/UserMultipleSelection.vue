<!--用户多选-->
<template>
    <YxModal
        ref="YxModalRef"
        title="用户多选"
        :style="{ position: 'fixed' }"
        v-model:visible="visible"
        @ok="onSubmit"
        @cancel="onCancel"
        :submit-loading="submitLoading"
    >
        <div class="table-tree-container">
            <div class="list-tree-wrapper">
                <div
                    class="list-tree-operator"
                    :style="{
                        width: '320px',
                    }"
                >
                    <YxTree ref="YxTreeRef" @click="handleTreeClick"></YxTree>
                </div>
                <div class="list-tree-content">
                    <ARow :gutter="0">
                        <ACol :span="12">
                            <YxSearch
                                ref="YxSearchRef"
                                @expand="searchExpand"
                                :items="searchItem"
                                @search="handelSearch"
                            />
                            <ASpace><a @click="checkAll">全部选中</a></ASpace>
                            <ACheckboxGroup v-model:value="checkValue" style="width: 100%">
                                <AList
                                    :style="{ height: tableHeight }"
                                    style="overflow: auto"
                                    class="left_list"
                                    item-layout="horizontal"
                                    :data-source="userList"
                                >
                                    <template #loadMore>
                                        <div
                                            v-if="hasNext"
                                            :style="{
                                                textAlign: 'center',
                                                marginTop: '12px',
                                                marginBottom: '12px',
                                                height: '32px',
                                                lineHeight: '32px',
                                            }"
                                        >
                                            <AButton :loading="loading" @click="onLoadMore"
                                                >加载更多</AButton
                                            >
                                        </div>
                                    </template>
                                    <template #renderItem="{ item }">
                                        <AListItem>
                                            <AListItemMeta>
                                                <template #title>
                                                    <ACheckbox :value="item.id">
                                                        <a>
                                                            {{ item.userName }}
                                                            <ATag
                                                                v-for="(
                                                                    role, index
                                                                ) in item.roleList"
                                                                :key="index"
                                                                color="#2db7f5"
                                                            >
                                                                {{ role.title }}
                                                            </ATag>
                                                        </a>
                                                    </ACheckbox>
                                                </template>
                                                <template #avatar>
                                                    <AAvatar :src="getAvatar(item)" />
                                                </template>
                                                <template #description>
                                                    <div>{{ item.deptCode }}</div>
                                                </template>
                                            </AListItemMeta>
                                        </AListItem>
                                    </template>
                                </AList>
                            </ACheckboxGroup>
                        </ACol>
                        <ACol :span="12" style="padding-left: 20px">
                            <AAlert style="margin-top: 10px; margin-bottom: 10px" type="success">
                                <template #message>
                                    <div>
                                        已选：{{ checkValue.length }}个
                                        <!--                                        <ACheckbox :value="checkAll"> 本页全选 </ACheckbox>-->
                                    </div>
                                </template>
                            </AAlert>
                            <ASpace><a @click="unCheckAll">全部取消</a></ASpace>
                            <ACheckboxGroup
                                v-model:value="checkValue"
                                style="width: 100%; margin-top: 20px"
                            >
                                <AList
                                    :style="{ height: tableHeight }"
                                    style="overflow: auto"
                                    item-layout="horizontal"
                                    :data-source="selectUserList"
                                >
                                    <template #renderItem="{ item }">
                                        <AListItem>
                                            <AListItemMeta>
                                                <template #title>
                                                    <ACheckbox :value="item.id">
                                                        <a>
                                                            {{ item.userName }}
                                                            <ATag
                                                                v-for="(
                                                                    role, index
                                                                ) in item.roleList"
                                                                :key="index"
                                                                color="#2db7f5"
                                                            >
                                                                {{ role.title }}
                                                            </ATag>
                                                        </a>
                                                    </ACheckbox>
                                                </template>
                                                <template #avatar>
                                                    <AAvatar :src="getAvatar(item)" />
                                                </template>
                                                <template #description>
                                                    <div>{{ item.deptCode }}</div>
                                                </template>
                                            </AListItemMeta>
                                        </AListItem>
                                    </template>
                                </AList>
                            </ACheckboxGroup>
                        </ACol>
                    </ARow>
                </div>
            </div>
        </div>
    </YxModal>
</template>
<script setup lang="ts" name="UserMultipleSelection">
import { computed, nextTick, onMounted, ref, watch } from 'vue'
import { getList } from '@/api/common'
import { assignIn } from '@/utils/ObjectUtils'
import { getGlobalStore } from '@/store'
const YxSearchRef = ref()
const YxTreeRef = ref()
const userList = ref([])
const selectUserList = ref([])

const checkValue = ref<any>([])
const checkParams = ref<any>([])

watch(checkValue, () => {
    const oldSelectedLen = selectUserList.value.length
    const tmpArr = userList.value.filter((u: any) => checkValue.value.indexOf(u.id) > -1)
    /*第一次加载页面 userList.value 为空，使用传递过来的数据*/
    if (userList.value.length === 0 || (oldSelectedLen === 0 && tmpArr.length === 0)) {
        selectUserList.value = checkParams.value.map((c) => {
            return { id: c.id, userName: c.name }
        })
        return
    }

    /*这里的处理都是为了保持选择的顺序*/
    if (tmpArr.length > oldSelectedLen /*新增选中人员*/) {
        const addArr: any = []
        tmpArr.forEach((item: any) => {
            const tt = selectUserList.value.filter((e: any) => e.id === item.id)
            if (tt.length === 0) {
                addArr.push(item)
            }
        })
        selectUserList.value.push(...addArr)
    } else if (tmpArr.length < oldSelectedLen /*删除选中人员*/) {
        let index = -1
        let type = 0
        for (let i = 0; i < oldSelectedLen; i++) {
            const tt = tmpArr.filter((e: any) => e.id === selectUserList.value[i].id)
            if (tt.length === 0) {
                index = i
                type++
            }
        }
        if (type === 1 /*取消选中1个*/) {
            selectUserList.value.splice(index, 1)
        } else {
            /*取消选中所有*/
            selectUserList.value = []
        }
    } else {
        /*处理传递过来的用户数据*/
        selectUserList.value = []
        checkValue.value.forEach((item: any) => {
            const tmpArr = userList.value.filter((e: any) => e.id === item)
            if (tmpArr && tmpArr.length > 0) {
                selectUserList.value.push(tmpArr[0])
            }
        })
    }
})
/**
 * 全部选中
 */
const checkAll = () => {
    checkValue.value = userList.value.map((u: any) => u.id)
}
const unCheckAll = () => {
    checkValue.value = []
}
/**
 * 基础数据定义
 */
const visible = ref(false)
const submitLoading = ref(false)
const loading = ref(false)
let defParams = {}

const searchExpand = (clientHeight: any) => {
    getGlobalStore().clientHeight = clientHeight
}

const getAvatar = (item) => {
    if (item.avatar) {
        const avatar = JSON.parse(item.avatar)
        return import.meta.env.VITE_API_URL_STATIC + avatar.path
    } else {
        return import.meta.env.VITE_BASE_URL + '/static/image/avatar.jpeg'
    }
}
const searchItem = ref([
    {
        type: 'text',
        key: 'userName',
        label: '姓名',
        value: '',
        placeholder: '',
    },
    {
        type: 'text',
        key: 'phoneNumber',
        label: '手机号',
        value: '',
        placeholder: '',
    },
    {
        type: 'select',
        key: 'state',
        label: '状态',
        value: '1',
        placeholder: '',
        options: [
            {
                label: '启用',
                value: '1',
            },
            {
                label: '禁用',
                value: '0',
            },
        ],
    },
])

const initTree = () => {
    YxTreeRef.value.showLoading()
    getList(`${import.meta.env.VITE_API_URL_SYSTEM}/v1/sys/department/getZtree`, {}).then((res) => {
        if (res.code === 1) {
            const TreeNodes = res.data
            YxTreeRef.value.init(TreeNodes, {})
            YxTreeRef.value.select()
        }
        YxTreeRef.value.hideLoading()
    })
}
const tableHeight = computed(() => {
    return `calc(100vh - ${getGlobalStore().clientHeight + 140}px)`
})
/**
 * 显示弹窗
 * @param checked 已选[｛id:'',xxx｝]
 * @param param 其他参数
 */
const show = (checked, param) => {
    checkParams.value = checked
    checked = checked || []
    defParams = param || {}
    visible.value = true
    nextTick(() => {
        initTree()
        checkValue.value = checked.map((c) => c.id)
    })
}
defineExpose({ show })

const emits = defineEmits(['ok'])
const onSubmit = () => {
    const result = selectUserList.value.map((u: any) => {
        return {
            id: u.id,
            name: u.userName,
        }
    })
    emits('ok', result)
    onCancel()
}
const onCancel = () => {
    selectUserList.value = []
    visible.value = false
}

const selectNode = ref({ code: '100' })

const pageNumber = ref(1)
const pageSize = ref(10)
const hasNext = ref(true)
const search = (params) => {
    loading.value = true
    params = params || {}
    params = Object.assign(
        {
            pageNumber: pageNumber.value,
            pageSize: pageSize.value,
        },
        params,
        defParams,
    )

    getList(`${import.meta.env.VITE_API_URL_SYSTEM}/v1/sys/user/getList`, params).then((res) => {
        if (res.code === 1) {
            const data = res.data
            if (params.pageNumber === 1) {
                userList.value = []
            }
            userList.value = userList.value.concat(data.rows)
            hasNext.value = data.pages > params.pageNumber
        }
        loading.value = false
    })
}
const onLoadMore = () => {
    pageNumber.value += 1
    const params = Object.assign({ deptCode: selectNode.value.code }, YxSearchRef.value.getValues())
    search(params)
}
/*点击*/
const handleTreeClick = (treeNodes: any) => {
    selectNode.value = treeNodes
    pageNumber.value = 1
    search({ deptCode: selectNode.value.code })
}

const handelSearch = () => {
    pageNumber.value = 1
    const params = assignIn(
        {
            deptCode: selectNode.value.code,
        },
        YxSearchRef.value.getValues(),
    )
    search(params)
}

onMounted(() => {})
</script>
<style scoped lang="less">
@import '@/theme/theme.less';
.list-tree-wrapper {
    background-color: @component-background;
    overflow-y: hidden;
}

.list-tree-operator {
    float: left;
    padding: 12px 20px;
    min-height: 250px;
    overflow: auto;
    max-height: calc(100vh - 250px);
}

.list-tree-content {
    //border-left: 1px solid #e7e7e7;
    overflow: auto;
}
.left_list {
    border-right: 1px solid @border-color-base;
}
</style>
