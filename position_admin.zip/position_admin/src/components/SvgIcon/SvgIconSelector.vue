<template>
    <AInputSearch v-model:value="val" placeholder="请选择图标" @search="onSearch">
        <template #enterButton>
            <AButton type="primary">选择</AButton>
        </template>
    </AInputSearch>

    <AModal v-model:visible="visible" title="选择图标" :footer="null">
        <YxSvgIcon
            v-for="icon in icons"
            style="margin: 10px; cursor: pointer"
            :name="icon"
            size="30px"
            color="#000000"
            :key="icon"
            @click="selected(icon)"
        />
    </AModal>
</template>

<script setup lang="ts">
import { ref, watch } from 'vue'
import { icons } from './iconData'
const visible = ref(false)
const val = ref('')

const props = defineProps<{ value: string | null }>()
val.value = props.value || ''
watch(
    () => props.value,
    () => {
        val.value = props.value || ''
    },
)
const emits = defineEmits(['update:value'])
const onSearch = () => {
    visible.value = true
}
const selected = (icon: string) => {
    val.value = icon
    visible.value = false
}
watch(val, () => {
    emits('update:value', val.value)
})
</script>

<style scoped lang="less">
.kxFont {
    cursor: pointer;
    font-size: 28px !important;
    &:hover {
        color: #0081ff;
    }
}
</style>
