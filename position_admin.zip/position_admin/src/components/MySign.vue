<!--电子签名-->
<template>
    <div>
        <div @click="show">
            <slot></slot>
        </div>
        <AModal
            v-model:visible="visible"
            :width="width + 6"
            title="电子签名"
            :body-style="{ padding: '0 2px' }"
        >
            <canvas
                :id="canvasId"
                :width="width"
                :height="height"
                style="background-color: #ffffff"
            ></canvas>
            <template #footer>
                <AButton @click="handleCancel">取消</AButton>
                <AButton type="dashed" @click="handleReset">重写</AButton>
                <AButton type="primary" :loading="loading" @click="handleOk">确定</AButton>
            </template>
        </AModal>
    </div>
</template>
<script setup lang="ts" name="MySign">
import { nextTick, ref } from 'vue'
import { message } from 'ant-design-vue'
import { uploadFile } from '@/api/common'
const canvasId = new Date().getTime() + '_' + Math.floor(Math.random() * 1000)
const loading = ref<boolean>(false)
const visible = ref(false)
let canvasEl: HTMLCanvasElement
let ctxEl: CanvasRenderingContext2D
let drawed = false
// 判断是否为移动端
const mobileStatus = /Mobile|Android|iPhone/i.test(navigator.userAgent)

// 保存上次绘制的 坐标及偏移量
const last = ref<any>({
    offsetX: 0, // 偏移量
    offsetY: 0,
    endX: 0, // 坐标
    endY: 0,
})

type CanvasLineCap = 'butt' | 'round' | 'square'
type CanvasLineJoin = 'bevel' | 'miter' | 'round'

interface Props {
    width?: number
    height?: number
    bgColor?: string
    lineWidth?: number
    strokeColor?: string
    lineCap?: CanvasLineCap
    lineJoin?: CanvasLineJoin
}

const props = withDefaults(defineProps<Props>(), {
    width: 520, //画布宽度
    height: 260, //画布高度
    bgColor: 'transparent', //填充背景色
    lineWidth: 4, //线宽
    strokeColor: 'green', //线段颜色
    lineCap: 'round', //设置线条两端圆角
    lineJoin: 'round', //线条交汇处圆角
})
const initCanvas = () => {
    // 获取canvas 实例
    canvasEl = document.getElementById(canvasId) as HTMLCanvasElement
    // 设置宽高
    canvasEl.width = props.width
    canvasEl.height = props.height
    // 创建上下文
    ctxEl = canvasEl.getContext('2d') as CanvasRenderingContext2D
    // 设置填充背景色
    ctxEl.fillStyle = props.bgColor
    // 绘制填充矩形
    ctxEl.fillRect(
        0, // x 轴起始绘制位置
        0, // y 轴起始绘制位置
        props.width, // 宽度
        props.height, // 高度
    )
}
const drawing = (event: { changedTouches?: any; pageX?: any; pageY?: any }) => {
    // 获取当前坐标点位
    const { pageX, pageY } = mobileStatus ? event.changedTouches[0] : event

    const { x, y } = canvasEl.getBoundingClientRect()
    // 修改最后一次绘制的坐标点
    last.value.endX = pageX
    last.value.endY = pageY
    // 根据坐标点位移动添加线条
    ctxEl.lineTo(pageX - x, pageY - y)
    // 绘制
    ctxEl.stroke()
    drawed = true
}

const startDraw = (event: {
    changedTouches?: any
    offsetX?: any
    offsetY?: any
    pageX?: any
    pageY?: any
}) => {
    // 获取偏移量及坐标
    const { offsetX, offsetY, pageX, pageY } = mobileStatus ? event.changedTouches[0] : event

    const { x, y } = canvasEl.getBoundingClientRect()

    last.value.offsetX = offsetX
    last.value.offsetY = offsetY
    last.value.endX = pageX
    last.value.endY = pageY

    // 清除以上一次 beginPath 之后的所有路径，进行绘制
    ctxEl.beginPath()
    // 根据配置文件设置相应配置
    ctxEl.lineWidth = props.lineWidth
    ctxEl.strokeStyle = props.strokeColor
    ctxEl.lineCap = props.lineCap
    ctxEl.lineJoin = props.lineJoin
    // 设置画线起始点位
    ctxEl.moveTo(last.value.endX - x, last.value.endY - y)
    // 监听 鼠标移动或手势移动
    window.removeEventListener(mobileStatus ? 'touchmove' : 'mousemove', drawing)
    window.addEventListener(mobileStatus ? 'touchmove' : 'mousemove', drawing)
}
const endDraw = () => {
    // 结束绘制
    ctxEl.closePath()
    // 移除鼠标移动或手势移动监听器
    window.removeEventListener(mobileStatus ? 'touchmove' : 'mousemove', drawing)
}
const addEventListener = () => {
    removeEventListener()
    // 创建鼠标/手势按下监听器
    window.addEventListener(mobileStatus ? 'touchstart' : 'mousedown', startDraw)
    // 创建鼠标/手势 弹起/离开 监听器
    window.addEventListener(mobileStatus ? 'touchend' : 'mouseup', endDraw)
}
const removeEventListener = () => {
    // 创建鼠标/手势按下监听器
    window.removeEventListener(mobileStatus ? 'touchstart' : 'mousedown', startDraw)
    // 创建鼠标/手势 弹起/离开 监听器
    window.removeEventListener(mobileStatus ? 'touchend' : 'mouseup', endDraw)
}

const show = () => {
    drawed = false
    visible.value = true
    nextTick(() => {
        initCanvas()
        addEventListener()
    })
}
defineExpose({ show })
const handleCancel = () => {
    removeEventListener()
    visible.value = false
}
const handleReset = () => {
    // 清空当前画布上的所有绘制内容
    if (canvasEl) {
        const canvasCtx = canvasEl.getContext('2d') as CanvasRenderingContext2D
        canvasCtx.clearRect(0, 0, props.width, props.height)
    }
}
const emits = defineEmits(['ok'])
const handleOk = () => {
    loading.value = true
    //至少动过一笔才可以确定
    if (drawed) {
        // 将canvas上的内容转成blob流
        canvasEl.toBlob(
            (blob: any) => {
                uploadFile(blob).then((res) => {
                    if (res.code === 1) {
                        emits('ok', res.data)
                        handleCancel()
                    }
                    loading.value = false
                })
            },
            'image/png',
            0.5,
        )
    } else {
        message.warn('请先完成签名！')
    }
}
</script>
<style scoped lang="less"></style>
