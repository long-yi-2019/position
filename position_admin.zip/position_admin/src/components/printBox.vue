<template>
    <div style="width: 100%; height: 100%">
        <APageHeader class="yx-page-header" :title="title" @back="goBack">
            <template #extra>
                <AForm
                    ref="myFormRef"
                    name="myFormRef"
                    style="padding: 0"
                    :model="formState"
                    layout="inline"
                >
                    <AFormItem name="width">
                        <AInputNumber
                            v-model:value="formState.width"
                            :min="10"
                            :max="3000"
                            @change="changeHeight"
                            :formatter="(value) => `${value}mm`"
                            :parser="(value) => value.replace('mm', '')"
                        />
                    </AFormItem>
                    <AFormItem name="height">
                        <AInputNumber
                            v-model:value="formState.height"
                            :min="10"
                            :max="3000"
                            @change="changeWidth"
                            :formatter="(value) => `${value}mm`"
                            :parser="(value) => value.replace('mm', '')"
                        />
                    </AFormItem>
                    <AFormItem>
                        <AButton type="primary" @click="handleSubmit" :loading="confirmLoading">
                            导出
                        </AButton>
                    </AFormItem>
                </AForm>
            </template>
        </APageHeader>

        <div class="box_body">
            <div ref="printMain" class="container" :style="mainStyle">
                <slot></slot>
            </div>
        </div>
    </div>
</template>

<script setup lang="ts" name="printPng">
/**
 * 用于打印线下粘贴是使用
 */
import html2Canvas from 'html2canvas'
import { changeDpiBlob } from '@/utils/changedpi.js'
import { computed, onMounted, ref, watch } from 'vue'
import { mm2PxByDpi } from '@/utils/dpi'
import { isEmpty } from '@/utils/Common'
import { message } from 'ant-design-vue/es'
import { isNotEmpty } from '@/utils/ValidateUtils'

const printMain = ref<HTMLElement>()
const confirmLoading = ref(false)
const myFormRef = ref()

interface Props {
    title: string // 标题
    width: number //宽度mm
    height: number //高度mm
}

const props = withDefaults(defineProps<Props>(), {
    title: '',
    width: 420,
    height: 297,
})
const formState = ref({
    width: props.width,
    height: props.height,
})
const dpi = 300 //默认图片dpi
const showWidth = 1920 //默认宽度，页面基于这个宽度进行缩放显示
const offsetWidth = ref(0) //窗口初始化宽度
/**
 * 窗口显示缩放比例
 */
const scale = computed(() => {
    if (offsetWidth.value > 0) {
        return offsetWidth.value / showWidth
    } else {
        return 1
    }
})

/**
 * 页面默认动态样式
 */
const mainStyle = ref({
    width: '100%',
    height: '100%',
    transform: `scale(1)`,
})
watch(
    () => [formState.value, offsetWidth.value],
    () => {
        mainStyle.value = {
            width: offsetWidth.value > 0 ? showWidth + 'px' : '100%',
            height:
                offsetWidth.value > 0
                    ? showWidth * (formState.value.height / formState.value.width) + 'px'
                    : '100%',
            transform: `scale(${scale.value})`,
        }
    },
    {
        deep: true,
    },
)

/**
 * 宽度改变，等比例改变高度
 * @param width
 */
const changeHeight = (width) => {
    if (isNotEmpty(width)) {
        formState.value.height = width * (props.height / props.width)
    }
}
/**
 * 高度改变，等比例改变宽度
 * @param height
 */
const changeWidth = (height) => {
    if (isNotEmpty(height)) {
        formState.value.width = height * (props.width / props.height)
    }
}

const emits = defineEmits(['back', 'before', 'after'])

const handleSubmit = () => {
    if (isEmpty(formState.value.width) || isEmpty(formState.value.height)) {
        message.error('请先设置打印宽高！')
        return
    }
    emits('before')
    confirmLoading.value = true
    setTimeout(() => {
        html2Canvas(printMain.value as HTMLElement, {
            allowTaint: false,
            useCORS: true, // 为解决跨域问题
            logging: false, // console中打印日志
            scale:
                mm2PxByDpi(formState.value.width, dpi) /
                (printMain.value?.offsetWidth || showWidth) /
                scale.value,
        }).then((canvas) => {
            canvas.toBlob((blob) => {
                changeDpiBlob(blob, dpi).then((blob) => {
                    const href = window.URL.createObjectURL(new Blob([blob]))
                    const link = document.createElement('a')
                    link.href = href
                    link.download = props.title + '.png'
                    document.body.appendChild(link)
                    link.click()
                    document.body.removeChild(link)
                    emits('after')
                    confirmLoading.value = false
                })
            }, 'image/png')
        })
    }, 500)
}
const goBack = () => {
    emits('back')
}

onMounted(() => {
    /**
     * 初始化页面默认宽度
     */
    offsetWidth.value = printMain.value?.offsetWidth || showWidth
})
</script>

<style scoped lang="less">
@import '@/theme/theme.less';

.yx-page-header {
    background-color: @component-background;
}

.box_body {
    position: relative;
    padding: 20px;
    height: calc(100% - 72px);
    max-height: calc(100% - 72px);
    overflow: auto;
}

.container {
    position: relative;
    background-color: #ffffff;
    width: 100%;
    height: 100%;
    transform-origin: 0 0;
    padding: 0;
    color: #000;
}
</style>
