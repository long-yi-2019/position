<template>
    <div style="text-align: right; margin-top: 10px">
        <APagination
            v-model="pageNumber"
            :page-size-options="pageSizeOptions"
            :total="total"
            size="small"
            show-size-changer
            :page-size="pageSize"
            :show-total="(total) => `总计 ${total} 条`"
            show-quick-jumper
            @showSizeChange="pageShowSizeChange"
            @change="pageChange"
        >
            <template v-slot:buildOptionText="props">
                <span>{{ props.value }}条/页</span>
            </template>
        </APagination>
    </div>
</template>

<script setup lang="ts">
import { ref } from 'vue'

const pageNumber = ref(1)
const total = ref(0)
const pageSize = ref(10)
const pageSizeOptions = ref(['10', '20', '50', '100', '200', '300', '500'])
/**
 * 接收方法
 */
const emits = defineEmits(['search'])
const pageShowSizeChange = (current, curPageSize) => {
    pageSize.value = curPageSize
    pageNumber.value = 1
    emits('search', { pageSize: pageSize.value, pageNumber: pageNumber.value })
}
const pageChange = (curPageNumber) => {
    pageNumber.value = curPageNumber
    emits('search', { pageSize: pageSize.value, pageNumber: pageNumber.value })
}
const setData = (params) => {
    pageNumber.value = params.pageNumber
    total.value = params.total
    pageSize.value = params.pageSize
}
defineExpose({
    setData,
})
</script>

<style scoped lang="less"></style>
