<template>
    <YxModal
        ref="YxModalRef"
        :title="modalTitle"
        v-model:visible="visible"
        @ok="onSubmit"
        @cancel="onCancel"
        :submit-loading="submitLoading"
    >
        <MyTablePage
            ref="MyTablePageRef"
            :showTools="false"
            :search-item="searchItem"
            :url="dataUrl"
            :columns="columns"
            :action="action"
            :ellipsis="1"
            show-index
            pagination
            selection="checkbox"
        >
        </MyTablePage>
    </YxModal>
</template>

<script setup lang="ts">
/**
 * 废弃-使用LabSelection.vue
 */
import { nextTick, ref } from 'vue'
import { isNotEmpty } from '@/utils/ValidateUtils'
import { message } from 'ant-design-vue'
const MyTablePageRef = ref()
const modalTitle = ref('选择实验室')
const visible = ref(false)
const submitLoading = ref(false)

const dataUrl = `${import.meta.env.VITE_API_URL_SYSTEM}/v1/lab/info/getList`
const columns = [
    {
        title: '所属学院',
        dataIndex: 'departmentName',
        hidden: false,
        sorter: true,
        width: 220,
    },
    {
        title: '房间名称',
        dataIndex: 'roomName',
        hidden: false,
        sorter: true,
        width: 200,
    },
    {
        title: '房间号',
        dataIndex: 'roomNumber',
        hidden: false,
        sorter: true,
        width: 200,
    },
    {
        title: '房间编号',
        dataIndex: 'roomSpecificNumber',
        hidden: false,
        sorter: true,
        width: 120,
    },
    {
        title: '楼栋',
        dataIndex: 'buildingName',
        hidden: false,
        sorter: true,
        width: 200,
    },
    {
        title: '负责人',
        dataIndex: 'managerName',
        hidden: false,
        sorter: true,
        width: 200,
    },
    {
        title: '安全负责人',
        dataIndex: 'safetyManagerName',
        hidden: false,
        sorter: true,
        width: 200,
    },
    {
        title: '分管领导',
        dataIndex: 'subLeaderName',
        hidden: false,
        sorter: true,
        width: 200,
    },
    {
        title: '用房性质',
        dataIndex: 'nature',
        hidden: false,
        sorter: true,
        width: 200,
        formatter: {
            type: 'text',
            format: (row) => {
                if (row.nature === '1') {
                    return {
                        value: '教学性质',
                    }
                } else if (row.nature === '2') {
                    return {
                        value: '研究用房',
                    }
                } else {
                    return {
                        value: '-',
                    }
                }
            },
        },
    },
    {
        title: '类别',
        dataIndex: 'type',
        hidden: false,
        sorter: true,
        width: 80,
        formatter: {
            type: 'text',
            format: (row) => {
                if (row.type === '1') {
                    return {
                        value: '化学类',
                    }
                } else if (row.type === '2') {
                    return {
                        value: '生物类',
                    }
                } else if (row.type === '3') {
                    return {
                        value: '机电类',
                    }
                } else if (row.type === '4') {
                    return {
                        value: '辐射类',
                    }
                } else if (row.type === '5') {
                    return {
                        value: '其他',
                    }
                } else {
                    return {
                        value: '-',
                    }
                }
            },
        },
    },
    {
        title: '安全等级',
        dataIndex: 'safeLevel',
        hidden: false,
        sorter: true,
        width: 100,
        formatter: {
            type: 'text',
            format: (row) => {
                if (row.safeLevel === '1') {
                    return {
                        value: '一级',
                    }
                } else if (row.safeLevel === '2') {
                    return {
                        value: '二级',
                    }
                } else if (row.safeLevel === '3') {
                    return {
                        value: '三级',
                    }
                } else if (row.safeLevel === '4') {
                    return {
                        value: '四级',
                    }
                } else {
                    return {
                        value: '-',
                    }
                }
            },
        },
    },
    {
        title: '使用面积',
        dataIndex: 'areaSize',
        hidden: false,
        sorter: true,
        width: 100,
        formatter: {
            type: 'text',
            format: (row) => {
                if (isNotEmpty(row.areaSize)) {
                    return {
                        value: row.areaSize / 100 + '㎡',
                    }
                } else {
                    return {
                        value: '-',
                    }
                }
            },
        },
    },
    {
        title: '实验人数',
        dataIndex: 'testNumber',
        hidden: false,
        sorter: true,
        width: 100,
    },
    {
        title: '状态',
        dataIndex: 'status',
        hidden: false,
        sorter: true,
        width: 70,
        formatter: {
            type: 'text',
            format: (row) => {
                if (row.status === '1') {
                    return {
                        value: '在用',
                    }
                } else if (row.status === '0') {
                    return {
                        value: '停用',
                    }
                } else {
                    return {
                        value: '-',
                    }
                }
            },
        },
    },
    {
        title: '备注',
        dataIndex: 'remark',
        hidden: false,
        sorter: true,
        width: 300,
    },
]
const searchItem = ref<any[]>([
    {
        type: 'organize',
        key: 'departmentCode',
        label: '所属学院',
    },
    {
        type: 'text',
        key: 'roomNumber',
        label: '房间号',
        value: '',
        placeholder: '',
    },
    {
        type: 'select',
        key: 'nature',
        label: '用房性质',
        value: '',
        placeholder: '',
        options: [
            {
                label: '教学性质',
                value: '1',
            },
            {
                label: '研究用房',
                value: '2',
            },
        ],
    },
    {
        type: 'select',
        key: 'type',
        label: '类别',
        value: '',
        placeholder: '',
        options: [
            {
                label: '化学类',
                value: '1',
            },
            {
                label: '生物类',
                value: '2',
            },
            {
                label: '机电类',
                value: '3',
            },
            {
                label: '辐射类',
                value: '4',
            },
            {
                label: '其他',
                value: '5',
            },
        ],
    },
    {
        type: 'select',
        key: 'safeLevel',
        label: '安全等级',
        value: '',
        placeholder: '',
        options: [
            {
                label: '一级',
                value: '1',
            },
            {
                label: '二级',
                value: '2',
            },
            {
                label: '三级',
                value: '3',
            },
            {
                label: '四级',
                value: '4',
            },
        ],
    },
    {
        type: 'select',
        key: 'status',
        label: '状态',
        value: '',
        placeholder: '',
        options: [
            {
                label: '在用',
                value: '1',
            },
            {
                label: '停用',
                value: '0',
            },
        ],
    },
])
/*table 操作列配置*/
const action = ref({
    width: 150,
    buttons: [
        {
            title: '详情',
            icon: 'iconfont icon-caidan',
            event: (row: any) => {
                MyTablePageRef.value.showDetail(row)
            },
        },
    ],
})

const show = (params: any) => {
    visible.value = true
    nextTick(() => {
        MyTablePageRef.value.search(params || {})
    })
}
defineExpose({ show })

const onSubmit = () => {
    const rows = MyTablePageRef.value.getSelection().selectedRows
    if (rows.length < 1) {
        message.warn('请选择实验室！')
        return
    } else {
        visible.value = false
        emits('change', rows)
    }
}
const onCancel = () => {
    visible.value = false
    submitLoading.value = false
}

const emits = defineEmits(['change'])
</script>
