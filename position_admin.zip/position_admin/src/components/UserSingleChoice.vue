<template>
    <YxModal
        ref="YxModalRef"
        title="选择用户（单选）"
        v-model:visible="visible"
        @cancel="onCancel"
        @ok="onSubmit"
    >
        <MyTablePage
            ref="MyTablePageRef"
            :search-item="searchItem"
            :url="dataUrl"
            :columns="columns"
            :ellipsis="1"
            show-index
            pagination
            selection="radio"
        >
        </MyTablePage>
    </YxModal>
</template>
<!--添加路由地址：/iot/iotCameraAuth/add，修改路由地址：/iot/iotCameraAuth/edit，组件地址：/iot/iotCameraAuth/edit-->
<script setup lang="ts">
import { nextTick, ref } from 'vue'
const dataUrl = `${import.meta.env.VITE_API_URL_SYSTEM}/v1/sys/user/getChooseList`
const MyTablePageRef = ref()
import { cloneDeep } from 'lodash-es'
import { message } from 'ant-design-vue'
/**
 * 基础数据定义
 */
const visible = ref(false)

const searchItem = ref([
    {
        type: 'userId',
        key: 'id',
        label: '用户',
        // value: '1',
        placeholder: '请输入姓名/工号',
    },
    {
        type: 'organize',
        key: 'deptCode',
        label: '组织',
        placeholder: '请选择组织',
    },
])
const columns = ref([
    {
        title: '姓名',
        dataIndex: 'userName',
        hidden: false,
        align: 'left',
        fixed: 'none',
        sorter: true,
        formatter: {
            type: 'text',
            format: (row) => {
                return {
                    value: `${row.userName}(${row.accountName})`, //
                }
            },
        },
    },
    {
        title: '所属组织',
        dataIndex: 'deptCode',
        hidden: false,
        align: 'left',
        fixed: 'none',
        width: 300,
    },
    {
        title: '身份标签',
        dataIndex: 'identityTypeCode',
        hidden: false,
        sorter: true,
        align: 'left',
        fixed: 'none',
    },
])

/**
 * 显示弹窗
 */
const show = () => {
    visible.value = true
    nextTick(() => {
        MyTablePageRef.value.search()
    })
}
defineExpose({ show })
const emits = defineEmits(['ok'])
const onSubmit = () => {
    const { selectedRows } = MyTablePageRef.value.getSelection()
    const rows = cloneDeep(selectedRows)
    if (rows.length < 1) {
        message.warn('请先选择！')
        return
    }
    emits('ok', rows[0])
    onCancel()
}
/**
 * 关闭弹窗
 */
const onCancel = () => {
    visible.value = false
}
</script>

<style scoped lang="less"></style>
