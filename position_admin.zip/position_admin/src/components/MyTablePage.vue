<template>
    <div class="table-page">
        <YxSearch
            ref="YxSearchRef"
            v-if="mySearchItem?.length > 0"
            :items="mySearchItem"
            @expand="searchExpand"
            @search="handelSearch"
        />
        <YxTable
            :style="{
                padding: mySearchItem?.length > 0 ? '0 20px 20px 20px' : '20px',
            }"
            ref="YxTableRef"
            :height="tableHeight"
            :pagination="pagination"
            :ellipsis="ellipsis"
            :selection="selection"
            :show-index="showIndex"
            :show-tools="showTools"
            :columns="columns"
            :action="tableAction"
            :drag="drag"
            :table-sm="tableSm"
            @reload="reload"
            @dragend="(e) => emits('dragend', e)"
            :data-source="dataSource"
        >
            <template #tools>
                <ASpace>
                    <slot name="tools"></slot>
                </ASpace>
            </template>
        </YxTable>
        <AModal
            v-model:visible="importVisible"
            :keyboard="false"
            :maskClosable="false"
            @ok="handleOk"
            title="数据导入"
        >
            <p v-if="importParam.templateUrl">
                <a href="javascript:void(0)" @click="downLoadTemplate">下载模板</a>
            </p>

            <AUploadDragger
                v-model:fileList="fileList"
                :before-upload="beforeUpload"
                accept=".xls,.xlsx"
                :maxCount="1"
                name="file"
            >
                <p class="ant-upload-drag-icon">
                    <InboxOutlined></InboxOutlined>
                </p>
                <p class="ant-upload-text">单击或拖动文件到此区域进行上传</p>
                <p class="ant-upload-hint">
                    请严格按照模板格式进行数据填写，否则数据可能无法正常导入！
                </p>
            </AUploadDragger>
        </AModal>
    </div>
</template>

<script setup lang="ts">
import { downLoad, uploadFile } from '@/utils/Common'
import { InboxOutlined } from '@ant-design/icons-vue'
import { getGlobalStore, getPermissionStore } from '@/store'
import { computed, ref, createVNode } from 'vue'
import { get } from '@/api/common'
import { assignIn } from '@/utils/ObjectUtils'
import { cloneDeep } from 'lodash-es'
import { message, Modal } from 'ant-design-vue'
import ExcelUtil from '@/utils/ExcelUtil'
import { getListByKeyword } from '@/api/system/sysUser'

const YxSearchRef = ref()
const YxTableRef = ref()
const dataSource = ref()

const permissionStore = getPermissionStore()
const defaultParams = ref<any>({})

const emits = defineEmits(['dragend', 'initTree'])
const importVisible = ref(false)

interface Props {
    searchItem?: any[]
    columns: any[]
    action?: any
    url: string
    localData?: any[]
    tableSm?: boolean
    showIndex?: boolean
    showTools?: boolean
    drag?: boolean
    selection?: 'checkbox' | 'radio'
    pagination?: boolean
    ellipsis?: number
    selectNode?: any //属性选中项，只配合MyTreeTablePage 时需要
    height?: number //原高度运算基础上的+-高度
}

const props = withDefaults(defineProps<Props>(), {
    tableSm: false,
    showIndex: false,
    showTools: true,
    drag: false,
    pagination: false,
    ellipsis: 1,
    selectNode: null, //属性选中项，只配合MyTreeTablePage 时需要
})
// eslint-disable-next-line vue/no-setup-props-destructure
const mySearchItem = ref(props.searchItem || [])

const getArea = (pid: string) => {
    return get(import.meta.env.VITE_API_URL_SYSTEM + '/v1/sys/area/getList', {
        pageNumber: 1,
        pageSize: -1,
        treeId: pid,
    })
}
mySearchItem.value = mySearchItem.value.map((s) => {
    // 搜索条行政区划类型，类型固定为 area;
    if (s.type === 'area') {
        return {
            cType: 'area',
            type: 'cascaderLazy',
            key: s.key || 'areaCode',
            label: s.label || '行政区划',
            placeholder: '请选择',
            changeOnSelect: true, // 选择即改变
            getLast: true,
            value: s.value || '',
            loadData: (selectedOptions: any) => {
                const targetOption = selectedOptions[selectedOptions.length - 1]
                targetOption.loading = true

                getArea(targetOption.id).then((res) => {
                    if (res.code === 1) {
                        const data = res.data.rows
                        const options = data.map((d) => {
                            return {
                                id: d.id,
                                treeId: d.parentId,
                                value: d.areaCode,
                                label: d.name,
                                isLeaf: d.level === 'district', //懒加载时使用，false标记为父节点
                            }
                        })
                        targetOption.children = options
                        targetOption.loading = false
                    }
                })
            },
            options: [],
        }
    }
    // 用户名称/工号搜索筛选
    else if (s.type === 'userId') {
        return {
            type: 'searchSelect',
            key: s.key || 'userId',
            label: s.label || '行政区划',
            value: s.value || '',
            placeholder: s.placeholder || '请输入姓名/工号',
            loadData: (val: string) => {
                return new Promise((resolve, reject) => {
                    if (val.length < 2) {
                        resolve([])
                        return
                    }
                    getListByKeyword({ keyword: val }).then((res) => {
                        if (res.code === 1) {
                            const data = res.data || []
                            const result = data.map((d) => {
                                return {
                                    value: d.id,
                                    label: `${d.userName}(${d.accountName})`, //
                                }
                            })
                            resolve(result)
                        } else {
                            reject(res)
                        }
                    })
                })
            },
            options: [],
        }
    }
    // 查询组织机构
    else if (s.type === 'organize') {
        return {
            cType: 'organize',
            type: 'treeSelect',
            key: s.key || 'departmentCode',
            label: s.label || '组织机构',
            placeholder: '请选择',
            value: s.value || '',
            fieldNames: { children: 'children', label: 'title', value: 'code' },
            expandAll: false, // 全部展开
            options: [],
        }
    }
    // 查询校区
    else if (s.type === 'campus') {
        return {
            cType: 'campus',
            type: 'select',
            key: s.key || 'schoolAreaCode',
            label: s.label || '校区',
            placeholder: '请选择',
            options: [],
            value: s.value || '',
        }
    }
    // 查询楼栋
    else if (s.type === 'building') {
        return {
            cType: 'building',
            type: 'select',
            key: s.key || 'buildingCode',
            label: s.label || '楼栋',
            placeholder: '请选择',
            options: [],
            value: s.value || '',
        }
    }
    // 搜索条系统字典筛选类型
    else if (s.type === 'sysDict') {
        return {
            cType: 'sysDict',
            type: 'select',
            dictKey: s.dictKey,
            key: s.key || 'id',
            label: s.label || '数据字典',
            value: s.value || '',
            placeholder: '请选择',
            options: [],
        }
    }
    // 搜索条实验室筛选类型
    else if (s.type === 'labInfo') {
        return {
            cType: 'labInfo',
            type: 'select',
            key: s.key || 'id',
            label: s.label || '实验室',
            value: s.value || '',
            placeholder: '请选择',
            options: [],
        }
    }

    return s
})
// 初始化数据 这里的areaCode对应124行的areaCode
const areaIndex = mySearchItem.value.findIndex((s) => s.cType === 'area')
if (areaIndex > -1) {
    getArea('0').then((res) => {
        if (res.code === 1) {
            const data = res.data.rows
            mySearchItem.value[areaIndex].options = data.map((d) => {
                return {
                    id: d.id,
                    treeId: d.parentId,
                    value: d.areaCode,
                    label: d.name,
                    isLeaf: d.level === 'district', //懒加载时使用，false标记为父节点
                }
            })
        }
    })
}

// 初始化组织机构数据
const organizeIndex = mySearchItem.value.findIndex((s) => s.cType === 'organize')
if (organizeIndex > -1) {
    get(`${import.meta.env.VITE_API_URL_SYSTEM}/v1/sys/department/getTree`, {}).then((res) => {
        if (res.code === 1) {
            mySearchItem.value[organizeIndex].options = res.data
        }
    })
}

// 初始化校区
const campusIndex = mySearchItem.value.findIndex((s) => s.cType === 'campus')
if (campusIndex > -1) {
    get(`${import.meta.env.VITE_API_URL_SYSTEM}/v1/school/area/getList`, {
        pageSize: -1,
        pageNumber: 1,
    }).then((res) => {
        if (res.code === 1) {
            const row = res.data.rows || []
            mySearchItem.value[campusIndex].options = row.map((v) => {
                return {
                    label: v.name,
                    value: v.code,
                }
            })
        }
    })
}

// 初始化楼栋
const buildingIndex = mySearchItem.value.findIndex((s) => s.cType === 'building')
if (buildingIndex > -1) {
    get(`${import.meta.env.VITE_API_URL_SYSTEM}/v1/school/building/getList`, {
        pageSize: -1,
        pageNumber: 1,
    }).then((res) => {
        if (res.code === 1) {
            const row = res.data.rows || []
            mySearchItem.value[buildingIndex].options = row.map((v) => {
                return {
                    label: v.name,
                    value: v.code,
                }
            })
        }
    })
}

// 初始化数据字典(可能会有多个)
const sysDictArray = mySearchItem.value.filter((s) => s.cType === 'sysDict')
if (sysDictArray.length > 0) {
    sysDictArray.forEach((d) => {
        console.log('打印d', d)
        get(`${import.meta.env.VITE_API_URL_SYSTEM}//v1/sys/dict/getList`, {
            pageSize: -1,
            pageNumber: 1,
            dictKey: d.dictKey,
        }).then((res) => {
            if (res.code === 1) {
                const row = res.data.rows || []
                d.options = row.map((v: { name: string }) => {
                    return {
                        label: v.name,
                        value: v.name,
                    }
                })
            }
        })
    })
}

// 初始化实验室数据
const labInfoIndex = mySearchItem.value.findIndex((s) => s.cType === 'labInfo')
if (labInfoIndex > -1) {
    get(import.meta.env.VITE_API_URL_SYSTEM + '/v1/lab/info/getLabList', {
        pageNumber: 1,
        pageSize: -1,
    }).then((res) => {
        if (res.code === 1) {
            const data = res.data.rows || []
            mySearchItem.value[labInfoIndex].options = data.map((d) => {
                return {
                    id: d.id,
                    value: d.id,
                    label: `${d.roomName}（${d.roomSpecificNumber}）`,
                }
            })
        }
    })
}

const tableAction = computed(() => {
    const actions = props.action
    if (props.action && props.action.buttons) {
        const btns: any[] = []
        props.action.buttons.forEach((d: any) => {
            if (d.permission == undefined || permissionStore.h(d.permission)) {
                btns.push(d)
            }
        })
        actions.buttons = btns
        return actions
    }
    return null
})
/*===============table高度动态设置 start================*/
const searchExpand = (clientHeight: any) => {
    getGlobalStore().clientHeight = clientHeight
}
const tableHeight = computed(() => {
    return `calc(100vh - ${getGlobalStore().clientHeight + (props.height || 0) + 380}px)`
})
/*===============table高度动态设置 end================*/

/**
 * 点击搜索条搜索，回到第一页。
 */
const handelSearch = () => {
    const params = {
        pageNumber: 1,
    }
    if (props.selectNode) {
        assignIn(params, {
            treeId: props.selectNode.id || '0',
            treeCode: props.selectNode.code || '1',
        })
    }
    if (YxSearchRef.value) {
        assignIn(params, YxSearchRef.value.getValues())
    }
    assignIn(params, defaultParams.value)
    YxTableRef.value.reload(params)
}

/**
 * 列表检索
 * @param params
 */
const search = (params: any) => {
    params = params || {}
    defaultParams.value = cloneDeep(params)
    if (YxSearchRef.value) {
        assignIn(params, YxSearchRef.value.getValues())
    }
    YxTableRef.value.reload(params)
}
/**
 * 重载数据回调
 */
const reload = (params: any) => {
    if (!props.pagination) {
        params.pageSize = -1
    }
    // 支持一页
    if (props.localData) {
        dataSource.value = {
            pageNumber: 1,
            pageSize: 10,
            pages: 1,
            rows: props.localData,
            size: props.localData.length,
            total: props.localData.length,
        }
        return
    }
    get(props.url, params || {}).then((res) => {
        if (res.code === 1) {
            if (!props.pagination) {
                dataSource.value = res.data.rows || res.data
            } else {
                dataSource.value = res.data
            }
        } else {
            dataSource.value = null
        }
    })
}

/**
 * 获取表格数据
 */
const getData = () => {
    return dataSource.value
}

/**
 * 打开详情页
 * @param row
 */
const showDetail = (row: any) => {
    YxTableRef.value.showDetail(row)
}

/**
 * 获取选中行
 */
const getSelection = () => {
    const selected = YxTableRef.value.getSelection()
    setTimeout(() => {
        YxTableRef.value?.clearSelection()
    }, 1000)
    return selected
}
/**
 * 导出
 */
const handleExport = (name) => {
    name = name + new Date().getTime()
    const hide = message.loading('正在导出..', 0)

    /*固定参数*/
    const params = {
        pageNumber: 1,
        pageSize: -1,
    }
    /*左侧树形参数*/
    if (props.selectNode) {
        assignIn(params, {
            treeId: props.selectNode.id || '0',
            treeCode: props.selectNode.code || '1',
        })
    }
    /*搜索条参数*/
    if (YxSearchRef.value) {
        assignIn(params, YxSearchRef.value.getValues())
    }
    /*默认参数*/
    assignIn(params, defaultParams.value)
    get(props.url, params || {}).then((res) => {
        if (res.code === 1) {
            const columnArray = YxTableRef.value.getColumnConfig()
            new ExcelUtil(columnArray, res.data.rows || res.data, name).export()
        } else {
            message.error('服务器繁忙，请稍后重试。')
        }
        hide()
    })
}
/**
 * 导入
 * @param param
 */
const fileList = ref<any>([])
const beforeUpload = (file) => {
    fileList.value = [file]
    return false
}
let importParam = {
    uploadUrl: '',
    templateUrl: '',
    templateName: '',
}

const handleImport = (param) => {
    fileList.value = []
    importVisible.value = true
    importParam = param
}

const handleOk = () => {
    if (fileList.value.length === 0) {
        message.warn('请先选择要上传的文件！')
        return
    }
    importVisible.value = false
    uploadFile(fileList.value[0].originFileObj, importParam.uploadUrl, {
        useToken: true,
        success: (res) => {
            if (res.code === 1) {
                // message.success('导入完成，请刷新查看！')
                let msg = '全部导入成功'
                if (res.data && res.data.length > 0) {
                    msg = res.data.map((v) => {
                        return createVNode('div', { style: 'color:red;' }, v)
                    })
                }
                Modal.info({
                    width: msg == '全部导入成功' ? '400px' : '60%',
                    title: '导入完成',
                    content: createVNode('div', { style: 'color:#000;' }, msg),
                })
                emits('initTree')
                handelSearch()
            } else {
                Modal.error({
                    title: '错误提示',
                    content: res.msg || '数据有误！',
                })
            }
        },
    })
}
/**
 * 下载导入模版
 */
const downLoadTemplate = () => {
    if (importParam.templateUrl) {
        downLoad(importParam.templateUrl, importParam.templateName, {
            useToken: true,
        })
    }
}

const getSearchParams = () => {
    return YxSearchRef.value.getValues()
}

defineExpose({
    search,
    showDetail,
    getSelection,
    getData,
    handleExport,
    handleImport,
    getSearchParams,
})
</script>

<style scoped lang="less">
@import '@/theme/theme.less';

.table-page {
    background-color: @component-background;
}
</style>
