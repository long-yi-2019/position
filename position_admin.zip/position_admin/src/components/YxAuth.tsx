import { defineComponent, Fragment, h, ref, watch } from 'vue'
const React = { createElement: h, Fragment }
export default defineComponent({
    props: {
        treeData: {
            type: Array,
            default: () => [],
        },
        value: {
            type: Array,
            default: () => [],
        },
    },
    emits: ['update:value', 'change'],
    setup(props, { emit }) {
        // eslint-disable-next-line vue/no-setup-props-destructure
        const checkedList = ref<any>(props.value)

        watch(
            () => props.value,
            () => {
                if (props.value !== checkedList.value) {
                    checkedList.value = props.value
                }
            },
        )

        watch(checkedList, () => {
            emit('update:value', checkedList.value)
            emit('change', checkedList.value)
        })
        /**
         * 子随父选中或取消
         * @param children
         * @param b
         */
        const checkedChildren = (children: any, b: boolean) => {
            if (children && children.length > 0) {
                children.forEach((item: any) => {
                    const index = checkedList.value.indexOf(item.id)
                    if (b) {
                        if (index === -1) {
                            checkedList.value.push(item.id)
                        }
                    } else {
                        if (index !== -1) {
                            checkedList.value.splice(index, 1)
                        }
                    }
                    checkedChildren(item.children, b)
                })
            }
        }

        /**
         * 取消选中父节点
         * @param parentId
         */
        const unCheckParent = (parentId: string) => {
            if (parentId === '0') {
                return
            }
            const list = [] as any
            const treeToList = (tree: any) => {
                tree.forEach((item: any) => {
                    list.push(item)
                    if (item.children && item.children.length > 0) {
                        treeToList(item.children)
                    }
                })
            }
            treeToList(props.treeData)
            const pItem = list.filter((item: any) => item.id === parentId)

            let allClear = true
            pItem[0].children.forEach((item: any) => {
                if (checkedList.value.indexOf(item.id) > -1) {
                    allClear = false
                }
            })

            if (allClear) {
                /*取消选中*/
                const index = checkedList.value.indexOf(parentId)
                if (index > -1) {
                    checkedList.value.splice(index, 1)
                    unCheckParent(pItem[0].parentId)
                }
            }
        }
        /**
         * 选项状态改变
         * @param checked
         * @param item
         */
        const handelChange = (checked: any, item: any) => {
            if (checked) {
                /*子选中，父跟着选中*/
                item.parentIds.forEach((pid: string) => {
                    if (checkedList.value.indexOf(pid) === -1) {
                        checkedList.value.push(pid)
                    }
                })
                /*父选中，子跟着选中*/
                checkedChildren(item.children, true)
            } else {
                /*父取消，子跟着取消*/
                checkedChildren(item.children, false)
                /*子同级全部取消，则父跟着取消 - 异步处理，否则选中状态结果还没赋值到checkedList*/
                setTimeout(() => {
                    unCheckParent(item.parentId)
                }, 100)
            }
        }
        const icon = (item: any) => {
            if (item.children && item.children.length > 0) {
                if (item.open) {
                    return (
                        <i
                            onClick={() => {
                                item.open = !item.open
                            }}
                            class="kxFont kx-caret-down"
                            style="font-size: 10px;cursor:pointer;margin-right:5px;"
                        ></i>
                    )
                } else {
                    return (
                        <i
                            onClick={() => {
                                item.open = !item.open
                            }}
                            class="kxFont kx-caret-right"
                            style="font-size: 10px;cursor:pointer;margin-right:5px;"
                        ></i>
                    )
                }
            }
        }
        const build = (list: any) => {
            return list.map((item: any) => {
                return (
                    <div
                        style={{
                            paddingLeft:
                                item.data.menuType === 3
                                    ? '17px'
                                    : item.children && item.children.length > 0
                                    ? '20px'
                                    : '37px',
                            display:
                                item.children && item.children.length > 0 ? 'block' : 'inline-flex',
                            // backgroundColor: item.data.menuType === 3 ? '#e1e1e1' : 'transparent',
                            overflow: 'hidden',
                            height: item.open ? 'auto' : '30px',
                            lineHeight: '30px',
                        }}
                    >
                        {icon(item)}
                        <a-checkbox
                            onChange={(e: any) => {
                                handelChange(e.target.checked, item)
                            }}
                            value={item.id}
                        >
                            {item.title}{' '}
                        </a-checkbox>
                        <div>{item.children && build(item.children)}</div>
                    </div>
                )
            })
        }

        return () => (
            <a-checkbox-group style="user-select:none;" v-model:value={checkedList.value}>
                {build(props.treeData)}
            </a-checkbox-group>
        )
    },
})
