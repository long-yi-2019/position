// vite.config.ts
import { defineConfig, loadEnv } from "file:///D:/project/position_admin/node_modules/vite/dist/node/index.js";
import vue from "file:///D:/project/position_admin/node_modules/@vitejs/plugin-vue/dist/index.mjs";
import VueJsx from "file:///D:/project/position_admin/node_modules/@vitejs/plugin-vue-jsx/dist/index.mjs";
import VueSetupExtend from "file:///D:/project/position_admin/node_modules/vite-plugin-vue-setup-extend/dist/index.mjs";
import { createSvgIconsPlugin } from "file:///D:/project/position_admin/node_modules/vite-plugin-svg-icons/dist/index.mjs";
import { resolve } from "path";
import eslintPlugin from "file:///D:/project/position_admin/node_modules/vite-plugin-eslint/dist/index.mjs";
import viteCompression from "file:///D:/project/position_admin/node_modules/vite-plugin-compression/dist/index.mjs";
var __vite_injected_original_dirname = "D:\\project\\position_admin";
var CWD = process.cwd();
var vite_config_default = ({ mode }) => {
  const { VITE_BASE_URL, VITE_SITE_FAVICON } = loadEnv(mode, CWD);
  return defineConfig({
    root: resolve(__vite_injected_original_dirname, ""),
    publicDir: resolve(__vite_injected_original_dirname, "./public"),
    base: `${VITE_BASE_URL}`,
    plugins: [
      vue(),
      VueJsx(),
      PluginTagsTransform(mode, VITE_BASE_URL, VITE_SITE_FAVICON),
      VueSetupExtend(),
      createSvgIconsPlugin({
        // 指定需要缓存的图标文件夹
        iconDirs: [resolve(process.cwd(), "src/assets/svg")],
        symbolId: "icon-[dir]-[name]"
      }),
      // 配置vite在运行的时候自动检测eslint规范
      eslintPlugin({
        include: [
          "src/**/*.ts",
          "src/**/*.js",
          "src/**/*.vue",
          "src/*.ts",
          "src/*.js",
          "src/*.vue"
        ],
        emitWarning: false
      }),
      viteCompression()
    ],
    build: {
      outDir: resolve(__vite_injected_original_dirname, "dist"),
      // 指定静态资源存放目录
      assetsDir: resolve(__vite_injected_original_dirname, "src/assets"),
      rollupOptions: {
        input: {
          root: resolve(__vite_injected_original_dirname, "index.html")
        },
        output: {
          entryFileNames: "assets/js/[name]-[hash].js",
          chunkFileNames: "assets/js/[name]-[hash].js",
          assetFileNames: "assets/[ext]/[name]-[hash].[ext]"
        }
      }
    },
    resolve: {
      alias: {
        "@": resolve(__vite_injected_original_dirname, "./src")
      }
    },
    css: {
      preprocessorOptions: {
        less: {
          javascriptEnabled: true
        }
      }
    },
    server: {
      port: 8100,
      host: "0.0.0.0",
      open: false
    },
    preview: {
      port: 8088,
      strictPort: true,
      open: true,
      cors: true
    }
  });
};
var PluginTagsTransform = function(mode, vite_base_url, vite_site_favicon) {
  console.log(mode);
  return {
    name: "body-prepend-transform",
    transformIndexHtml() {
      return [
        {
          tag: "link",
          attrs: {
            type: "text/css",
            charset: "utf-8",
            rel: "stylesheet",
            href: vite_base_url + "/static/css/loading.css"
          }
        },
        {
          tag: "link",
          attrs: {
            type: "image/svg+xml",
            rel: "icon",
            href: vite_base_url + vite_site_favicon
          }
        }
      ];
    }
  };
};
export {
  vite_config_default as default
};
//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsidml0ZS5jb25maWcudHMiXSwKICAic291cmNlc0NvbnRlbnQiOiBbImNvbnN0IF9fdml0ZV9pbmplY3RlZF9vcmlnaW5hbF9kaXJuYW1lID0gXCJEOlxcXFxwcm9qZWN0XFxcXHBvc2l0aW9uX2FkbWluXCI7Y29uc3QgX192aXRlX2luamVjdGVkX29yaWdpbmFsX2ZpbGVuYW1lID0gXCJEOlxcXFxwcm9qZWN0XFxcXHBvc2l0aW9uX2FkbWluXFxcXHZpdGUuY29uZmlnLnRzXCI7Y29uc3QgX192aXRlX2luamVjdGVkX29yaWdpbmFsX2ltcG9ydF9tZXRhX3VybCA9IFwiZmlsZTovLy9EOi9wcm9qZWN0L3Bvc2l0aW9uX2FkbWluL3ZpdGUuY29uZmlnLnRzXCI7aW1wb3J0IHsgQ29uZmlnRW52LCBkZWZpbmVDb25maWcsIGxvYWRFbnYsIFVzZXJDb25maWdFeHBvcnQgfSBmcm9tICd2aXRlJ1xyXG5pbXBvcnQgdnVlIGZyb20gJ0B2aXRlanMvcGx1Z2luLXZ1ZSdcclxuaW1wb3J0IFZ1ZUpzeCBmcm9tICdAdml0ZWpzL3BsdWdpbi12dWUtanN4J1xyXG5pbXBvcnQgVnVlU2V0dXBFeHRlbmQgZnJvbSAndml0ZS1wbHVnaW4tdnVlLXNldHVwLWV4dGVuZCdcclxuaW1wb3J0IHsgY3JlYXRlU3ZnSWNvbnNQbHVnaW4gfSBmcm9tICd2aXRlLXBsdWdpbi1zdmctaWNvbnMnXHJcbmltcG9ydCB7IHJlc29sdmUgfSBmcm9tICdwYXRoJ1xyXG5pbXBvcnQgZXNsaW50UGx1Z2luIGZyb20gJ3ZpdGUtcGx1Z2luLWVzbGludCdcclxuaW1wb3J0IHZpdGVDb21wcmVzc2lvbiBmcm9tICd2aXRlLXBsdWdpbi1jb21wcmVzc2lvbidcclxuY29uc3QgQ1dEID0gcHJvY2Vzcy5jd2QoKVxyXG4vLyBodHRwczovL3ZpdGVqcy5kZXYvY29uZmlnL1xyXG5leHBvcnQgZGVmYXVsdCAoeyBtb2RlIH06IENvbmZpZ0Vudik6IFVzZXJDb25maWdFeHBvcnQgPT4ge1xyXG4gICAgY29uc3QgeyBWSVRFX0JBU0VfVVJMLCBWSVRFX1NJVEVfRkFWSUNPTiB9ID0gbG9hZEVudihtb2RlLCBDV0QpXHJcbiAgICByZXR1cm4gZGVmaW5lQ29uZmlnKHtcclxuICAgICAgICByb290OiByZXNvbHZlKF9fZGlybmFtZSwgJycpLFxyXG4gICAgICAgIHB1YmxpY0RpcjogcmVzb2x2ZShfX2Rpcm5hbWUsICcuL3B1YmxpYycpLFxyXG4gICAgICAgIGJhc2U6IGAke1ZJVEVfQkFTRV9VUkx9YCxcclxuICAgICAgICBwbHVnaW5zOiBbXHJcbiAgICAgICAgICAgIHZ1ZSgpLFxyXG4gICAgICAgICAgICBWdWVKc3goKSxcclxuICAgICAgICAgICAgUGx1Z2luVGFnc1RyYW5zZm9ybShtb2RlLCBWSVRFX0JBU0VfVVJMLCBWSVRFX1NJVEVfRkFWSUNPTiksXHJcbiAgICAgICAgICAgIFZ1ZVNldHVwRXh0ZW5kKCksXHJcbiAgICAgICAgICAgIGNyZWF0ZVN2Z0ljb25zUGx1Z2luKHtcclxuICAgICAgICAgICAgICAgIC8vIFx1NjMwN1x1NUI5QVx1OTcwMFx1ODk4MVx1N0YxM1x1NUI1OFx1NzY4NFx1NTZGRVx1NjgwN1x1NjU4N1x1NEVGNlx1NTkzOVxyXG4gICAgICAgICAgICAgICAgaWNvbkRpcnM6IFtyZXNvbHZlKHByb2Nlc3MuY3dkKCksICdzcmMvYXNzZXRzL3N2ZycpXSxcclxuICAgICAgICAgICAgICAgIHN5bWJvbElkOiAnaWNvbi1bZGlyXS1bbmFtZV0nLFxyXG4gICAgICAgICAgICB9KSxcclxuICAgICAgICAgICAgLy8gXHU5MTREXHU3RjZFdml0ZVx1NTcyOFx1OEZEMFx1ODg0Q1x1NzY4NFx1NjVGNlx1NTAxOVx1ODFFQVx1NTJBOFx1NjhDMFx1NkQ0QmVzbGludFx1ODlDNFx1ODMwM1xyXG4gICAgICAgICAgICBlc2xpbnRQbHVnaW4oe1xyXG4gICAgICAgICAgICAgICAgaW5jbHVkZTogW1xyXG4gICAgICAgICAgICAgICAgICAgICdzcmMvKiovKi50cycsXHJcbiAgICAgICAgICAgICAgICAgICAgJ3NyYy8qKi8qLmpzJyxcclxuICAgICAgICAgICAgICAgICAgICAnc3JjLyoqLyoudnVlJyxcclxuICAgICAgICAgICAgICAgICAgICAnc3JjLyoudHMnLFxyXG4gICAgICAgICAgICAgICAgICAgICdzcmMvKi5qcycsXHJcbiAgICAgICAgICAgICAgICAgICAgJ3NyYy8qLnZ1ZScsXHJcbiAgICAgICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICAgICAgZW1pdFdhcm5pbmc6IGZhbHNlLFxyXG4gICAgICAgICAgICB9KSxcclxuICAgICAgICAgICAgdml0ZUNvbXByZXNzaW9uKCksXHJcbiAgICAgICAgXSxcclxuICAgICAgICBidWlsZDoge1xyXG4gICAgICAgICAgICBvdXREaXI6IHJlc29sdmUoX19kaXJuYW1lLCAnZGlzdCcpLFxyXG4gICAgICAgICAgICAvLyBcdTYzMDdcdTVCOUFcdTk3NTlcdTYwMDFcdThENDRcdTZFOTBcdTVCNThcdTY1M0VcdTc2RUVcdTVGNTVcclxuICAgICAgICAgICAgYXNzZXRzRGlyOiByZXNvbHZlKF9fZGlybmFtZSwgJ3NyYy9hc3NldHMnKSxcclxuICAgICAgICAgICAgcm9sbHVwT3B0aW9uczoge1xyXG4gICAgICAgICAgICAgICAgaW5wdXQ6IHtcclxuICAgICAgICAgICAgICAgICAgICByb290OiByZXNvbHZlKF9fZGlybmFtZSwgJ2luZGV4Lmh0bWwnKSxcclxuICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICBvdXRwdXQ6IHtcclxuICAgICAgICAgICAgICAgICAgICBlbnRyeUZpbGVOYW1lczogJ2Fzc2V0cy9qcy9bbmFtZV0tW2hhc2hdLmpzJyxcclxuICAgICAgICAgICAgICAgICAgICBjaHVua0ZpbGVOYW1lczogJ2Fzc2V0cy9qcy9bbmFtZV0tW2hhc2hdLmpzJyxcclxuICAgICAgICAgICAgICAgICAgICBhc3NldEZpbGVOYW1lczogJ2Fzc2V0cy9bZXh0XS9bbmFtZV0tW2hhc2hdLltleHRdJyxcclxuICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgfSxcclxuICAgICAgICByZXNvbHZlOiB7XHJcbiAgICAgICAgICAgIGFsaWFzOiB7XHJcbiAgICAgICAgICAgICAgICAnQCc6IHJlc29sdmUoX19kaXJuYW1lLCAnLi9zcmMnKSxcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICB9LFxyXG4gICAgICAgIGNzczoge1xyXG4gICAgICAgICAgICBwcmVwcm9jZXNzb3JPcHRpb25zOiB7XHJcbiAgICAgICAgICAgICAgICBsZXNzOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgamF2YXNjcmlwdEVuYWJsZWQ6IHRydWUsXHJcbiAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgIH0sXHJcbiAgICAgICAgc2VydmVyOiB7XHJcbiAgICAgICAgICAgIHBvcnQ6IDgxMDAsXHJcbiAgICAgICAgICAgIGhvc3Q6ICcwLjAuMC4wJyxcclxuICAgICAgICAgICAgb3BlbjogZmFsc2UsXHJcbiAgICAgICAgfSxcclxuICAgICAgICBwcmV2aWV3OiB7XHJcbiAgICAgICAgICAgIHBvcnQ6IDgwODgsXHJcbiAgICAgICAgICAgIHN0cmljdFBvcnQ6IHRydWUsXHJcbiAgICAgICAgICAgIG9wZW46IHRydWUsXHJcbiAgICAgICAgICAgIGNvcnM6IHRydWUsXHJcbiAgICAgICAgfSxcclxuICAgIH0pXHJcbn1cclxuXHJcbi8vIFx1NjNEMlx1NEVGNlx1RkYwQ1x1NjNEMFx1NEY5QiBcdTU3MjggaHRtbCAtPiBoZWFkIC0+IFx1NjNEMlx1NTE2NSBzY3JpcHRcclxuY29uc3QgUGx1Z2luVGFnc1RyYW5zZm9ybSA9IGZ1bmN0aW9uIChtb2RlLCB2aXRlX2Jhc2VfdXJsLCB2aXRlX3NpdGVfZmF2aWNvbikge1xyXG4gICAgY29uc29sZS5sb2cobW9kZSlcclxuICAgIC8vIGlmIChtb2RlICE9PSAncHJvZHVjdGlvbicpIHtcclxuICAgIC8vICAgICByZXR1cm4gbnVsbFxyXG4gICAgLy8gfVxyXG4gICAgcmV0dXJuIHtcclxuICAgICAgICBuYW1lOiAnYm9keS1wcmVwZW5kLXRyYW5zZm9ybScsXHJcbiAgICAgICAgdHJhbnNmb3JtSW5kZXhIdG1sKCkge1xyXG4gICAgICAgICAgICByZXR1cm4gW1xyXG4gICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICAgIHRhZzogJ2xpbmsnLFxyXG4gICAgICAgICAgICAgICAgICAgIGF0dHJzOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU6ICd0ZXh0L2NzcycsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNoYXJzZXQ6ICd1dGYtOCcsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHJlbDogJ3N0eWxlc2hlZXQnLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBocmVmOiB2aXRlX2Jhc2VfdXJsICsgJy9zdGF0aWMvY3NzL2xvYWRpbmcuY3NzJyxcclxuICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICB0YWc6ICdsaW5rJyxcclxuICAgICAgICAgICAgICAgICAgICBhdHRyczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0eXBlOiAnaW1hZ2Uvc3ZnK3htbCcsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHJlbDogJ2ljb24nLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBocmVmOiB2aXRlX2Jhc2VfdXJsICsgdml0ZV9zaXRlX2Zhdmljb24sXHJcbiAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIF1cclxuICAgICAgICB9LFxyXG4gICAgfVxyXG59XHJcbiJdLAogICJtYXBwaW5ncyI6ICI7QUFBbVEsU0FBb0IsY0FBYyxlQUFpQztBQUN0VSxPQUFPLFNBQVM7QUFDaEIsT0FBTyxZQUFZO0FBQ25CLE9BQU8sb0JBQW9CO0FBQzNCLFNBQVMsNEJBQTRCO0FBQ3JDLFNBQVMsZUFBZTtBQUN4QixPQUFPLGtCQUFrQjtBQUN6QixPQUFPLHFCQUFxQjtBQVA1QixJQUFNLG1DQUFtQztBQVF6QyxJQUFNLE1BQU0sUUFBUSxJQUFJO0FBRXhCLElBQU8sc0JBQVEsQ0FBQyxFQUFFLEtBQUssTUFBbUM7QUFDdEQsUUFBTSxFQUFFLGVBQWUsa0JBQWtCLElBQUksUUFBUSxNQUFNLEdBQUc7QUFDOUQsU0FBTyxhQUFhO0FBQUEsSUFDaEIsTUFBTSxRQUFRLGtDQUFXLEVBQUU7QUFBQSxJQUMzQixXQUFXLFFBQVEsa0NBQVcsVUFBVTtBQUFBLElBQ3hDLE1BQU0sR0FBRyxhQUFhO0FBQUEsSUFDdEIsU0FBUztBQUFBLE1BQ0wsSUFBSTtBQUFBLE1BQ0osT0FBTztBQUFBLE1BQ1Asb0JBQW9CLE1BQU0sZUFBZSxpQkFBaUI7QUFBQSxNQUMxRCxlQUFlO0FBQUEsTUFDZixxQkFBcUI7QUFBQTtBQUFBLFFBRWpCLFVBQVUsQ0FBQyxRQUFRLFFBQVEsSUFBSSxHQUFHLGdCQUFnQixDQUFDO0FBQUEsUUFDbkQsVUFBVTtBQUFBLE1BQ2QsQ0FBQztBQUFBO0FBQUEsTUFFRCxhQUFhO0FBQUEsUUFDVCxTQUFTO0FBQUEsVUFDTDtBQUFBLFVBQ0E7QUFBQSxVQUNBO0FBQUEsVUFDQTtBQUFBLFVBQ0E7QUFBQSxVQUNBO0FBQUEsUUFDSjtBQUFBLFFBQ0EsYUFBYTtBQUFBLE1BQ2pCLENBQUM7QUFBQSxNQUNELGdCQUFnQjtBQUFBLElBQ3BCO0FBQUEsSUFDQSxPQUFPO0FBQUEsTUFDSCxRQUFRLFFBQVEsa0NBQVcsTUFBTTtBQUFBO0FBQUEsTUFFakMsV0FBVyxRQUFRLGtDQUFXLFlBQVk7QUFBQSxNQUMxQyxlQUFlO0FBQUEsUUFDWCxPQUFPO0FBQUEsVUFDSCxNQUFNLFFBQVEsa0NBQVcsWUFBWTtBQUFBLFFBQ3pDO0FBQUEsUUFDQSxRQUFRO0FBQUEsVUFDSixnQkFBZ0I7QUFBQSxVQUNoQixnQkFBZ0I7QUFBQSxVQUNoQixnQkFBZ0I7QUFBQSxRQUNwQjtBQUFBLE1BQ0o7QUFBQSxJQUNKO0FBQUEsSUFDQSxTQUFTO0FBQUEsTUFDTCxPQUFPO0FBQUEsUUFDSCxLQUFLLFFBQVEsa0NBQVcsT0FBTztBQUFBLE1BQ25DO0FBQUEsSUFDSjtBQUFBLElBQ0EsS0FBSztBQUFBLE1BQ0QscUJBQXFCO0FBQUEsUUFDakIsTUFBTTtBQUFBLFVBQ0YsbUJBQW1CO0FBQUEsUUFDdkI7QUFBQSxNQUNKO0FBQUEsSUFDSjtBQUFBLElBQ0EsUUFBUTtBQUFBLE1BQ0osTUFBTTtBQUFBLE1BQ04sTUFBTTtBQUFBLE1BQ04sTUFBTTtBQUFBLElBQ1Y7QUFBQSxJQUNBLFNBQVM7QUFBQSxNQUNMLE1BQU07QUFBQSxNQUNOLFlBQVk7QUFBQSxNQUNaLE1BQU07QUFBQSxNQUNOLE1BQU07QUFBQSxJQUNWO0FBQUEsRUFDSixDQUFDO0FBQ0w7QUFHQSxJQUFNLHNCQUFzQixTQUFVLE1BQU0sZUFBZSxtQkFBbUI7QUFDMUUsVUFBUSxJQUFJLElBQUk7QUFJaEIsU0FBTztBQUFBLElBQ0gsTUFBTTtBQUFBLElBQ04scUJBQXFCO0FBQ2pCLGFBQU87QUFBQSxRQUNIO0FBQUEsVUFDSSxLQUFLO0FBQUEsVUFDTCxPQUFPO0FBQUEsWUFDSCxNQUFNO0FBQUEsWUFDTixTQUFTO0FBQUEsWUFDVCxLQUFLO0FBQUEsWUFDTCxNQUFNLGdCQUFnQjtBQUFBLFVBQzFCO0FBQUEsUUFDSjtBQUFBLFFBQ0E7QUFBQSxVQUNJLEtBQUs7QUFBQSxVQUNMLE9BQU87QUFBQSxZQUNILE1BQU07QUFBQSxZQUNOLEtBQUs7QUFBQSxZQUNMLE1BQU0sZ0JBQWdCO0FBQUEsVUFDMUI7QUFBQSxRQUNKO0FBQUEsTUFDSjtBQUFBLElBQ0o7QUFBQSxFQUNKO0FBQ0o7IiwKICAibmFtZXMiOiBbXQp9Cg==
